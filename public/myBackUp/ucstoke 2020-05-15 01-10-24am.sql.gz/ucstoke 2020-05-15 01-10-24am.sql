-- Created at 15.5.2020 1:10 using David Grudl MySQL Dump Utility
-- Host: 127.0.0.1:8000
-- MySQL Server: 5.5.5-10.4.11-MariaDB
-- Database: ucstoke

SET NAMES utf8;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET FOREIGN_KEY_CHECKS=0;
-- --------------------------------------------------------

DROP TABLE IF EXISTS `account_calculations`;

CREATE TABLE `account_calculations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT 'store value for operation',
  `rent` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT 'store value add ,subtract from account',
  `type` int(11) NOT NULL COMMENT '0 =>for account when add this person,1 =>for takeMoneyFromCustomer ,11 =>for take MoneyFromSupplier\n            2 => for payMoneyToSupplierOrSupplierCustomer,\n            3 => for add this number to adjust account,4 => for bill buy,\n            5 => for bill sale,\n            6=>bill back with type discount from account,\n            7=>bill back with type replace,\n            8=>bill back with type takeMoney,\n            9=>exist Deal typ profit,\n            10=>for Deal type loses,\n            11 =>for take MoneyFromSupplier,\n            ',
  `bill_id` bigint(20) unsigned DEFAULT NULL COMMENT 'null => if type not equal 4 or 5',
  `exist_deal_id` bigint(20) unsigned DEFAULT NULL COMMENT 'null => if type not equal 9 or 10',
  `account_after_this_action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relation_account` int(11) NOT NULL DEFAULT 0 COMMENT '0 =>for don''t update account,1=>for add value to account , 2 =>for subtract value from account',
  `note` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_calculations_device_id_foreign` (`device_id`),
  KEY `account_calculations_user_id_foreign` (`user_id`),
  KEY `account_calculations_account_id_foreign` (`account_id`),
  KEY `account_calculations_bill_id_foreign` (`bill_id`),
  KEY `account_calculations_exist_deal_id_foreign` (`exist_deal_id`),
  CONSTRAINT `account_calculations_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `account_calculations_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON DELETE CASCADE,
  CONSTRAINT `account_calculations_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `account_calculations_exist_deal_id_foreign` FOREIGN KEY (`exist_deal_id`) REFERENCES `exist_deals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `account_calculations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `device_id` bigint(20) unsigned NOT NULL COMMENT 'last device for this account',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tel` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `account` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `note` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `is_supplier` tinyint(1) DEFAULT 0,
  `is_customer` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accounts_user_id_foreign` (`user_id`),
  KEY `accounts_device_id_foreign` (`device_id`),
  CONSTRAINT `accounts_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `activities`;

CREATE TABLE `activities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `type` int(11) NOT NULL COMMENT 'users=>0,stokes=>1,saves=>2,backups->3,settings=>4,supplier=>5,customer=>6,supplierCustomer=>7,8->damageProduct,9=>devices,\n            10=>add and take money from treasury,11=>for expenses_types and expenses,12=>for product_units,barcode,product,productsCategory\n            13=>for bill buy,14=>for bill sale,15=>for bill message and bill design print,16=>for making,17=>for emp,18 =>exist_deals,\n            19=>for visit or plan',
  `data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `notification` int(11) NOT NULL DEFAULT 0 COMMENT '0 =>if activity don''t have notification,1 => if activity has notification,2 => if activity notification delete',
  `button` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'for store button to show activity',
  `device_id` bigint(20) unsigned DEFAULT NULL,
  `relation_treasury` int(11) NOT NULL DEFAULT 0 COMMENT '0 =>for don''t have relation with treasury , 1 => for have relation with treasury add,2 => for have relation with treasury subtract',
  `treasury_value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'store value add or subtract from treasury',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activities_user_id_foreign` (`user_id`),
  KEY `activities_device_id_foreign` (`device_id`),
  CONSTRAINT `activities_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `activities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `activities` (`id`, `user_id`, `type`, `data`, `notification`, `button`, `device_id`, `relation_treasury`, `treasury_value`, `created_at`, `updated_at`) VALUES
(1,	1,	3,	'تنزيل نسخة إحتياطية ',	0,	NULL,	1,	0,	NULL,	'2020-05-15 01:10:19',	'2020-05-15 01:10:19'),
(2,	1,	3,	'تنزيل نسخة إحتياطية ',	0,	NULL,	1,	0,	NULL,	'2020-05-15 01:10:22',	'2020-05-15 01:10:22'),
(3,	1,	3,	'تنزيل نسخة إحتياطية ',	0,	NULL,	1,	0,	NULL,	'2020-05-15 01:10:23',	'2020-05-15 01:10:23');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `backups`;

CREATE TABLE `backups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pass` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createBackUpEvery` int(11) NOT NULL,
  `dayCreate` date NOT NULL,
  `type` int(11) NOT NULL COMMENT '0=>create backup for dataBase Only,1=>create backup for file Only,2=>create backUp for dataBase and File',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `backups_pass_unique` (`pass`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `backups` (`id`, `pass`, `createBackUpEvery`, `dayCreate`, `type`, `created_at`, `updated_at`) VALUES
(1,	'c:',	1,	'2020-05-16',	0,	'2020-05-15 01:10:12',	'2020-05-15 01:10:12');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `barcodes`;

CREATE TABLE `barcodes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UltimateCode' COMMENT 'store company name in barcode',
  `company_name_font_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '8',
  `company_name_color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#000000',
  `barcode_font_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '6',
  `barcode_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CODE128',
  `barcode_width` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '38',
  `barcode_height` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '25',
  `product_font_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '6',
  `product_color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '6',
  `price_font_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '6',
  `price_color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#000000',
  `time_font_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '6',
  `time_color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#000000',
  `padding_top` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'by milly metre',
  `padding_bottom` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'by milly metre',
  `padding_right` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'by milly metre',
  `padding_left` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'by milly metre',
  `barcode_color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#000000',
  `last_barcode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT 'store last barcode create by program',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `barcodes_user_id_foreign` (`user_id`),
  CONSTRAINT `barcodes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `barcodes` (`id`, `user_id`, `company_name`, `company_name_font_size`, `company_name_color`, `barcode_font_size`, `barcode_type`, `barcode_width`, `barcode_height`, `product_font_size`, `product_color`, `price_font_size`, `price_color`, `time_font_size`, `time_color`, `padding_top`, `padding_bottom`, `padding_right`, `padding_left`, `barcode_color`, `last_barcode`, `created_at`, `updated_at`) VALUES
(1,	1,	'UltimateCode',	'8',	'#000000',	'6',	'CODE128',	'38',	'25',	'6',	'6',	'6',	'#000000',	'6',	'#000000',	'1',	'1',	'1',	'1',	'#000000',	'0',	'2020-05-15 01:10:13',	'2020-05-15 01:10:13');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `bill_back_details`;

CREATE TABLE `bill_back_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bill_back_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `bill_details_id` bigint(20) unsigned NOT NULL,
  `product_unit_id` bigint(20) unsigned NOT NULL,
  `relation_qte` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'store value relation product_unit_id and main unit',
  `qte` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'qte by main unit',
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'price for 1 main unit',
  `store_id` bigint(20) unsigned DEFAULT NULL COMMENT 'used in delete bill buy back',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bill_back_details_bill_back_id_foreign` (`bill_back_id`),
  KEY `bill_back_details_product_id_foreign` (`product_id`),
  KEY `bill_back_details_bill_details_id_foreign` (`bill_details_id`),
  KEY `bill_back_details_product_unit_id_foreign` (`product_unit_id`),
  KEY `bill_back_details_store_id_foreign` (`store_id`),
  CONSTRAINT `bill_back_details_bill_back_id_foreign` FOREIGN KEY (`bill_back_id`) REFERENCES `bill_backs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bill_back_details_bill_details_id_foreign` FOREIGN KEY (`bill_details_id`) REFERENCES `bill_details` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bill_back_details_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `bill_back_details_product_unit_id_foreign` FOREIGN KEY (`product_unit_id`) REFERENCES `product_units` (`id`),
  CONSTRAINT `bill_back_details_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `bill_backs`;

CREATE TABLE `bill_backs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `device_id` bigint(20) unsigned NOT NULL,
  `bill_id` bigint(20) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '0 =>replace , 1=> take money,2 => discount from account',
  `note` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ' ',
  `total_price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'total price for bill backs',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bill_backs_user_id_foreign` (`user_id`),
  KEY `bill_backs_device_id_foreign` (`device_id`),
  KEY `bill_backs_bill_id_foreign` (`bill_id`),
  CONSTRAINT `bill_backs_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bill_backs_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `bill_backs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `bill_details`;

CREATE TABLE `bill_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bill_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `store_id` bigint(20) unsigned DEFAULT NULL COMMENT 'used in delete bill buy or add Discarded to bill buy',
  `product_unit_id` bigint(20) unsigned NOT NULL,
  `relation_qte` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'store value relation product_unit_id and main unit',
  `qte` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'qte by main unit',
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'price for 1 main unit',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bill_details_bill_id_foreign` (`bill_id`),
  KEY `bill_details_product_id_foreign` (`product_id`),
  KEY `bill_details_store_id_foreign` (`store_id`),
  KEY `bill_details_product_unit_id_foreign` (`product_unit_id`),
  CONSTRAINT `bill_details_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bill_details_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `bill_details_product_unit_id_foreign` FOREIGN KEY (`product_unit_id`) REFERENCES `product_units` (`id`),
  CONSTRAINT `bill_details_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `bill_messages`;

CREATE TABLE `bill_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0 =>not active,1 =>active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bill_messages_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bill_messages` (`id`, `name`, `state`, `created_at`, `updated_at`) VALUES
(1,	'شكراً لزيارتكم',	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13'),
(2,	'سعداء بخدمتكم',	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13'),
(3,	'نسخة من الفاتورة بعد التعديل',	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13'),
(4,	'نسعى لنكون الأفضل',	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13'),
(5,	'برجاء مراجعة الحساب',	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13'),
(6,	'برجاء الإحتفاظ بالفاتورة',	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `bill_prints`;

CREATE TABLE `bill_prints` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UltimateCode',
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'شركة UltimateCode للبرمجيات ترحب بكم',
  `row_under_company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'سعداء بخدمتكم',
  `row_contact1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'إدارة : م/أحمد الغمرى : 01018030420',
  `row_contact2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'للتواصل مع خدمة العملاء : م/تامر عبدو : 01018030420',
  `use_small_size` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 for small size,0 for not small size',
  `small_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '6' COMMENT 'store value for width for bill when type_size =1',
  `icon` longtext COLLATE utf8mb4_unicode_ci DEFAULT ' data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAABmRklEQVR42u19e5wcRbX/9/TM7sxuNsnOEkIIYRMmgSDPQHiJvATxgQoob3wiylV/egERFblerj9/qOgPEVF/V1HxgSAQUBTfgoDIG+QtYnbILiGEGHZCstmd2Z3p8/uju6pOVffMPpLNBm5989nMdJ+q6uo6jzrnVHUP4OHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4TG5oKnuwJZEqb+SBdEcZgYRzQb4EGaACACoHYy3mJHhXwEY1nTGnSBaG1NXFwu52lTfj4dBqVzNApgTH85i5sOIgJh/rWB6uy5M+C0zDxo63QVgDQCAeXWxK/8/hrevWgNQKlfbAcxj4AAA8wAcTtHnHroQjzIajemPAVxhxs0gGgbzL0G0bmEht2aq7/t/Akrl6mwAnQwcC0YrER8HUB7AXlbBifH3CQArAdzBwEpi3A/CymIhNzjV9z0ZeFUZgJ7+yi4gOpaA1wFYwswLttS1CbSWiW8npr+C+JZiIb98qsfj1YSe/soiAr2NiV9HjCMYmLWlrk1EKwA8wsBfifmXxa78M1M9Hpvt3qa6A5uKUrm6G4AzwHwYCEvA1AoCmBkU3x7DfFd3Pcn0CjOvIqJfAri2WMjdP9Xj9EpEqVw9AMBpAB8Lxtx4lt8S/GtMJx4G4xEQ7gToqmIh99RUj9Om4BVpAErl6iIAxwI4l5lnESHPjIhJlMJQMKaKzkBIjD4GX06gXxa7cqWpHr+tGaX+apHBxxLR2QC6AQRTyb9R6BUAa8F8GYh+WSzkXnFe3yvKAJTK1UMY/CEwTgWoFcTxLXD0P0e3pJI7WyG9AqKHwXwZRQIzPNVjujWgp7/aCvCxIDoXjH2VQd8K+deETsMAfgbGlcWu3F1TPaZjxVZvAErlagDgSGZ8CeB9AQQEiq2wuQ0WGZ1XAh2Elcy4jAjXFwu5lVM9zlOBUrk6jxknA3wuogStHp+p5s8m0EOAHibCBQBuKxZy4VSPczNstQagp1zJEnAIQJcC2BdiiGVsZo5fsfQamL5JhMuKhVzfVI/7lkBPudINpnOJ+GMMZLdy/kyYDuBhgM8D6K6tddl4qzQApf7KEUz0JQIf1LirE1/D20rpFWb+HhF99dVqCErlajczn09EHwQ4P87xecXSmeleAi4oduVu3ywDuRmxVRmAnv7qPACfB/h0AFpA7HSMirrSb2IsdImBkRDL+4cxMBImCszIBVhYyGFaiz1Mm3r9UegDRPRjBr608FUSGvSUq/MIuICZ3wugY5LHT9M3jjB6ylWsrya98I7WADt3tWJaSzBp13foFQZdA+CihV1bD1+3CgNQKleyYPoYg88HYS6BEO/W02VY+1dRBnasdGbGUI2xYThET7mKJ/9VQbVm3LWXhuqo1kOA05hHaMsSCvmMPpPPBthzdh7FQitmtAbIZym+zsT614S+nkDngfCzYiE3MNU8mhhfqx1gnAriS5lpxmYeH4AIlVqI9dUQpfIwHn+xgqFaiDhZj/6hOoZqrDlKjrTnswG2aTO8zWUJe27bhoWFVkxvDZAXxmFz8ZcIq8D8VRB9c2sIC6bcAJTKldlg3AiiQ/RJpYkTPGZmvDBQw1P/quClSh09YobnRg0wNaQzO8dx+em5ALt0tWJmLoPdZ+eHd5zR8gcAbwAjvyn9t44ZKxj8oYVd+T9NNa/Gg1K5+gYwrgRhwaby0xzzamY8+PyG2hsfX1Npfbka4pmXqlhfrWtlI1mBnGMoI5C8AJnCABgdrRnsXGhFV1sGu2+bx5xpLcaAbI77Ad8FwgnFQn5Kd49OqQHo6a++E+DvENEsZplQUYhmajWTj0Z/YaCG3vXDuPf5QazdWAer9VvBOdWKVnU2bbIw08pkm/J2fV02LtTeEnxxcIR/csSCaX/ZZ05+1vYdLTo3PNb+N6GHAG4B4+PFrq07P1Dqr3aDcAWAt4E52Bz3DyK8sGEED64aWvGXvsGj21uC9wwM1//T6Gxci0wbOktPsk3lCZCYsqP2pfmPKrGuEhBhVnsGB8+bhh1ntCDi7bj4l04nrGXGvy3syt00VfyaEgNQKlc7Af4cQJ8QY6WsfDQbkzutp9NXbRjBk2srWPHyMHrXjSBke/q0lF1/F3SWGVybbmZ+pz5b7AeAu5nxFgJ+GwIHBwAWFlqx95w8dt82hxm5zITvz6EPAvgCgK8XC7nKVPCuCU/zAJ8D0OfAaJ/g/Vn0VRtqePzFKp5dN4zl/cOoMxAQbmPgHQHwKwYOixRcKJdol2Ce5DL+QUS3PQGZv4/OMSmO2/SAgJ06W7FgZgt22zaPuR0tE74/gNQM9DWAvlAs5NZtab5tcQNQKld2BegqAAdNtA1mxvrhEPesHMRfVm5EGLlUWpnF5gzrmJ1jo/zmvNrlpZRf5hLEDhCp/AMAdmfGhxj4D4vOhGwA7LxNDod0t2PXbVqtuHATcAuAjxcLuRVbmn9pKJWrC4B41t9EMAP/eKmKv71QwYMvDKEeCn7GYxcQLgLwQwCPAtyp+EJEjtI78kAyNldhgl3OGIDGcqTkJiDCYfOn4eB57ehozWyqMt0L8BnFQv7pLcm7LWoASuXqQWD8nsEzJtrGqg01/PHZDfhneRghy7VXAW5cnxuc4GZl2TmnjwkA3gFgMGT+vUvXdiku25YlnLTbDOw9J49gk0eeVoNwHgE/m6rNJqVyNWDwqWC6FOA5m9IWA3hkdQXXPbE+StxFM6Pmq7KbsVsfZgM6OmTMAPBzZcJJF3DkgZKCLttLyNA4eRMQYZdtcnjjTh3YviM74TEg0HoQ3lQs5O7dlLEc3zW3AErlSsCgc4jxOQCdkecjsqR6djW9knRmxsBIiF//cwP+vraC4TrrnqtJP80AuMsxTeyCBXaNQooBiOeLq1szdF6lHj4OxmxZnt22RJuzp2Xxuu52vHZeG3LZADTK/TcfH/4FmM4tdm1Zb6DUX10A4ssAOn40/jWjV2sceXK9g3hxIEqKO8qeMALRd1qdy9BrRkK+jMHvl8orZcE1DDL6IzLd2hyK0JoJsPu2Obx10fRoeXGM8u3Q1zHhCwT+erGQn3TDPukGoFSuAuDPguliJxeD0Y4ZwOqBETy8eggPrR5CpaZiccEyglyDEQ3IqM+hazcdor3YAZThhOKJTgiSsQCgZ/JZOnCwxteB+Y3RadWmCh/U5ez6qv/TWghv2bkDr92xHS0B2VnmMYyPvh3wKgLOLRby1082PyOeVk5m4DICzZ1QfxmohYy7nxvCr58ZwMBwPVZSk4zTWX0di8ccUnF0VPY3M3LBaRuG6/cB2FU8sQfSiUG7fuT1m1UCVV7x35WfiGUxnUVuwV0VMp1FPkvYf/s27DunDdt3tIx7fOLmLwTwxWIhN6m8nFQDUCpX28E4B4SL0+g6M5oSFw/XGX0vD+OaJ9dZa7mNR24cdJXEk1n/eMUgqiUNRVSfhVViUCUgvD5k7MfMV6gcgkksG0OiHiBR9ZltQ8IMzO7I4sidpmHf7fOY1hqMaXxS6MNg/hyIvj5ZDxmVytVWMJ/DRF8goHWc/QMAbBwO8fALFdzasxGrB2rqbUxx7I4UQwAdsxtPwPA3IPpIJsDDdcafAW53VwVUe7I+xMyrr0/SdEs3QciP4C8J+WAS8iXcjfYs4d17FDBvRgtaM8kxGm38AFyIKOE7aS8jmVQD0NNf+QmB3s1wN0XEx1qnpLsPVOshrnlyHf7ZXzWDb2VUTaLHSsxQE7qZLo0HIRJ21mYe5oipIhFouXDAuSFwO4C/MqM94VE4iUBm8+iI8ig4vr78nNWewYeWdmLHmdmG4zOG8buJCGdv7geMesrVeWC+nIje2ez6jfoHIjy3bgTfeXAd/rWxpjP2KsEmZ3yVyJOfap1ej6I6T7QewOEB4RBmvsKtJxOAcs526ca7kP2PyqU9HkxCfoBYXuCMB0f8XzyrFafv3olcNhiVfy6dwVcv7Mq/Z3PyUmLSDECpXL0CzB8FKHBpWledoJzBuO/5Ify5dwAvV0NIBTaG1WToZSZXJ39V5j6R+ZeLQ3Ymn+TszSIDbGX8VTP0hxA4DYw7AN7DKLBinrhurNgmBIjbV4YBbMrHDWQDwoHz2nD0wmnYriObyqBG4yfoTxNwdrGQ+8Nm4uUbGbicGLuO8fpmxQvAiwM1/GH5IO5+bgi1UCbsYlddueBiNrYMBLmzv00nwoMEHE2EnzJwjMzc6/a1R6+SRoa/6vrWbA+zm0AGdnKlwJ5gGtMZjJm5DI5c0IED57YbQzaG8QM4BNG3i4XcxzcHL11MigEolaufAXAxgGCsdUJm3Pv8IG755waEMqnXrIdpA0hJkjvY7FbnlGbTE4GrGLw/QJ9nxgftLL+TPGT70/ruJgY5Sc8GhLP2n4klc/KgCXCJmSsAnbCwK/eb8dc26OmvHkOEGyGezRhzHwA8+kIV375vHWpxOkvN8DrRR0bvCGh4vtGKgPoeEL4JwpcA3AdgXoPVA4iPxPkEsfEpfb5ZYtmlZQg4dpcZOHBu23iXg0MAFxYLuS+PlwejYbMbgJ7+yqcAfImIAmu3HGC5PSoTCkT78X/4aBkvDdUdWwpHocWOLTe9b0kJJxnDSNhyazMfw4oNWbYbxe3DBJzEQDszfsrgwFVyK/YX7Vq5hTgEcZVf5wpEmwER5s3M4pzXFjA9Rw3Hr8n4DhPRdyc6e5TK1SuY+SwArc34l3b99cMhLr2rjJUv11BnbqrkJGJ1GbvrOg1yA7INALVMQCcBqDFwI8CtSnzMte2p1xV+rZRk5MM2HHZuiaTxt+6f9eqUHbxGLWzTnsEZexes5xBGHV+iEMwXLOzKf2UivGyEzWoASuXquwH8iJmDREwjTLhcAnlpqIbvPNyPl6v1JEPUQDTqeCMXKu3OHA9AW282jGYndyhnboC+kSV8ayTEPQzuiu5D3U+DTyAxsyt6+nlyDEJ0bruODA5d0IZjdml3NrOMPr7x3d7CwBkLC7m1GAN6ytVZBFwF8NuskCq1ffv6zMCv/7ERd64YwuoNNRGrR0xJm/2NgrNUaL1Mp9hJsTZreuIcrc1laelIyOdGyWe22rLEgmwRUfx3ZY7YLqNodkbAlkmRKzRlHe9wZj6DjyztQldbdjzjGwJ4X7GQu3osfBwLNpsBKPVX9wPhjwx0jrVOeaiGbz/Yjw3DkX/Y1CtKGfFGxZUBcAdffZW5wkQ9x/WPyzzSmqG3VGt8HQOHqQKWoopzCbffCRPc87ZhoAbeAXDETm04cmEbume2jJtzFL3K/KhiId/UCJTKlVkA3cruK7bHgL51I7h1+RBu7Rlq6MJTw2O2jscSIjSg39bRGpy0cTj8Iwj7ajlpEEJA0CxFdiaDtJDUNQRSLuCUd2UNHD1u/tH9tkHB8QRG4eM6MI4uduUeHC9/GrS36SiVq7OY+R8EimZGK/Vmp1UU/aWhOr77cD/WVeoJ5uoHeLQPplwsOOaVDfPcRL2aKSVjrLJxdt7O4+hrqfYZNJghLK0xTgTzF2x3XSb3XCWP6zeb7XUSEPF25gZGQbSRbwlw3iGdWDyrxWKiO76p409UAvDWYiGXut20VK4cCcaVDBRH458b//5j7Qi+csc6DNXCURW44bEVEtjJwYQRIMeb0HQCES5oDbBsJMTfAO7QE4uqrxoVd5DIBYg7VJMICVkEpcif4L9aPUhNFCj5AaMzl8GHl3ahqy0zOv8MvZ+IFhfH6NE1wyYbgFJ/dQbAvwbRIWq5LBoQFoNsn3tpsBYpfzWEXIu1ysqlFDIDltiswSZ+NNc09Zk5fu7C0IlVlK7OQbcFlSeIM/gB4SN1xlNg/JGZWzU9Vl6ONdvsBYivby3xKfdenYNWfkWTBkJen/UndJm2LOG43abhDYvakG+hxPg2H38MAHTcwkLuNsnHnnL1SIBvBqhjNP7J75WREH/45xB+/uRGDI2wM6PLjL7rspu9+3qJTp9P8wzE8p6ob/IBhh4AFSIcHRAWhcxX6fgfxrXWzwwoJRbLfkq+7Hf/xbIm5Es/g6BbND4Bi/oQ9dUsJZeiC21ZnLVvnBMYg/5EBonvYtBbF3bl1k+pAegpVy8j4JyxlGUAawdr+N7DZZQrdd2DROzvxP2jdTItHtMETjnvnEhz/ZWyZQPkaiH+GTK6UzP+Mt5vEuOnuf3SMACUoJnyxljINhZv24LPHN6JtpYxL7ao3g8AdFwxNgKlcvVIADcD6BhPK0MjIS7+8zo8vWZYK3H6zB8redrsT0YZ7RCAG3gHdvuJkCD+HhCeaQloz5GQhyI7bmTCDQWQdsxIl00lIy6hWT5KHqd4Awygqy2Ds/YtYFb7uJ4l+HqxkDt3PBVcbJIBKJWr72TmG8dafu1QHd/7Wxn9gzV99TTlH1NvhcvlhGsmmSdPpoDHYASyAbXVQvwrZO5Ic/XVZ2qMr44T7j01oY1mMER5Bl4zuxWfOrwT7S3jZCVhgED/FrXF38F4lb/G+OJt6/DUmuFk4g6Ooo5yrlFYENG4Yd1EXkB8zxCtzWVpx0o93EjxcnTTJcGU4XO3ZsuyqRNUg8mm0eTjTjbbtGVx1tLk6kBTNhKdUCxM/H0CEzYApXK1k8H/JKbkTzS5Gglg7VAN3324jP6hmngc047dElFPSkxGko4k3f3OaXQ2rp1RfLnhJ47PAXRkM5mBkfAeZhxgtvMqd18qvh0OqPyCUWQT86cqunVO1E8zEIIORBnlY3drx7GvmZaawGrC9YG4XEcqPaU+A7j5qY24+clBlCt1EVNLBSRLcZMGIIVOtixID8DKCUi6dV0TDlA05d/d1ZY5tL9Sq8c9AqzlRqPVlkwR4j3/Jv/QUL6scUrSrQlGybwsq3gqZG6btiz+bWnsCYzGv8g7XEtEO0/0XQLj9R0lvkWgWVoC4j92x4Hipb6HynhpsAbl6kYFTSU1ENrVdRtWw6and0OzN3mqTA3Z1zCc0PUZsoyhs2qHCT95545hCPTrAdcvA4nrg2z33L0/prisPfNrQeC4vrUEqJQ/qhtKOtv0kAnlwRA/fmgAv3xqo+XJJIbQ5U8063eMxj9J+8WTG/HDBwfw0mAdHEbXV/0LOUpmqn0Oqu/mz7k/yHsX9wd5/+JT8E+NjeqcNPQMIGSsv+r4eSFzkm5yNun8j4oY3pq4PkU+G9CZk/KrJxpO9l/hpcE6/vvBWFdG41+Uu5gF4FsTVeIJGYCe/srxAE41N2U+rRkoZvaNT69H/1DNJrjQ2zIblYpmT5LXtC4t86QJYvTFeu9fovXU/p1+43OLdNJQxidODsDs6zdky20X7r82CkrYVVlOU4hIGULAUiYjaIyQgVoIXPXgAG5+aqNIPI3On7HSmRm/eGIjrnpgALU6tMLr/qX0X9Ib3h8EXRpESIMAxyAIlmovyuRRFN5908p51o0wpfOebf6nSoKzVu8KEjeRX6t/zviaicPQXxqq46a/b4jaHBt/Ti1FOjlujPvtBaX+SicTLmJm8dhackAUHlhVwdNrhyOPidRvrCVmotj1YmuA5E4rwMmzNjQCKTkBN9hyCphEnh2cMYBKLdzNZpLtulvts1RmeQ3jIVhldFl2jlPoSDtvhCue9fCD+wfw+AsjeN9+HdhxZmZU/oyF/ly5jqseHMD9fVUrdDLDyNaQEsNRBMV0w2ubsWzRNH/VxBm3p3ZZyg6ospE8sU6cMxEGhut7qLAskrloRUi9kUtfQnvkKgQw96GS97H7qfuYGCoyfLDGVU7+TgbQ3UMCIV9P/auKh16oYOn2+bHwLwDholJ/5fZiV34dxoHxv76E6L0ELNE33QgMPLx6CNc+8XJcVDwiQcIp08syYiDjUWAdTyZvnmGWf9ipilhpFHcVk5nt9qOilBBIFsyuM2cD0Lq6mB1MD0zI4SbpAOnm2m6sldkXcaCt/IKeovSR0RD5hLhzIQP39Fbx1IsjuOStBXR3NmBxusOToPeWa/jUr8tYNxTq+FrNVQzSyq6aI6cBeV79BWPpgNJUCH3XGhnR1X4MOTGr4c8SVtdD6AcpGHAMV8x/sr1G8yYw86iY7oM18yblz+qENgZkbkfcjDI2zPaISen6yaPrEFAn9t2+bSz8WwLCewF8A+PAuEKAnnJlEZDybH+KZRoJGbev2Jhc9ojLa+ZxwyYauuxmwiVn0NxRlLFZsg1OEUAz20OPcAj8OUET/Wfn2kapmymw/OPUmV/F1CFYfDfnrfqhfb48VMenbimjb12t8czRhH8A0Feu4ZO/KqN/sB71R1xDXSf6Hl2f2em3e3/yvuD0HynjosdS7qWQ/BTTq+OV1Rn3aVlLkz/B/0arQanv/XflkwFXCLVdsnYOucJr5NOWaflJuH3FIGrhKAw0k87FsY6OGWM2AKVyNQvG55k5yhgTx4xla+pV537y2Dr0vjyiuaNdVeFGRVZSnDOWQfiBjj/N7mjb0mLezmLqk6WZhk5xfVPLbj/eg51lwRWT6Tc+gPEm2HLXpZdgBFmU0cci3o/poXUs6CHDxN0c/5l8AEOdA/oH6zj/V2X0rqvp8TLj35h/ALCiXMN5SvlD0ooexnUiY2D659KN4jv9F/Swyf1bx2n5Emu8hXxB1w0BZI1pib1Cd55ljsZCcIsF/2HVseXHXNnSakt+XPnS3+P6UiY5pf6z5WH8+JGXTf2m/EMHMX2+VK6O2bMfuwfAvCsRTifhHpuHNUzHiYDnN9Tw1JoqZMZWD6zaIsmkX6KgdkzpWVf76spDSFlCkQ4nxYEbUugcX58N3TyPT9ayD0t6XD8g7OMGsGYXlxJMu33t/jI58mbuJ5n5NoYiTEuEsQgjUjLnYVwvUkzSGfqXNkaewIp+8b69Ufj3bH8N599SxtqNoTWjs2xfJSRDiOy+CHcSKxfp/Td15QxP5k/M7vZ4EqwVHeVyi/cxZALaVY07O/yT2f30BEVMJ1lHyqIjf3pikAkKFQLZ8gV5fRJ1WFxLyPcTayp4YcPImPgH4tOB6L0Nm80AlMrVLAjfMoPiLJ3oG4sY9vO/b8Bw6LpZrkJD3DD0gEpFMO1CXBf2ta1zyuUnp1+if059lnS5xGhcyTmmnBA4PeTmmraAG7Ykldz4pW5IELIRZlt5jJKoGT606slMPFsu+pqBEJ+6pYxn++uj8u/Z/shrWLMhtMOKML191+UPZf/YDll0fT1Lu2Nj2pcTr3TLE2GVlpUE/8N6yPMT8hWXJXHfku7KF1sykyJ/QqY5hU6iPrnyr69r9IPFOWV8huvAjU9tEDmPxvyLDcy3xuoFjNUDWASmw7SrYs12wkoz4/YVg1jePyzCEuW2GKdXZkuVm6TccculJkRv52Hh6pEMGYybaNx/076uL101Eu1rXz3tT39kAdQgrmOsNexz1nc507muLYwSqNlLus7qvoTCMbPOBci4WimcCg2MorFWSGbGixsixV7RX2vIv2f7a/jkL8t4cUPd1A+VwjdvX4Ymdl4j5f7k/av+ax4rhXfqwxkfxR82/GUhAwEwHLJ6b6HzJ6+jeEa648a6KCFx5Nd4G8apZ062r3RCtaHKWPKbIj/WalN8/MzaYdyxYrCp/gm5PgzAmHIBYzUAl0TXiyyYtp9Kp+LjSo1xa2kj6nIgVT/tL0IpZVPS8sWGwXWhEwMH7ZGRNTPbjHTWGqL6JAc6orNDZwZaAjymrLjVvvymXVfjAdjGRLm1MqGlBEPNjHJ2FIrPQAhhTCxPQJZXyqjCABOvMxNe3BDiEzeX0VuuJ/i3olzDJ25Wyi8MizY6ZIyB074pL2d/qfimf1Z/tfLY/YceS7bHS7rKclVF3YuQy5aAHtFL1cJ7AGz5kHru8l9l6l35VXM1k+0XwpVfK/6z25fyz7rbMulo168z4w89G1GphQ31z9HPSzAGjGoASuVKEcAxtqcstCo+ZgC3PDOAciW0XCLz9BvZgyx2ShkXyXHJU9x2EvRoCUcts9juV7RdNMVtS91pCB2vSTdRLdEM17HCakffj9gF6Lh3Lt3YA5WXAEysK8MAGTfLsMKmR+6/vQNPKaZx/0knCNW5FzeEOOcXZfSVzU6zvnU1nP3zMl7cEOr6WunV9USb7LQfhsn+2bmMdLo7Po3oUo84ofgyb2DolTqvknznFP6kh4Vqs45y2ZN0WZ/RgK5jfLGz1JFfs1vUlqs0/QEI5aEQv3x6IFX/UvTzmFK5WhxNv8fiAZzLQNbam86wmAoQ1lfruPe5IeNeWW4TjKumLbzt7kgX29Qy6RB9rN0fx10S4YU+lu64CAPI+GeJ/kG2H117ljpmp7/GbZOuoGhCCi2b+cwWeHu2hxhnhlR04yarmDxRX7jJ1lKdduOjcy9uCPHRG8voLdfQ21/DR5eti5Q/hEjyydhfHdvtm342cPPZjfvlCof0rgnSfXdnduv+Nb8Ae2efdKWjDyLqgJAQV36UvJA8VqrKDr+FPNnenV2fnetZ7VvuvS1v8tj2YI0+MTPueW4IG6phQv9S9DML8LmjKTc1I5bKlSyA5wCaowbS7HUQb9hj4PonNuD2FRv1ZhG1acN9zbOiqx0XBJiy2uUifQWjjPIBDpmpNfQolpN9U1ZVlVX9ja/PNl3+gIf4SfB1YYidAfxLxu2RgIjlNzHTJZNdlCL4xh0OncRYMtmWUh9RfcT1wYxQyo0SCj0GQqGEzjSTDCvVZRLiMR/lu/zFwztxuYDkOUIg6SToTtlAl5F1InpARjyI7AeGonpRf4JIvrYNiP4OYJb9lmGIh9HMD41Y/icJ+SEYWZWxNznyp2QKRj5IeyuxfEn50zKnjINNt98DwYafDBxZnIaT95whAgpCA/1cDWDHYiGv1oETGMUDoBMZNEddRLlExpGJXJT11RD3rhyCzKRbm0OdTL3tMplus3LZtVWTym/qS1cusrCkGQcWZdkMRcTn2KUkU5/j/im3z83kMnNrNkAIQsXNNGvlh1F+a3lJuvs6yyvdfhFzpj4HkOJOO/TQoYdMCEEiDhd1Q0q0Ezb444bfzXX1sdt/5/rN+m/Po2rpT42bqW89IyDDSDPhQz1LQISBXEA1Bue1oqnyUv7IVRtnpUnnoiTPnZUgduhyaTKtfUt3lASK8NQJZRWdxfXv7hvC+kpdj1cT/ZwD0InNNLzpUgEzziVi2844MwMY+MPyjRgcCa1nZaSB1K/mUpO0+NR0kd/RBhZqUpfpQlhlSTHBdAfKkVD1E1OdngUJIFpJwCoG7gIQRqktChAZxyUAzZmZywz2V+orQ+ZFSGkOYmYwHgGEsEprDu3mmycB2Yl9UxJ71tKi9Azs2UKGD8ZbSc7+wsNpwHv7xZRm6Mgy48azshO8ZjzEbCfoZhIgsEsnm05CSXQaj82Eoc2I7gat3LY9M/j8QK1EAa1m8GMBKAwINdZvOMZBDMwDqBvgwMiSzqUZGSQnGZ2QARGWpH3qsCFRLa5nyzen1JcFBkeA3y8fxMl7dAi/Nl0/melcAD9rxOeGBqDUXy0yeIkVz8rXFcWoM/C3F6pw5YGNAbPepdZI5AzvGpfVRkQeu2XIKICai9lpg0EriXA1MX4+M5d55AfHzWv6U1pn/3YV1g7VLieic0PmolEuwSdnWzJgFFmVkrO+UmQTtVoRaIIus+GJLbZxGGPCCRkLCuFTnpWwCMkoQL483X7wxwRi9oOsKowjjt1vzZwoLFGp+Oi7MEjO/xwzmARdBG7SSRcbYMx9xa8hK9VDvmLbadnh771j3t7N+PrhX61qXT04shczvYOA0xm8QDebIlzSZ7X4LGWLzNgTkhXU/bA8cInitKV/wmv626oq3rlbB6xfHEvRT4CXlPqrxWJXrpQ2Bg2ngFK5+gkwLmXAmtn1yl7c2VueGcDNfx9wXvxg3vMmX9tsnhCLZxcyAmTJjf7JKNFBMhZa5g9c6LmExIxrGnomAC4JCMuuO3H+uN+ldvw1vfnhEG8IGe9ixjuZ0WpcfxGrQ8RxVkwPK64PHbr9eK27oSdZ3943IAyDuL5OEDmKJ+PQ9BmcnNyMfOWXfJ8fnNifEzF6oI8NPZBxvT6GOEeibLK+vH5AGCbCLzKEH7W30O2/eFf3uH9L79RlfR0jIR8fMj4N5j1sd1aknWL5Mz/dZSuTjPmtGYIgvADhEcZ0bbQhwso0j04fE45/zTS8bXFHU/2M9fe8YiH3tbT7bmgAesrVXgK63R9/0E/vxY1f8Me1eGmwlvoGGFhGIXlOdSARdsnvjIShYNEVZrsc3MFggIgqzPh8NkPfvO6E7oHxCkca3vLj3iUhcHbI/F5mBEYBzU4+N9udrviCFqYpPpyyYi0d8pwRDBMyyA0rjgcgJTIhEqwlSLNG80+8yDPtrT4EBI5hCKzvruI7n4FMDoq6QfwdlmEJA8KPA8Llt35g/iObg6+nLuvrqNbDDxPoIkb03EvauwLlUFnnleK5M7copj/ZvA06aQTSlN7m9bbTsvjyG7dx2Gf0M2IxA0R9Cwu5+Wn3m2oAesrVRQR+HEx5hsypq/8jBtUZOOvmF1Nf5OjODImXRSJpFFLuQ99IoqNueWl0BWMC0DMMHLfspPmpr8LeVLzxRyv2CkO6IAROTV3+Yk6ZvV1jYGb/pvTQNSyyfZmQkzmDOF7WiTAxQ0G6i2ZASSRwZKbf8Ey85FO+tVcrpn0ucGfvQCm3TU8aBuUFkM7yC2NxTTbAJX8+c/5jk8HXE67v3QXADSHzXlIeU+NP55w0uiSOtZIjWS5N8cHuU5Nk0UMm/NeRXVjQ2ZKqn9rYE1UA7LmwkFvu3mfqKgABb2NQXsVker8CkdlxR4Tbnx3SySwzGCIyZILJvBqzyVrjzV/iVV8cZzX1Zh/Hsoi6qj8c1yfT4V9mAuw5WcoPAH9434LHmOm0DNFRAJ6QDJYxNgu2sEO13HI2zE9srXXdQsu4yPJG+ZlJCJFNDxNtOvVdOkRyU5d3+ySEOJHDcDcF2fcn8yicMn6xhj2RDehoMN41WcoPADeePP+ZlgwtBdFN1oYyIX/6vHkqR8uj/pT6IOUbUi+i+uzQOaW+Hr/46IHnKw31U+kvgDwBb0u7z/RlQObXmeSO22XoYPz+lRUou6PjTqeTWiGU++n4QrYTasddyTJJh4UcuvAofhYEOOFnJ8xvmuDbHLj1A9344/u7b5veSvsT6AKABux3vpm+m6f8IubKJbHoXsn+U9uKraVBdzlNjbOrrK5yusYgSVfeh+2ZODMQq0d/xdN8kPVN/+x+w5zTRt8IfiQn9tio+gAGCHxhZx773/7B7j/95az5Y2XPhPGzE7pruQxOyRB+0Ej+bIi8QFqY0OB9d5Z+AK5SWN6DO7n+c+2IPGvkH7b+gvl1DXpso1SuZpn5WRDN0/231kaic2sH6/jM79fqH360Nn5AJAKFy2h3jHViCQ4dis5kvoukIIs60bEsC4DwswzhfddtAeVPw2Hf69s1DPF9Zhws974bxXJ316ndejbdDguSx24ewZ65HXcSxkC7y05G0EziJZGL0fG34qfik715R7vyihZI+QAokEk+OykYpNDjsODeDOGMez86eZ5cM7zr589lq7XwyjDE+80wxe42AzppLWL96DkSFRMYB92EAcbjYUG3vD9ImVBG05afDAFffcssdLVnLP2UUUkc5q0kop2KhZy1KSjNA9iLKPp5ZWkdzC6+6C6e7R9BrQ6YTRDOWqic7fUNy2PX9rA9gFKh45ExHg1S1qhZ3flNCHHGVCk/ANz5we6n7zqr+3VE/GWAKvr+9UjqHosZjq2ZUAuLDgvYOZbegOt6i00zaS46kl6E+1x+6NBhtWHaR1r70pUXu+Gs+xV9lfLDNr0SAF/unpk5fKqUHwB++o4dawx8BMD1RruS8mnORt+sNEEi4WrLr9QPzUNYKmN7CTFGQuDZ/pGEfib0lzAPKb/3mGYAjrBffgYT6yhWMuH+lRXRQeOWWG4/jMDJWzNKLgYjlnhyB4qj3ut1X06aDuEdLG/N4MxlJ8+vTJDXmxV3nTX/AgLeDtAKZRDluEi3zlr/txTEsNMYDls4rA1HrgcgFb4RXbvaDh0N6gtjbxkc4XKk7eKTBl5PFlZYIFnKK4n57Q98bP4FN7573pQZc4UbT5pfybfQhwA8lUxYG89JqmwiNLWZboe2nKxvDpOyIcfwvpVVSP1srL84wr2vhAFgYCf54EbaQyoA48k1w7qGLi/Zy0Z8rZu2bpTtO4Lqu3wwRFxb1zL19HeiYQDvuuaE+eu2lFCMBXd/uPtPzPxaAt8GcS9SFcz4modV5ENHnPgzQ5d4gEgrrFDWREhA4pzzAA/GWV/QDWcJRhrY+qfvX9S3+MiMgHAnh7z/w/8+/09TzT+Ja97ZvT4gvA/AoHy2P/GeAsVTW2L1+MCVX1fpwSl/sL6bl8owHn2hikrN3RSWor/ATu49JQwAAW8QOcz4U32L/h8cYdRCCGGUmUt1HLemBEZn/8V5mQBKeXTX2pefyMQKeuSHfW3ZSfPvn2ohScN9H52/OpeltwD4tnTMjNtnJwyN+y/DApMZtgVNCBUk80X71qxvP5EmRVQaBNMW9Pm4ku1JCLo5x1rG7WSoG/6o61gO67c7WoM3PXrOgtVTzbc0LDtp/oMAvqZ8TvNwm9ER+Qn16awU6E/lIac8h2Lrjzi2JQgbhxlPrK4iqbcJ/X2Dez+WASiVK4uYeVFi945+/jiy7E+8OIzBYRZMtf0SO4YRron0AYXyyhlduj1qEOXsYGAe8AFQymeDS6daOJrhzrO6h7MBnQ3gFIAqOn6WoRWEyyyVXszyUAZXPzjixOoyHywfnhF0lnWd+m6b+rsOYdylKXMsw0ErbHG9DOfa8clKhnBmlvjsuz6y41YRwjXC9NbgUhAt1+NpzegKzjKAlF87mWXoKfXNg0Lyw12XY/x9zYjRpUb6y1hUct4abHsATFmAoucDhGseyRzrjj2zdgTGtTMdkzGuuWmrffOVk3QrurdCCjVWdn01KxFwyU/f0b3Jv5U+2bj3o921hz/efT2BTyFgrb0PAA6TlYtpkRynku2yrusO4QkgMth6dhczNQRdexUsr6/c/Aahg3bhzfUhpMN2fw3/tDgT1hPhlMc/Mf8Hj5y7oOGjq1sLfnT8juuQ+sYdx7uTE570fFPifWuGt3gmx8w6SuiH1Yc0/SVkIx03sAwAEx+gO6YNs3HQFNPWbqwLSRQzk2S4fBpIzxJSIGTiRCYZBT1un+RMqG6T9Pag/umtwdWTx+7Nj7/9+/xftmbwOgAlJSSG6dEIyDFNRIBaic34J1RNGw42jpVQfpgrGeMtQwdAKL8qLMMI55oN+m9mSYgaVp1SLksH/v2T83851XwZD7bJZ64mwmqwkF/HQzX8E/LtesAp8h+dJoenEPVlIj0a65cG63beoYH+RjpuYBkAAs3T/ZaL9oqBBGwYZvx9zbDlosL5bv3Apqhrv+IIEBfQRiPxRl9yjq31VgID/33VcTuO++GPqcYDH+t+BkyHMqOEBuOYeOZO5FukG63H3HpeXmykge3OA3aIodsUu9zY6YNc9oN7TbbLJ+vChC12PqAEpkMfO7d7ypb4Joorj51XAfBdlQeIYOc57Lg+kesA3GNuTLfGzQ3BQHhyzTAGhtnYnQb6SyDxe4mpSUC1hVFd0qQziAlrN9axYTjpnkSd5BQ3Jf7Gbp2UY/GTz5KunV1K1g8I104inycVT3yiexURHR4QHjb3JF1E41jZeyoajB/kqSTdDieMi6rHl2U1hvQeEu5qCj855fqJEvGJDPFjAeHwns90r5pqPkwULQFdC1LP8xj5FIt21t2r5yr0+Fgh8Gj6AfuYJW+ADVXGvzbWR9VfF44B4Gk6stAvMzSZaP0IoBPn2fFOyo2w03HXbeQGxynlrWOi0g0nzX9iSzB7svDkJ7pXduRwKBGWJe5Xj0Uy3lffdIJNupTWspTKldhr1dqwaEGMPSuR5bf7IB4ughsCqDDPvr5hmv1JwE2Fdjqq5zPzV071+G8Krjux+2kAy+1Zz43NjaJLw8kuXR5bip4S3iW+S26Mor/gafIeHANAb46LImKU+qcumFyeMO80dt0VVc79i867IYRL1396eUUtpRg6AXduQX5PGu77WPdgyHgXg6424yPHQYx5WnhgParWZFxFvEqJNgDzGifxAJbVB060yw7dDQVTXNir6yFOe/DsrT9pOxYEhNvth9OQGDuSD7AJ+TXnGsi/NWO7Ky1uSEFWycb6G+m47r97Q5TSoPy+Pn4jqRu7GBskY/q0ISM0BI1Cd+ozcMfE2Lb14Znzu4cBnCmNQNo9j3VsGtETE7NVjYytSCmWILplaNR+Xs3AmSs/1z3lO/s2F0LGX+wzyTHgUeh2uTR6miy4uQVg43A4qv66cEMA423LLK7IEN+/sgrpdthuoDiWEUGKmyJ8UEMz6WZZUrTNVj8zhNTXHL1SsfxTkREA+Jp0V68ZmtPZTgDY31VoJY6pUX2ggTxxwy7EPLwGwJnPv4qUHwBaAlpuZNOW2vRQTpxnR9kseQfS9AtNju/tq9pNp+ivyyR7GRBmHVhd3HgpEe3v8RbgpFWTMag7TG72XrRA0q2V1aU9tLOjil5nPDj5LN6yKH2me5iZzgBIvMjRdcPRYIwbGwrFPyIxupbHqZapbBEkp34af6np9RkAfgbQGav+89Wl/AAwEvJjOmSybl/mQUSYJumaLMKHhi6aGuU0/kb0p9YMo5n+qicYJbQB6ClX2wk8Qz14o9bZrYlZbmUUrzBmpyP2tlYxc1OaeyJHjdRSRSpdbrQkouGx/7TxKwsrPts9DOA9AC1zafLNPGrIJNUdPbe2rpDqaco8SwM6bDo59JSrLyPgPasvevUpPwBkCCEBA3p8pPw6q1l2DkDQWci3Ewbbo9koZyaLjKa/PKOnXG1XxQPR9CxmLLIeIhCujdq5919v6Nob4LcT4Rcg1BKZSOshCAOTjXaznqpAMqMJMX5xT0JEib/3EbBNNqBX3Pr/WNH72e7adtPxIYBXqUGwl5fMH6WdI/fXB2weETvnOaXNlHNp10r8UXT9IOBKdxed8eJ/dW/1u/smivZsUMkG2I4I7yHgNgD6Xu1XibtjCvsX7ZEu/8kQO1FuOEO4KSC89b/e0LV3M/2Nw4BFpH/tShiAYiHXR4SHo5c6pP8BhPWV8DoCHZjN4IJ8BjsERP9GoNsZVEnPaFp3AncGScIhEg2D6JGA6PyWgHbOBnQagC4Gfj8ScjtepXjN/+3L/msAPyWiucZFl2NkZ+qtzDM5551XWGl+xn/UgEZOPdkmUXKlgJxrh0z558u4dp/LnuuY6vGcLGwcCdtrIX4LoLM1Q6flMrQTEc4l0IPxE6o21Es79X+S5pwk6JDNmfkrRHRbhujMjlbs0JrFBQFhvw3V8LrR9JcIDxcLuT51iZQcgAvh4BOwcSTcNWT8x0gNf6/UcR2APAOnEHhxQPg0AU8QMJzIESSe9nOOLfeRQgKVCPR/ACwF8HpmrKqF/K1ayM8CuIwZB4dTzf1JQvHLfa1Dw/gJM45R45PwHJHy3fXgpcfvfFr1ndVEizNuvaQdSph7WTRkftuql/nK7f93X+tUj+tkIH7F2mHMuKJa596ROv8/MFYBfDSAfQKiiwj0DEC1pvJvLftRyjkME+GRTIDziHgxgFNAaN84jOsqI/hHLcTnKzXeNdlDW39dHU++D0BvBJHPgTvPohu38YiQ+XKAnwPoOwBWZgIcFQRYSsT/B1BZesedtL6b9hi8EsB/B4TDswHtD+ABABcCeJbBP2XmNzNzq3JrAuDgqRaAzY1Fl/S1EvATEJ/quvj6VVyxix1v7LC+uyEAIRkKWO2l/Mk2Usu7bYtrJ8KOaBY7lYAfLf5K36vOY8sE2E+48PkQ/DYGrgPQQ8AFAeHBfJYOzBAOJcI3AcSzr73qle7eM0BYHgD/O5vBPlnC0QBWEuhbDH4+DPkKBh9pxnt0/XVhPwvA0NlM8xvk4ie4Qci4C4dROrmVwW8OmX9aD/GPeojzmemeXIb2zwR0OIG+SUTpWz6J+gn0QwK9NSDsCeAnIeOkGvPjIfhmMJ8K5k5dXF4b6J5qAdic2PfyvhkAfx/gk9XMbEZeDJk4Z8/a0lMwdPlOf1U47We/rOSTclXlLG/9WIZxNcx1SDh7JLwDAsCnVkZw7R6X9r2qwoEwxIJkTosBoIuZ310L+deVGj8eMk4B8NOWgPYMCG8C0Q9AZG2GEinulQHRN7IBvW5aa7AUwH31Os6vMf4RhriOwW8D0CrlQ/NhFP11f+LMVmfhOzKEQIlzGScWtX/vHGDmToDfS+BfV+v8eBjiPUT4eUuG9iSi4wi4GoTlINxCwHsyhN0DwuUAXs9MDwD4K4B/Z+a5WppIXkl+w1FTLQCbC/t9o3fu0AiuI8K7jWKpWBxmHKwwQMTkQGzB5bGIzylen9HxIJwYEeJFroZu8gIARH19ZetFF+bJTdcgEQj1kI8dHMZv976sb85Uj/dmxOFSCZNxF4GZ5zFwDjP+Wgv5AQCHZwiXtQb0moDoNAL9gkDLieiHAeGtbS20Z0C4MWS8a+Nw+CQDv2bg/czcZWuwHHv7oaRG+utG+W4I8DvW7l90QmYSiVIsnXQ95fP60cdcBn8wZPxxuM73gLEUoEsJtHcAOheg2XXGzSHjPmb+JIMXyfcA6KypWQWA/S35hpNXInb/Wl/34Aj+GDL0Vmzt6lvut/k5LBUGaPdfz7bmvHTZARgjIMq4WWe7jlxNSK9vjiGMiOoTm3uIjUst5EM2VPmPO1/S92rx3t7obt7Ra/wswrZIrgMG7xIyf7Ye4qGRkH8FYHZAOC8IsCcRLmXGvkM1vqfO+HPI+CjA8wxfSG6fgRWqkdGOUfT3d7LzrgHYqK26vpDI+DKhuzMbvYLYsngu3AQHBwB2YfB/MvgBAM+GwOMMvhSMAxjcKv3J5NqnIAg6M88+8YYVS6ZaAjYFe1zWNw/ArQzsZrxqM4uaF6KahF0y968y89C80nwjyUNAZvitOsLTMDThdZFd1mT9xfVVWXGceDkWAcy0R8h866JLeueNNj5bM068vnePEJhnxWKCR4JrkDN0rLytDD4oZFweMh4PGT0h4yEGf4GZdwU4SNu4Y2I8e2S3acuguzOL0fQXjI2yOXsVIL6e/oQ6ZjBFliQbEPaZ2yp7A0vhyWa4aF2VyzJ4Nhh5e7AYScMhG2LYz0vrzzO3MN83G/a8vG8uRc8zLCIxfubHWGwF1MqmZ1tRXoZJIu4nSbfaTjlHdtvqXCDbJ1jyro2AaAvaE0DCwIiQcRFAd+zylb65U82HCYNwhsn/Cadb+top8iv3uEbFuR3McwG0kqPYJL9Z46dHHwBh6bxc9EvBo+iv+0SwnQQk3C+3EQJR5chsm5qtGdIuaNpmFPel1aa74jxJa6Puz82MxnQS9QU93tz4gdNv6uuaalkYLw74Zu+RAXAPiIsy206OW0eUdLfNexPYUjQTCrBRSuWewyhlIOqY3/ETZa3f4BPhhXVdWGXVdXUYoj+dlQGy7q1IhHv2vqzvjVPNj/Hifb94rjNkfJBZjIUr92Tk23bZYcm/8ezMyomZEFX4laJfQm4yQXyFUfSXAOvFuc47AbFSW2wWs4xmOsWCkeb2Q9xo8pxtz1SHnB1/Oqmh7CALGuS0h2i4GMzcPlznj06VIEwE+36z7/iREL8FuFu6xmYmtcdSliFHGS1Fs7wBaRzUd7kywLqNgDj+I/2LPlpJoQyG+PUmt32t3GQZI/eeLO9D3xd3D9f5V7tf2nf8VPNlPBgcCc8CeAYgN/fZHJGr7hwz0N68xQ6vbflWBj2RuofUSwgDLcK0BvoLhvUOBncVYB0z+kWPRNeMDWvJwLkRu6zc9EN2+46VE8GSHinpJbhulKDreBcAcPbJN/Ru9ZnlA77dmz3w273/ScC1IGq1Ym8Ys2fid0KqC59yHiQ44sb4SGsnPQcgywfu9SB/otvOK9grCfY1NAvdPIOp1wria5dc3vufe1/em53A0G5RnLKsd3YInJuY7shOwpF292PEyWzj9aZNl9KLIKd5W79k5mXxrBZd265q9JeBfhDWyTYtA1As5FYDvAaOwSHn+3475BosR8mCaVsYk4sTCbpceGb7ZtUylNsjZsxi4KLNx+LNj0O+0zcDwOUh0+cR/VqrsH0yCefMmOSy2o3h5Qxvvqf9Xp8JA1jM9K7isigLoeRmttchBNz6Ka8icQyIPfsL8STK1xmfB3DFQd/qnTHV/GqGWogLmTHHSoqSkE+h2NZ2avUbguTIv2a8yYPZeSClbGLcRQu5DGFBocWMZwP9JWBNpOMGyReCEP0p7ZdFzMMFwKJtWtDRqhRWxiUKRoDsnU2ERBzTgB7FLg5dvUNeW1HzFzJ/4ORlvVtlLHnYlX0L6ow7iOijMqa3lsis1JCzO8+J9dOW4AIds5Ol6Kq+/rFOl55oW/xop1b2RgbDrh+kttuk/3Is9DInPlyt446Dvt23YKr5loaTl/UeycBZtlwqeSQkZNN66IocfYm/s/okK2eS3NmpYOeJclnCttMCseCXrr8AEr+0lHyilvlZ5V6b2CKe35UCErDnnFZYG0ZcX1911Dovj133Rt0YTJt2TYBEFlO6INFfa53xnVNu7F0wZdKRgkOv7D22HvLfAF4iZ3zt1WiXGpYSmuU6WLG17bLbWXnSsbxdJkgorlJ0182XCUI3BLHrm7oklB9W29aGIaT0H27bipe0pBby3w78du/xU80/iXfd1DevFuJKgPOufLrya8JhccZ6CSgliiY2+TT8agaLAOw5J5fQz3T95Wfde0o+C0C4hUAVvZ1QuOTa5QPhgB3VKp505rQVF+csztq3oWJEQdc36CRVKM5k2pmFhFO5oBbiWyfe0JufXFEYHUf9oLfz0Ct7L2PQjQB16hdyQMzAMMIfKbmgQ9ChlIiF0nA8U7tGwFYoqfxBnAgKyDYo6qe5A7nTj8zPfgdOfbt9thKHpr/2/akXUlj3R0aCrPuLhrCTGTcc+O3eyw79bm/nVPPzhBtW5Cs1/hbAxTjshCXfMu9FZIWv6pOFwY/gyLcV4ysldgJAHRay1oUD5uUS+pmivxUm3OLeV8IALCzknwHzGu2NSwhLtLCrBVn3laJucKLdWMBeIoloydckyW1O9i41ExKYAdAJF6s+H8PAT09c1jtlT58d+YO+g2qMO4hwDgFZyVeZ4kBKzGznAFQWHpbCmonSdf8b5QGkMsOpI/6CFBrgGAt5nu36bhlrOdH+g6BbcmqXyYJwTi3Enw/9bu9BU8XPE5f1toLxEwDH6pPxurrJ98vkdnRvrnzrnbRCvvU5mdyG0Rdy6rt+cUsG2CmO/53UmKNuvGZhIf+Me2+pL9Vh0P2yQfdZB2agqy2DpTvkrOuZu7ffV2puTJ1V8RDsC5Cgy0SKmC0i70AlE1XrLK5PIPA7mfm6E5dt2Yzy0T/snXHUVb1fZeAOgPaC1SvLv0F64i8lU++4/kETegDSyqsNQiDj72TCLxBhQ6DbN/sFgkAaE0qpI40GObmCtNBFzFQpdCMW1n7CJSHjjkOv7L3k9d/r3aIPE73z+t5syPxTJjpRSaPl6cbKrO7JlW81OVnyq5ZMoVo0q2KUIv/Wqhns8Vu6Qw6FtozVZ/MGIHOsddpBg7dq8V/dBEQiIUGMxbNatSWXULNb0u0369Vy558eHJUMUWVjyWBB1z9+yOntm/M4HsDN77pp8h88Ofbq3uzRP+o9noGHGPgkgFZ3f7zrLSbX8d2Axq6fnEVlpj5tJo4VFLGSBiKh19CQmPX+QHsEKmSQ+QX7mkGD67vfA+lRoMn9izEz36mVQZ8KgceP+H7v8W/+Ud+kG/f33fzcLAA3AnSimuWV/OrfWhDP8LOTDNQTng4XxH4JueIV1zdL5NLIiKVcNdGR8Sx23qY1VT9Tjv+ado/pBoDoFqg3/DT6Y2D/eTno/cpimci0o+5P+MDpF4yZreylAEP/ool8z5ndXTNnOORjKnW+76RlvYdMlpC86ce9+w6HuBXAzwEskgKtb0AxTyiZcXtVXO1u2pHKYdPt2deur2dnOIZAKmFgGwIZ67vhhDYagTlvXR9N+k8ib6BnybQVgZT6WmrYEn4GFjDw85E633rUVb37TRZfT76h96CBangfhNuv5+xELtvIZyqIZGGbJOlajkWzrv7IiYOA/XfIoZF+iuNKpNNIv34aevor94DoIGP51DeY70z44h39WP7ScCJGdWcFNdNbzLVmBHXA1uCSti/KpWq0SUEZBzb3r8AYDoi+CeALN5w0f92mCseJP+vNbqxhCRjnhsynR7svSa8GxW+JgfopbP0rvQyE4hd0rWMAoSof093jqIxd322fIX+h19DV0ACkuehutLSFMqIYb0yMsrNPADCeAUAO743xk2FE4hjmOFHfWmaUxgJhAFwfBLh0eis9cuNpm/7uwRNv6J0B4MIw5HNAEHkkpeRsjZsZK5UYtEdTvhk45gJUMf3Jgq5f4gHzqfkc05kQAti5qxWfPqyrsX6agOLehYXca9Put4kBqH6CCJeONmB3PjuEq/62XguEvUnENgp6OylglYH+ZMuKSroeIrI2CRs6G4HVxg/aHiisYsZl2QA/vu7E+WvGKxzHX7uicySkIwCcz4yDmBHYTFI/oW0YZhQ5jak2LXToVj1RP0w5536HOCeGx8kLNblZMuNG7jGJcy6vU/ielgTUCh1AyI6g0VjaFIaAcG9AuCJL+N2v3j1+I3/KDX2zhkN+LwHngjBP3rcYMRj1soZKK7dRZHGeIZSf9JYWJPgj5Efxx+KvlC/gffvMxCHz20a9N2act7Ar97UGbE5HqVwtAvg7gKbZ9JE64z/+9BLWbqwnYz+kGQFbiBzvx1Z4VwgdQWSnfNoyrHs+Zkg/mH9DAV0bEB6+/sT51u4oiRNv6Ju1bXu2f9X6kY+GjAtDxhwgXZkhjiMvgBoqftJTSDcUjYyARUsTFth9sj4t6WguEVLp3c8EP1OMQSPlT6MFTv2gQT3pSQZkZCIusypD+NLibXLf7F0/3HXjKd39jXh7yrK+2bWQ9w0Zp4BwDBizXWPXaDzSDYAY1lQD4Hym8IcbHLvft52WweePnIVs0FCFFYYBvKZYyKX+iE7T2qX+6n0AHyATm2bqNTd23RMD+OPyjcJNMy5jECQFxriTSYFSBPe77KjFnLEagAbuLoPWAVhLwMMhsBKx+0xEs0LGwYjWoy8PCH+oh3wrAx0JhU9lkrLktgtv3H7Xc5DK7oYT7JQn55qcuLbsm3IrjbDZbJfvijPZajGUavlV84McvrlGP7lByaXbys2JjUS20jtJUJ0T4bRJZqAlQ4fWoxeqnk2E/oBwNwP9ygnPBDSHGfuBMBvgLnlvauZODefl5MNyvIRcOQLmGt00D8yVJVeuwEk5O3rRNJyw23Sr32n6CdD9xa7cgWiAUTKpfBkTrpUywUJ51bmD5uXx194hVGoh5G4mS9GtZpMzPUR7KTJoMWFCSOYF1JdOBjoZWCQHj5nFeNJFzHiQiM5kxrUAB3ohwrmGeQRCxdnq11rV4KlMsDvU0TJeKDK8QGRQGZEhMBLKCUFTHVD7I6Q8sO4XgeP1actWWhbVXN+d/XX2GnaYB6HY9lOCrnKa1QTLIOhyQrEdmq2hyevHHQyDAGcw0AXgIoBbAcxmxq7yhkK270/ywmJLiqypsbQMhOWS2jwlso2D5S2QKMPiFNtNs/xCQHtLgAN2aNNtN9VP5svQBM1/XIdoGTGtNi/iMLuMOJYsYsL8zix2m92q0iTJKTrmkvsgj3zfvP2oiLlrkm3E5Zmd9kUZvS2ZDV2+wUb1X0onuf20RpAAIMvga7MBniDg6+b2TH3rPfkOE1K3vUJ9d7f1OnsBoLbzkrXWbtbt5V9cR2XsA1NXPsqt6Gn1rZWAgBAEyS3F1nMHzeoTOWXEzkVqcv9wxgdi/BR/xDKaGX98PSDcHzKuA7jVki9LBm3+2luzyYhfQi7VekRS/qxy2oY6dC0v0K1bZYQ1JUl3ZGy3bXPYcWZW618T/VwNSv661JgNQLGQq4GwTG0xNg8VRJ2Sc80Ju3fEHWfR2ZSHhMgwDi5dPzhh6kMuqVnrrDFd+0aAeZ+gYoSgx9fXL0jQMYyZDayHNvS0qTcZddZCfL8lwCVEdK9ZmjKzuXlltjJEZhekdpX1shmJY+EKi/pJN9es07uzpVrqU8/1q2y6XrILxJIeETIB4YMHdeBDB3UgCOz2jUKL9gPTP2UUgiBtbwALpW9CV+NneQMp94c0Oqz6Mf/ubcvSV+shfgpgVpp8GXmKFUd5U0I+AdM/JF6lLeQ/bl+uwEDKj/CmyGmfkZR/ktfXhohhrYrFY/GO3aZb+tdIP0FYVizkmq6MjGUzxWUE/jAIWR1Hq04ZzcS27RkcvlMb7lwxZGqSsGaqgtQ/6S2Qnnsdl1RcJ/Z5rBlYQD6FEF2KZBd1Q8K1h33CeA9EgnWmwkF1xiUA3g7CA2BaILvHwicj2R6Q4uNJWixc8akA8VKPdXvSL2So5yK07XME3d0gTap9jozFJw6bgTcujh6Z2KY9wKV3rkcYivbt0YS9/qyMtLkl6bbrvQ1KBLTyCkNgeTqGHlUy1yfBwERYEPcwIKxpCXBCNeTzQTgEDj1Nnkgew6azqsPmHiN7INrjuIfCYSX5vi1R3m1f5w3U0jYbebTCgVieZH8OW9CObdoC2GGkHVvE+lkDqKn7D4wWAgAoFnIlMP1GejRSbrUiEXDY/HbMzAXGcqsSpBioLK72UTRjpShbNJE+IbcNh+7+s7J/ajYnm2YssDyWfbPpIfP7A8J7AZxBxANmf7fpX/KVTdLoSSWApQR2IsxJjMEu5+6zsLcAi40/gU1ryRDOjZVf3eUbF7fh3MNmoCVLorzwLEQb5nkBk4U3HoTsS/pzAmYFgE3WX8qWvld2xguGj4KXRKgwcEoIHMGMTzR9NR05/JX8EXWSv4sIcT2XJuSDlCkWv4Mp5V/KNyfls+Er9uL6M/IBDulusxKPUjot/WT6TaPM/7gMQNz+eRQ/IQiYvitjzcwgBubNyOK413SoOvpD7xYURsuevM1cbXsWcnZLeZxIjyPb1lfIinKNkEKPxgnx89hk9dn+NFkfIiBkXETEIYE+B5gZDUKgyRJuThFkdUmzsQUpymJc8UYP8NgbZ9z9+XJjTWuG8PFDZuCNu+QT/HvzLnn8+yEz0JJxnicICHLnn9V+vFU4fauyyTPI2V/Wh3N/lqHT42g2Clnbp7W3hM9nAwyGzN+yVissORP7SyRRy6PI3pFTRtGZbHtAMG+1Y0F3ZZuU0y/kQ95fLB/S37IS5LqjhGMXd2CHGdmG+qf1E1QB4TyMAWPaT10s5JaXytXbQHSM6qDMPqpxIAD7zc3jvpVDWN4/bN2J9cCDYIrxJlRYYc7YWytNWiZBZzWIpr6K9bXHLThH6nryRtg8UMS6khAKvSpAIMIMgG4AYfcAtGfI+ICaSdj4d4n+aR8f5rqKBIpWAeRlpWwGMC6jFA527kx/j11JVSYbED7y2ul48+I22azFv4jGuO6RjXhxILSMsRobrUdSX/Q5k0BNKDMZujSEluFTYYEoY20hjq9hPEpaBsJ3Q8atADpVH4y8iUnF5HLMsStf1uyTLn9apoRSS/mKnhOADpO0eEnrIJnOdvtWfSZtZHbuasXSuW2aB430D1HTtxW7cssxBtBYCgFAqVzdBcDfAIz6+24PPD+EHz/6cizMbDEWiqkOo+TNSOZB0sVgkaQ7U7dmDjt0VcOa8dmO1dj2ONTuLBWLyfoM3B8Ab4l/HfYAe92djPehvkPmJZPnYNHTv+syzqc8D+dz7+1bcMyu7Xjt/LG9JqFSY1zy53V4cKX947ZuAt3imXTXxScSCp0MaZqXcZb89Dl6DMDrM4RvMXCqfX0jMyTyCUZMbPlJ7uGXM3L88E8anQyvLVNhWXGTj9EizLZ8me+O/MTfiQjv2WtmbABGxSCAfYqF3DNjKTxmAwAApf7qVQC/X2Yq7Fs11ugPPRvxq39ssK29ZiKZ2FpMamb2ENOXoJkJ0FyfZAHVB5lJkR9WYbZ3a1n8NfvrRRP2vm69356+kglwVa3O93C0aQhq84+q4yqm2SSURjeGQyq5Dh1T6EawDF3d37475PDpIzqRy8hZozn/QIRqjfHlP6/DQ89XnbAt5oDgn81HMjO3UGij5Em6rm95AeLhIKs+QKD1AeFoCnAEMy5JylLsq8lrS1kiAnFE14s9lqylSoUxeoifp4iLqcnJrMEL/qdqki0fNv+S9Lcvno6jdpomdKQZ/+iHxa7cGRgjxpYDMP2+mIEBHfJYARkJS0nYf4e2+DlliofEcEENmDki00Zi1NSSmlkBNo0YumrfuPya27pvTl47Ud+lG5eRTD/c/hE+GYbYDUQnEaiWmK1S+pdM7Mm1cPdpOSBw6IF4Os/E+TadKFL+C17fiVzW5s9o/GMGWrPAZ4/sxL475Jz9AOodAc5ThGi09JfsX/LxZcEDufSntU6sgxMhIPwvENqZ1Ytg0/aYmC9ynZ9gK7yRSyOfMqEGcd2E/DB02/o67MifkF85S5lJz9YPazIE0NmWwdLt23QfRuHfAAgXj0elx2UAioXcciK6UFvqNKWJLXxXWwb/fmAXZuTMJQxDYQ+I+015ASLmtNoXipXQ6fj6Rukdsu5xsr52FskIhps7kvTYIAQM/CgbYD0IXzQzoGnfdoldI+CGR7bABW55S1nkBiDbWOwzN4fPvL4TLZl0/ozGPwKhJUOREZjbmmjf/lQ025gFup8O3blH2+035fW8oMQlEthvEOF3RPgJwO1JD1LxTPBfliGHv44AkqyfJn9CPt0H16zxI6d9R761wRBqIOUDRJiRy+DjB3RZL/wYhX8XFgtji/0VxucBRPgxgEes3x4HO5/R+VntWRy7uAPCrkI4OdanMZvC502pp9t360NlQp0AWUdgymUSPy0qP0kl+Zzrs11f/iqPuH5HPcSVBFxBhN/o/ih67NaY+NR1cdn5hJgl7efkdcY8ULOs8x4AYuwztxWfPiJS/mb8GY1/DKAlAD7z+k7su0NrdG1xXflp3hyU7Fdq/8U46vuF8Q7keInju1uzdDEDNzNjnt4sRkl5Mi+pcT4dOWPBJ81/LSn2MYl60CEgJ+TbqiflhOx+KDmkBvJ+7OLp2KYtMyb+AXgk1s1xgcZbAQB6+iuHgej3BOisEnNaMgWoM+Mnj67DI6srkDN60jLLxAoScZtM1sj0AAm6rpASeOkdgiZ8smInmZZnpw31wA0Eq5NP2DEIdEvIeB+AvzBjNzt2N8nGZE7A5AbUWOprWDkFMn1RdQCds5jeGuCQBW04Za+OyO2X99+AP2OlV2uMnz06gDtXDGFDNZQecsxXsZTrxuSklgLJKL2c/FRoYNVxQinC2myApSHjbACfSOQe5PWlbJHhmkk8G/6zlrNkshiiHKXIj6Sr+ponKfKn1x9cmxSflKZkyXZ5vHuvmfpXuJrxh4EKmN+0sCt/J8aJCRkAACiVq19l8CfFUCYiaGXj6iFw9WMv49HVQ4Ixpk7SGKgT9lCq5Q8AeiunEcK0W0tPBJq8sFEkd0RZcNpO0NiJGsdZAIheQ4yLQuBU+8UcjuGI25fKn0gUSkVPZPpt+vRcgE8dVsBOXVmtBmb2as6f8dBL/TV8+fYy1lfNNug0/lHMP0eJnVDHNhR2ws+mZ4h+QIRLQsaTRJw1RkfKTPL6qvdSTqRRgjgvRUcl8hITjZ5j5KJrQtSi8aPESVHeSRSKokvmtOH0PWbqJ2lH4w+B/m+xkDsfE8BEQoC4p3wxMa2Vw2HuwygXAGQC4PQ9Z2LbaVmLW7byy5yAmMk1jwjRww+AjHuMchDUZgyZjNF7gFTMJuiSMfr6LK5vjbeVPdCJHNNrK+bcVfdbxpaQ8ZuhKyUJkFQGO/aW300ibUY+Uv5iV1bfjW3ZGvAHGCBgYDT+SfpOXVl85ogCZubJPHQk+me/PNTJXcAop/UWIHHeKL89PgGhyECgld9mDeyYPRmbq6SCmXykLBtpVP87jwBoupE1IV9s2ldX1UrNsidGvlwxUzmv2dOyOHX3mcgEGJ1/DBDTWjCPK/EnMWEDUOzKrwPh7WCsJ+Xi6kFis2mFI0PcEgBvWtiBlkDNrNL6qmUVGScZulmWkVMtizDBbpPFd2NqTB04dNLW1Lm+ZfYlN9nxTuzZgMGdsGan2IJbcS/bxiHe4pr6gk/hYruv1JpfaMGnDo1m/mbj7/IHTAMEejtAbwdjYDT+SfpOhSw+fXgBCwotQrnth5Dc/tu/KeA8F0Aq1nfzAWa2DoG51lhb3oU5Z9RLzMXUmP/GNRDbymO6bTzEOVZbhoV8WXXch5DI9IlMfVt6GNkMcHSxA9kAo/IvDhfXg/D2Yld+3UT1eOIeAIBiIXcvgb4BovixRMTrq7El1wuj0RDsu30ep+w+E9lM0oJbc39KdtWCqMB28VgokrGgbYzN9aWTqwtR2gxj2jKZWjN7xcZosCXAIKLJLyWscWY6EnXFbYlZz/ICzNOBUeb/nbt34Atv6MJOXS2jj79NHwDhuGIhd3uxkLudiI4j0MA46mOnrhZcfPQ2OHGPjuTTftrTkUbAKHZgHTvGLjYoydCC87kMDQaEwVT+WLwQ13fLsfFGlAAkFpMcgSLjXMYzt+OMCxqr/kNcn3RT+vpSPkHRTs2Td5uJfebkxzT+ceVvFAu5e0fT02bYJAMQ38WXGLzM+MPq5tQMLe6ejBHIBGLtVj+ia4+WeY5f0OXg6qWYJB0w9aULZbvfym2PswLCVTWuaNQ/Eu2bnkbSIRKEfdNzmZXJpSbTvhZONXM5CTLzmf70XADC7I4AJ+4xHcfuOs0Z39HGHwDRw2AcXSzkblPjVCzkbgPjaAIeHkN9TScCjnvNNJy8Zwe2m5414ycUOZDjaim58Ghkgs7lL1QugLBNe3YVgJW2Z6VmX4srhq69L7t9kCM/sOXHlhaxl9/pH6R8EIScwdwsp8inkgUQMgScsvtM7BOv949l/AFeRoQvbar6brIBKBZyg2CcCeZnyA6K7MwXc2S9AOw7J49Td58J63VmzvKMcftNllSV00MkkmjS/efYysoki1l0McF5Wn1A7RA01zduoymnnvc3vIm+//D4eaEMW4wxke4ptGAbnjrLX1ox7Nes7dSVxX8csQ2O2WWa8FrM+DYbfzAeAfCWYldy1ih25e4F4S3MeKQZ/9z2CYS3Lm7HRa/vQrGrxbxzQN2f+NP3AaV8Joyz3pmgBZ8tvbny2Lk1ADW4dDG+Fn9kGMgqYWrGPyXQN/cc19czewqdxbsmpHwpL8H6LUA2/FfypXYjnrL7TCzZLj8q/wT9GTDOLBZyg5uqv7SpDSiUytX9AP4jgE5tUIV/bU3y8X098mIF1zzxsmCUZRGMq8OSqYYuTIF9OyoDIy7oZgSk1TcvfTDty/3c7LSvH/5Q7+aDFoqn8xk6aqjGTzJzp+6ZXi0wV2ZR36wJk7BzDFm/JUNYOjePk/eYgWktNOr4SnrsfzzGhKMWFnJrm/Gxp1ydRYxbGbyXHo1R2lf0jSOM6x7fgAefr2CkzsYtB2At02lDp44F/8kur0aMiNZ25jOLX67W/gLQbtasrFcjpPcnvC7RUcHhJF31R8iPPTmQMbpwB8TN08tlP9G+4C8R4fQ9ZmKv7fLJ5hrzdx2Djl5YyD2IzYDNZgAAoFSuHsGMW0ENPIuknqFv3TD+vGIjnlpbMZ3SwRFb36Wnpl0rzRh2+CKWsUjU1805Iwy2JwR1TnBAZ3bj+trasypLTwF4DxgP6flAZX3l3m+KkzySDtZd1JlmRMmethbCv+3XicWzcs25ljK+8eE3i4Xcx8fJyysY+NhY2nfpT68dxn/fX8ZQTSXGCEgs2ZGj+DLpZjwkQ0ctQ1gaMl9LhN1c+bCSamntp9BT5UvfX1I+pGRI+VLSx7L9UeRr923zOGL+NOw4U7x0e/TxDYlwVLGQu308vGyGzWoAAKDUX/kUiL6EcYQXtZBxzRPr8OS/qnbnkoIMrRvujTAaIrUOu2x1yOzUF1/kse144jFmnAHgIYvGzidSjtn5jOmHLWjDKXvM0BtCxolhABcVC7kvT6RyqVz9DIDPY5RXw6ePH+PaxzfgjhWRl2pCoQhpIXEqXRwTsJQI32FgP9tYJL9TCk22B+c61jmkyAw3URY3DSFJnJSx3bfN4bTdO8fySm+JkJkvWNiV/8p4edEMm54EdFDsyn8F4AuhXmQ7BmQDwmm7d2Kv2XnkMoZTVuYe+nQ6qPH5RJYXSQEDRCYX9klK60jKNQPCKhLbDFOF3TnvZv7VuTkdGfz7QQWcusfMiSp/PwPvmKjyA0CxkPsyA+8A0D/eukSE0/aagXNeW8D20zMNVgXs3Jak6+HVx5EGBoTVmkgJA2HVs5DGR0ry3DUYsmwzz6eRIZGfuQxhr9l5nDoB5Qf4ws2t/Gm3udnQU65+hsAXQxsZ22VKU21mxgsDNVz1aBkbhkOHCsvFShhcHp2Jbqgvwz8GEg24Wz7ZLZ88/r/MuBZQIQCQ6gmktKNo2QA4eMd2vKE4DYU2aZ/HMH6KznQ/iE8oFvIrNwMrUSpX5oHpRiY+YEzXd+jloRB/7NmIv/YNohY6409JRUlZ0FHflxLhFACfSqsvz8n2VBlOuUYaRKhutetuIXcL6MfLU+RrRmuAM5YUsF1HdrzjFwJ04aYY8maYNAMAxC4k85f0qLqQGibo66t1PPjCEP5QGtDa4r7SiQHzKi9lgiWHdcaX7PqGLPy2xMbOuHsqEZeyjzuFzsAXAfycgQf09U1+IFlfJwKjdnbfNodjdu7AvBlZvfyYNj7Nxo+ZfwCijyws5IaxGdFTrraC+f8R0QdG418anQGsXF/Dr58ZwBNrqnGVOBEnplBbQW06AUtBfAKBPqtaNVt+KcWri/nb4JVbzKyVzZKPFLqp5PAvpb4x/tH5NxenY585eczI2T/jPabxI7pgspTfHqtJQqlc/SyAi5lTbWp874QkHXhsTQV3PzeIvvUjIsWS0nFZ3/Xp4/bd6dz2BE0SzumaWD1weiDjetL7xr+YIXq2FvKV1sxOIokIbdP0985cBkcVp+G189qRdfZ/Nx6fBH0YhDMJdH1xMyu/4GUrg08G4/sAtY6zfwCAWgjcs3IQf+rZiHKlHs/YaUk8iNk9aiuXCd41Eoa7A/isLEvaCJtzLNqRM2oiv6cv2Fy+JP+sApwuXwAwv7MVB89rx56z21Loo/OXCBcWC7kvTgYvFSb9N9aZ8cU4PrtYcVQvabD6pRrBaEHfe3YbFm+Tw8+fXo9/9FdRqYVmsOSgM+vhJDkjqwwMS+EivQRj9glI42EsvrX2C2hmW9cnc30QwjpjvsVU4QdavgYRtpuWwSHd07B0+zzasoTxjo+iM6ME4O0LC/mnJpOXsWG5uqe/8jCIf0VMxbH0T9JbMsCh3dOw/9w2PPRCBXf2bsSLA7WYN2KUxPgq41ALeRER1fSTcYJ/RvmFxybpwjro90G6KVygoXxp8YjlSk8apDwF035blrBLVw7vWDwDrVkSCepx8fdCZkyq8pt7mmT0lKsBGAcT4VeIX96YujFAukGCzsxYNVDD/asGcf+qIV3HrBKn1E/GA9pN4xS62fwDfU15/cRwMevfAVDXzwZ09kjI2xHos8n3Cpr6bVnCWxZNxwE7tKEliJermtx/s/Fh8DfB+PTCrvwmbwoZF0/7K+0gXEKgj43Gv0Z0JsJInXH/80P4zT83YHBEKCrMOj9Yn/9ia4Z6R0J8R/JfzqR6mK3HZx266J+QoMQ+k/HKF4hw0Nx27D+3Ddt3ZO3rj3181jHj7SDcvbCQG3MifaLYIgZAoae/ehARvs/g3SbUAAMbhkP8rmcDHl9TQS2UMZRVzD7FozY7ppPciKz4BzqQmY8D4bPOxkYQEWa3Z3DgvHa8bsd2ZJpllcc2FqsJOK/Ylb9mE1rZZJT6q6cz+FJQ9KvJE7wXhAzc9dwg7n1uCC9urEGuu4nZ/YsE/JzBD0THpr4OF5wxbTrMNKZTqUQpY9kgyu6/eeF0dLQEE+YrgZ5ixpkLuzZtf//4rrmFUSpXOwH8GuCDAIojXpHMg8PVFDozsGpgBHev3IjH11QwUldF5ayt3CwVGMB6qYL28lSijgSd5bquocuXNhiYtwYDWArgJAY+o7rcGhD23i6PQ7rbk7NCg/sbhR4CuAXA2cVCbsWW5l8Dni4AcDmAt0Gv+kzs/hiE1RtGcNdzg3hw1VBk5M3zF18kwo2I91mo8EDP1U6yT7UtPQmZzIuWZaPNVkS2fBhREk9GOvLVkonC1IPntWNuR8tY+ZdGDwG6F8Bbi4Xcui3Juy1uABRK5cqXADoHQN5e/ogGh8VxIzqYsGG4jpXrR3DP84NYNTCCwZrSXkSCw8n6yqXXLzFl2wXUdOHCq/YkHbK9iL9LA6KL6szHLirksGROHrvNyqEjfi/ieO8vSUcfQGcWC7k/TRXfmvO0+gaAvw+ge2L3Z9MHqiGeWlvFo6sr6H15BHXm6+OfZnuomYvPLJ8nsPltlYcw/IK/7tZzk8shtLcQ5k5vwcE7tGOH6S2YnsvY7Y2fvxWAv14s5C+YCp5NmQEAgJ5y5QgC3cDgWY2iq/EcV2uMR9ZU8Oy6YSwvV7FxJDQFmsFtUJ4XiwONmmEGpucyYUtA+y/ZLv+dnQqt+y0stOqM/kTvRxwPEOhqBs5fWMgNTDJbNgk95WoHAV9l8LsJ6NhM94/1lRDPb6jd/at/rv9f1Ro/tGG4nrqVptH6PslPck424n+MjpYMdu5qxYLOVizZrg0tmU2/nzjpt5bBJy0s5G+fTJ40w5QaAAAolauzAb4CoJPl4Ii19dTBa0YHA5VaiEfXVPDEvyp4uVrH2sGaaEBk8CG+i3hdzSLy1VvmGgQQY9u2LDrzGew5O4+9t8sjnw2eZmABxV7NRPvv0P9AjAuLXZvn4Y8txtf+6n4cvaL6jZt4/5JeAbCiUgt3ffTFCh5fU8G6Sh1rNspVhJineg+uTLIqqloJiMsK/quGZrVl0JnPYI9t89gr4q3lxG8qfwG+HqCPFwu5NVPJpyk3AADQU65mwXgzES4B4CQIRzHPo9CZGSEDLwzU8M9yVTP5+Q0jeHbdcPzAimkprfn2FkKxM4ftp5tV08Xb5LB9R9a8+WOC/WtC7wPwhWIh973JGfUtg1J/5YMg+hyA7s08PgCAkBmrB2p4em1VF3thoIaechWDI2J5L/ElQluWsLDQGsfwEXbRvKVRrz8B+lPM+DQIv1s4yk93bwlsFQZAoVSuzADoLDB/gYG8PVGbmVi+Y2FT6IMjjOGQR+1Xa4bQng30rLK5rt+AvoKAL4HomuJW7u6Pna/VDgCng/kCBhZM8vgBFPNWGPdGkt4aRHE9TYJ8OfQKgM8B/N1iIb9+qnkyyrBMLUr9lV1AdCmAYwAEaq098Vpkk8p/5dMJfQRcDeDizfGih60RpXK1HcCFDLybgO6tavwnjx4C+A2Yzyt25cf0e31bElulAVAolSu7AHQtgH0tgozf0/DKoq8E8FWA/7tYyE/KFt6tDaVypRWgDwM4H8C8UcYHr2D6wwCfVixsfYqvsFUbAADo6a8GRHwIM70PwHuJkJWrqmo5qNGq61ZJZ4Qgvp9AN4Dx9WLX5O/42hpR6q8GIJzD4JPAdADFL5KZcv5sGr3GjB8T8Y+Y6a6FWzlvt3oDIFEqVxaB8TkG3kkULTEpNNpisZXRBxj4GYGuKhZyd0/1eG5NKJWrBzPzGUQ4lYGOrZR/jemMAQJuAuELxUJ+XL/PN5V4RRkAhXg34ZsBnAvwXgzKT0oefvPQBxH9btvlAH5XLOS2mgTQ1ohSuToDEW/PBrAEQPsU868JnSsAPcbAZRTxdt1Uj9948Yo0ABKl/souDBwL4CQiWgSgy+z8isqYjXzuzrDJomMtAc8w+AYiumW8v9jqEaFUri5i5rcR6CQQdgEwC9gS/GtK72fm5QBuIOCXW2Nibzx4xRsAiZ5ydTYBbwCwGMDbmHkJgMA8Dy5f3mF/biK9BsLTYL4NRH8FcFtxlLfveowPpXJ1FoAjwfw6EB0J8K5gym4m/jWjh0T0CKLnL/7BwJ8WTvHmnc2JV5UBcFEqVxYh2oByAICFAO3FjHkEnuveutgEhrQ3PAr6SgCrmPkRIjwL4F5m9C3sypem+n7/J6Gnv1IkQjeAg5ixExEtYea5RDRvFP414++qiL/8GIAeAPcD6HslxfTjxavaAKShp1yZAaYZIqPzztHqEOEuBiKrz7x+YdfWs5HDw6CnvzIDRDPizTizmXHIqJUIN5kgn9cv3Io26Xh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4vKLx/wH7i7/383nWsQAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAyMC0wMS0xOVQxNTozMDozMi0wNzowMMr/2j0AAAAldEVYdGRhdGU6bW9kaWZ5ADIwMjAtMDEtMTlUMTU6MzA6MzMtMDc6MDAd1Wk1AAAAAElFTkSuQmCC',
  `header_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.75' COMMENT 'store size for company_name & row_under_company_name by rem',
  `bill_number_date_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.1' COMMENT 'store size for bill_number & date by rem',
  `contact_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.5' COMMENT 'store size for row_contact1 & row_contact 2 by rem',
  `account_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.5' COMMENT 'store size for account data by rem',
  `table_header_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.4' COMMENT 'store size for table_header_size by rem',
  `table_body_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.3' COMMENT 'store size for table_body_size by rem',
  `table_footer_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.4' COMMENT 'store size for table_footer_size by rem',
  `message_uc_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'store size for message_uc_size by rem',
  `opacity_background` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT 'store opacity for background in bill',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bill_prints` (`id`, `name`, `company_name`, `row_under_company_name`, `row_contact1`, `row_contact2`, `use_small_size`, `small_size`, `icon`, `header_size`, `bill_number_date_size`, `contact_size`, `account_size`, `table_header_size`, `table_body_size`, `table_footer_size`, `message_uc_size`, `opacity_background`, `created_at`, `updated_at`) VALUES
(1,	'UltimateCode',	'شركة UltimateCode للبرمجيات ترحب بكم',	'سعداء بخدمتكم',	'إدارة : م/أحمد الغمرى : 01018030420',	'للتواصل مع خدمة العملاء : م/تامر عبدو : 01018030420',	0,	'6',	' data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAABmRklEQVR42u19e5wcRbX/9/TM7sxuNsnOEkIIYRMmgSDPQHiJvATxgQoob3wiylV/egERFblerj9/qOgPEVF/V1HxgSAQUBTfgoDIG+QtYnbILiGEGHZCstmd2Z3p8/uju6pOVffMPpLNBm5989nMdJ+q6uo6jzrnVHUP4OHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4TG5oKnuwJZEqb+SBdEcZgYRzQb4EGaACACoHYy3mJHhXwEY1nTGnSBaG1NXFwu52lTfj4dBqVzNApgTH85i5sOIgJh/rWB6uy5M+C0zDxo63QVgDQCAeXWxK/8/hrevWgNQKlfbAcxj4AAA8wAcTtHnHroQjzIajemPAVxhxs0gGgbzL0G0bmEht2aq7/t/Akrl6mwAnQwcC0YrER8HUB7AXlbBifH3CQArAdzBwEpi3A/CymIhNzjV9z0ZeFUZgJ7+yi4gOpaA1wFYwswLttS1CbSWiW8npr+C+JZiIb98qsfj1YSe/soiAr2NiV9HjCMYmLWlrk1EKwA8wsBfifmXxa78M1M9Hpvt3qa6A5uKUrm6G4AzwHwYCEvA1AoCmBkU3x7DfFd3Pcn0CjOvIqJfAri2WMjdP9Xj9EpEqVw9AMBpAB8Lxtx4lt8S/GtMJx4G4xEQ7gToqmIh99RUj9Om4BVpAErl6iIAxwI4l5lnESHPjIhJlMJQMKaKzkBIjD4GX06gXxa7cqWpHr+tGaX+apHBxxLR2QC6AQRTyb9R6BUAa8F8GYh+WSzkXnFe3yvKAJTK1UMY/CEwTgWoFcTxLXD0P0e3pJI7WyG9AqKHwXwZRQIzPNVjujWgp7/aCvCxIDoXjH2VQd8K+deETsMAfgbGlcWu3F1TPaZjxVZvAErlagDgSGZ8CeB9AQQEiq2wuQ0WGZ1XAh2Elcy4jAjXFwu5lVM9zlOBUrk6jxknA3wuogStHp+p5s8m0EOAHibCBQBuKxZy4VSPczNstQagp1zJEnAIQJcC2BdiiGVsZo5fsfQamL5JhMuKhVzfVI/7lkBPudINpnOJ+GMMZLdy/kyYDuBhgM8D6K6tddl4qzQApf7KEUz0JQIf1LirE1/D20rpFWb+HhF99dVqCErlajczn09EHwQ4P87xecXSmeleAi4oduVu3ywDuRmxVRmAnv7qPACfB/h0AFpA7HSMirrSb2IsdImBkRDL+4cxMBImCszIBVhYyGFaiz1Mm3r9UegDRPRjBr608FUSGvSUq/MIuICZ3wugY5LHT9M3jjB6ylWsrya98I7WADt3tWJaSzBp13foFQZdA+CihV1bD1+3CgNQKleyYPoYg88HYS6BEO/W02VY+1dRBnasdGbGUI2xYThET7mKJ/9VQbVm3LWXhuqo1kOA05hHaMsSCvmMPpPPBthzdh7FQitmtAbIZym+zsT614S+nkDngfCzYiE3MNU8mhhfqx1gnAriS5lpxmYeH4AIlVqI9dUQpfIwHn+xgqFaiDhZj/6hOoZqrDlKjrTnswG2aTO8zWUJe27bhoWFVkxvDZAXxmFz8ZcIq8D8VRB9c2sIC6bcAJTKldlg3AiiQ/RJpYkTPGZmvDBQw1P/quClSh09YobnRg0wNaQzO8dx+em5ALt0tWJmLoPdZ+eHd5zR8gcAbwAjvyn9t44ZKxj8oYVd+T9NNa/Gg1K5+gYwrgRhwaby0xzzamY8+PyG2hsfX1Npfbka4pmXqlhfrWtlI1mBnGMoI5C8AJnCABgdrRnsXGhFV1sGu2+bx5xpLcaAbI77Ad8FwgnFQn5Kd49OqQHo6a++E+DvENEsZplQUYhmajWTj0Z/YaCG3vXDuPf5QazdWAer9VvBOdWKVnU2bbIw08pkm/J2fV02LtTeEnxxcIR/csSCaX/ZZ05+1vYdLTo3PNb+N6GHAG4B4+PFrq07P1Dqr3aDcAWAt4E52Bz3DyK8sGEED64aWvGXvsGj21uC9wwM1//T6Gxci0wbOktPsk3lCZCYsqP2pfmPKrGuEhBhVnsGB8+bhh1ntCDi7bj4l04nrGXGvy3syt00VfyaEgNQKlc7Af4cQJ8QY6WsfDQbkzutp9NXbRjBk2srWPHyMHrXjSBke/q0lF1/F3SWGVybbmZ+pz5b7AeAu5nxFgJ+GwIHBwAWFlqx95w8dt82hxm5zITvz6EPAvgCgK8XC7nKVPCuCU/zAJ8D0OfAaJ/g/Vn0VRtqePzFKp5dN4zl/cOoMxAQbmPgHQHwKwYOixRcKJdol2Ce5DL+QUS3PQGZv4/OMSmO2/SAgJ06W7FgZgt22zaPuR0tE74/gNQM9DWAvlAs5NZtab5tcQNQKld2BegqAAdNtA1mxvrhEPesHMRfVm5EGLlUWpnF5gzrmJ1jo/zmvNrlpZRf5hLEDhCp/AMAdmfGhxj4D4vOhGwA7LxNDod0t2PXbVqtuHATcAuAjxcLuRVbmn9pKJWrC4B41t9EMAP/eKmKv71QwYMvDKEeCn7GYxcQLgLwQwCPAtyp+EJEjtI78kAyNldhgl3OGIDGcqTkJiDCYfOn4eB57ehozWyqMt0L8BnFQv7pLcm7LWoASuXqQWD8nsEzJtrGqg01/PHZDfhneRghy7VXAW5cnxuc4GZl2TmnjwkA3gFgMGT+vUvXdiku25YlnLTbDOw9J49gk0eeVoNwHgE/m6rNJqVyNWDwqWC6FOA5m9IWA3hkdQXXPbE+StxFM6Pmq7KbsVsfZgM6OmTMAPBzZcJJF3DkgZKCLttLyNA4eRMQYZdtcnjjTh3YviM74TEg0HoQ3lQs5O7dlLEc3zW3AErlSsCgc4jxOQCdkecjsqR6djW9knRmxsBIiF//cwP+vraC4TrrnqtJP80AuMsxTeyCBXaNQooBiOeLq1szdF6lHj4OxmxZnt22RJuzp2Xxuu52vHZeG3LZADTK/TcfH/4FmM4tdm1Zb6DUX10A4ssAOn40/jWjV2sceXK9g3hxIEqKO8qeMALRd1qdy9BrRkK+jMHvl8orZcE1DDL6IzLd2hyK0JoJsPu2Obx10fRoeXGM8u3Q1zHhCwT+erGQn3TDPukGoFSuAuDPguliJxeD0Y4ZwOqBETy8eggPrR5CpaZiccEyglyDEQ3IqM+hazcdor3YAZThhOKJTgiSsQCgZ/JZOnCwxteB+Y3RadWmCh/U5ez6qv/TWghv2bkDr92xHS0B2VnmMYyPvh3wKgLOLRby1082PyOeVk5m4DICzZ1QfxmohYy7nxvCr58ZwMBwPVZSk4zTWX0di8ccUnF0VPY3M3LBaRuG6/cB2FU8sQfSiUG7fuT1m1UCVV7x35WfiGUxnUVuwV0VMp1FPkvYf/s27DunDdt3tIx7fOLmLwTwxWIhN6m8nFQDUCpX28E4B4SL0+g6M5oSFw/XGX0vD+OaJ9dZa7mNR24cdJXEk1n/eMUgqiUNRVSfhVViUCUgvD5k7MfMV6gcgkksG0OiHiBR9ZltQ8IMzO7I4sidpmHf7fOY1hqMaXxS6MNg/hyIvj5ZDxmVytVWMJ/DRF8goHWc/QMAbBwO8fALFdzasxGrB2rqbUxx7I4UQwAdsxtPwPA3IPpIJsDDdcafAW53VwVUe7I+xMyrr0/SdEs3QciP4C8J+WAS8iXcjfYs4d17FDBvRgtaM8kxGm38AFyIKOE7aS8jmVQD0NNf+QmB3s1wN0XEx1qnpLsPVOshrnlyHf7ZXzWDb2VUTaLHSsxQE7qZLo0HIRJ21mYe5oipIhFouXDAuSFwO4C/MqM94VE4iUBm8+iI8ig4vr78nNWewYeWdmLHmdmG4zOG8buJCGdv7geMesrVeWC+nIje2ez6jfoHIjy3bgTfeXAd/rWxpjP2KsEmZ3yVyJOfap1ej6I6T7QewOEB4RBmvsKtJxOAcs526ca7kP2PyqU9HkxCfoBYXuCMB0f8XzyrFafv3olcNhiVfy6dwVcv7Mq/Z3PyUmLSDECpXL0CzB8FKHBpWledoJzBuO/5Ify5dwAvV0NIBTaG1WToZSZXJ39V5j6R+ZeLQ3Ymn+TszSIDbGX8VTP0hxA4DYw7AN7DKLBinrhurNgmBIjbV4YBbMrHDWQDwoHz2nD0wmnYriObyqBG4yfoTxNwdrGQ+8Nm4uUbGbicGLuO8fpmxQvAiwM1/GH5IO5+bgi1UCbsYlddueBiNrYMBLmzv00nwoMEHE2EnzJwjMzc6/a1R6+SRoa/6vrWbA+zm0AGdnKlwJ5gGtMZjJm5DI5c0IED57YbQzaG8QM4BNG3i4XcxzcHL11MigEolaufAXAxgGCsdUJm3Pv8IG755waEMqnXrIdpA0hJkjvY7FbnlGbTE4GrGLw/QJ9nxgftLL+TPGT70/ruJgY5Sc8GhLP2n4klc/KgCXCJmSsAnbCwK/eb8dc26OmvHkOEGyGezRhzHwA8+kIV375vHWpxOkvN8DrRR0bvCGh4vtGKgPoeEL4JwpcA3AdgXoPVA4iPxPkEsfEpfb5ZYtmlZQg4dpcZOHBu23iXg0MAFxYLuS+PlwejYbMbgJ7+yqcAfImIAmu3HGC5PSoTCkT78X/4aBkvDdUdWwpHocWOLTe9b0kJJxnDSNhyazMfw4oNWbYbxe3DBJzEQDszfsrgwFVyK/YX7Vq5hTgEcZVf5wpEmwER5s3M4pzXFjA9Rw3Hr8n4DhPRdyc6e5TK1SuY+SwArc34l3b99cMhLr2rjJUv11BnbqrkJGJ1GbvrOg1yA7INALVMQCcBqDFwI8CtSnzMte2p1xV+rZRk5MM2HHZuiaTxt+6f9eqUHbxGLWzTnsEZexes5xBGHV+iEMwXLOzKf2UivGyEzWoASuXquwH8iJmDREwjTLhcAnlpqIbvPNyPl6v1JEPUQDTqeCMXKu3OHA9AW282jGYndyhnboC+kSV8ayTEPQzuiu5D3U+DTyAxsyt6+nlyDEJ0bruODA5d0IZjdml3NrOMPr7x3d7CwBkLC7m1GAN6ytVZBFwF8NuskCq1ffv6zMCv/7ERd64YwuoNNRGrR0xJm/2NgrNUaL1Mp9hJsTZreuIcrc1laelIyOdGyWe22rLEgmwRUfx3ZY7YLqNodkbAlkmRKzRlHe9wZj6DjyztQldbdjzjGwJ4X7GQu3osfBwLNpsBKPVX9wPhjwx0jrVOeaiGbz/Yjw3DkX/Y1CtKGfFGxZUBcAdffZW5wkQ9x/WPyzzSmqG3VGt8HQOHqQKWoopzCbffCRPc87ZhoAbeAXDETm04cmEbume2jJtzFL3K/KhiId/UCJTKlVkA3cruK7bHgL51I7h1+RBu7Rlq6MJTw2O2jscSIjSg39bRGpy0cTj8Iwj7ajlpEEJA0CxFdiaDtJDUNQRSLuCUd2UNHD1u/tH9tkHB8QRG4eM6MI4uduUeHC9/GrS36SiVq7OY+R8EimZGK/Vmp1UU/aWhOr77cD/WVeoJ5uoHeLQPplwsOOaVDfPcRL2aKSVjrLJxdt7O4+hrqfYZNJghLK0xTgTzF2x3XSb3XCWP6zeb7XUSEPF25gZGQbSRbwlw3iGdWDyrxWKiO76p409UAvDWYiGXut20VK4cCcaVDBRH458b//5j7Qi+csc6DNXCURW44bEVEtjJwYQRIMeb0HQCES5oDbBsJMTfAO7QE4uqrxoVd5DIBYg7VJMICVkEpcif4L9aPUhNFCj5AaMzl8GHl3ahqy0zOv8MvZ+IFhfH6NE1wyYbgFJ/dQbAvwbRIWq5LBoQFoNsn3tpsBYpfzWEXIu1ysqlFDIDltiswSZ+NNc09Zk5fu7C0IlVlK7OQbcFlSeIM/gB4SN1xlNg/JGZWzU9Vl6ONdvsBYivby3xKfdenYNWfkWTBkJen/UndJm2LOG43abhDYvakG+hxPg2H38MAHTcwkLuNsnHnnL1SIBvBqhjNP7J75WREH/45xB+/uRGDI2wM6PLjL7rspu9+3qJTp9P8wzE8p6ob/IBhh4AFSIcHRAWhcxX6fgfxrXWzwwoJRbLfkq+7Hf/xbIm5Es/g6BbND4Bi/oQ9dUsJZeiC21ZnLVvnBMYg/5EBonvYtBbF3bl1k+pAegpVy8j4JyxlGUAawdr+N7DZZQrdd2DROzvxP2jdTItHtMETjnvnEhz/ZWyZQPkaiH+GTK6UzP+Mt5vEuOnuf3SMACUoJnyxljINhZv24LPHN6JtpYxL7ao3g8AdFwxNgKlcvVIADcD6BhPK0MjIS7+8zo8vWZYK3H6zB8redrsT0YZ7RCAG3gHdvuJkCD+HhCeaQloz5GQhyI7bmTCDQWQdsxIl00lIy6hWT5KHqd4Awygqy2Ds/YtYFb7uJ4l+HqxkDt3PBVcbJIBKJWr72TmG8dafu1QHd/7Wxn9gzV99TTlH1NvhcvlhGsmmSdPpoDHYASyAbXVQvwrZO5Ic/XVZ2qMr44T7j01oY1mMER5Bl4zuxWfOrwT7S3jZCVhgED/FrXF38F4lb/G+OJt6/DUmuFk4g6Ooo5yrlFYENG4Yd1EXkB8zxCtzWVpx0o93EjxcnTTJcGU4XO3ZsuyqRNUg8mm0eTjTjbbtGVx1tLk6kBTNhKdUCxM/H0CEzYApXK1k8H/JKbkTzS5Gglg7VAN3324jP6hmngc047dElFPSkxGko4k3f3OaXQ2rp1RfLnhJ47PAXRkM5mBkfAeZhxgtvMqd18qvh0OqPyCUWQT86cqunVO1E8zEIIORBnlY3drx7GvmZaawGrC9YG4XEcqPaU+A7j5qY24+clBlCt1EVNLBSRLcZMGIIVOtixID8DKCUi6dV0TDlA05d/d1ZY5tL9Sq8c9AqzlRqPVlkwR4j3/Jv/QUL6scUrSrQlGybwsq3gqZG6btiz+bWnsCYzGv8g7XEtEO0/0XQLj9R0lvkWgWVoC4j92x4Hipb6HynhpsAbl6kYFTSU1ENrVdRtWw6and0OzN3mqTA3Z1zCc0PUZsoyhs2qHCT95545hCPTrAdcvA4nrg2z33L0/prisPfNrQeC4vrUEqJQ/qhtKOtv0kAnlwRA/fmgAv3xqo+XJJIbQ5U8063eMxj9J+8WTG/HDBwfw0mAdHEbXV/0LOUpmqn0Oqu/mz7k/yHsX9wd5/+JT8E+NjeqcNPQMIGSsv+r4eSFzkm5yNun8j4oY3pq4PkU+G9CZk/KrJxpO9l/hpcE6/vvBWFdG41+Uu5gF4FsTVeIJGYCe/srxAE41N2U+rRkoZvaNT69H/1DNJrjQ2zIblYpmT5LXtC4t86QJYvTFeu9fovXU/p1+43OLdNJQxidODsDs6zdky20X7r82CkrYVVlOU4hIGULAUiYjaIyQgVoIXPXgAG5+aqNIPI3On7HSmRm/eGIjrnpgALU6tMLr/qX0X9Ib3h8EXRpESIMAxyAIlmovyuRRFN5908p51o0wpfOebf6nSoKzVu8KEjeRX6t/zviaicPQXxqq46a/b4jaHBt/Ti1FOjlujPvtBaX+SicTLmJm8dhackAUHlhVwdNrhyOPidRvrCVmotj1YmuA5E4rwMmzNjQCKTkBN9hyCphEnh2cMYBKLdzNZpLtulvts1RmeQ3jIVhldFl2jlPoSDtvhCue9fCD+wfw+AsjeN9+HdhxZmZU/oyF/ly5jqseHMD9fVUrdDLDyNaQEsNRBMV0w2ubsWzRNH/VxBm3p3ZZyg6ospE8sU6cMxEGhut7qLAskrloRUi9kUtfQnvkKgQw96GS97H7qfuYGCoyfLDGVU7+TgbQ3UMCIV9P/auKh16oYOn2+bHwLwDholJ/5fZiV34dxoHxv76E6L0ELNE33QgMPLx6CNc+8XJcVDwiQcIp08syYiDjUWAdTyZvnmGWf9ipilhpFHcVk5nt9qOilBBIFsyuM2cD0Lq6mB1MD0zI4SbpAOnm2m6sldkXcaCt/IKeovSR0RD5hLhzIQP39Fbx1IsjuOStBXR3NmBxusOToPeWa/jUr8tYNxTq+FrNVQzSyq6aI6cBeV79BWPpgNJUCH3XGhnR1X4MOTGr4c8SVtdD6AcpGHAMV8x/sr1G8yYw86iY7oM18yblz+qENgZkbkfcjDI2zPaISen6yaPrEFAn9t2+bSz8WwLCewF8A+PAuEKAnnJlEZDybH+KZRoJGbev2Jhc9ojLa+ZxwyYauuxmwiVn0NxRlLFZsg1OEUAz20OPcAj8OUET/Wfn2kapmymw/OPUmV/F1CFYfDfnrfqhfb48VMenbimjb12t8czRhH8A0Feu4ZO/KqN/sB71R1xDXSf6Hl2f2em3e3/yvuD0HynjosdS7qWQ/BTTq+OV1Rn3aVlLkz/B/0arQanv/XflkwFXCLVdsnYOucJr5NOWaflJuH3FIGrhKAw0k87FsY6OGWM2AKVyNQvG55k5yhgTx4xla+pV537y2Dr0vjyiuaNdVeFGRVZSnDOWQfiBjj/N7mjb0mLezmLqk6WZhk5xfVPLbj/eg51lwRWT6Tc+gPEm2HLXpZdgBFmU0cci3o/poXUs6CHDxN0c/5l8AEOdA/oH6zj/V2X0rqvp8TLj35h/ALCiXMN5SvlD0ooexnUiY2D659KN4jv9F/Swyf1bx2n5Emu8hXxB1w0BZI1pib1Cd55ljsZCcIsF/2HVseXHXNnSakt+XPnS3+P6UiY5pf6z5WH8+JGXTf2m/EMHMX2+VK6O2bMfuwfAvCsRTifhHpuHNUzHiYDnN9Tw1JoqZMZWD6zaIsmkX6KgdkzpWVf76spDSFlCkQ4nxYEbUugcX58N3TyPT9ayD0t6XD8g7OMGsGYXlxJMu33t/jI58mbuJ5n5NoYiTEuEsQgjUjLnYVwvUkzSGfqXNkaewIp+8b69Ufj3bH8N599SxtqNoTWjs2xfJSRDiOy+CHcSKxfp/Td15QxP5k/M7vZ4EqwVHeVyi/cxZALaVY07O/yT2f30BEVMJ1lHyqIjf3pikAkKFQLZ8gV5fRJ1WFxLyPcTayp4YcPImPgH4tOB6L0Nm80AlMrVLAjfMoPiLJ3oG4sY9vO/b8Bw6LpZrkJD3DD0gEpFMO1CXBf2ta1zyuUnp1+if059lnS5xGhcyTmmnBA4PeTmmraAG7Ykldz4pW5IELIRZlt5jJKoGT606slMPFsu+pqBEJ+6pYxn++uj8u/Z/shrWLMhtMOKML191+UPZf/YDll0fT1Lu2Nj2pcTr3TLE2GVlpUE/8N6yPMT8hWXJXHfku7KF1sykyJ/QqY5hU6iPrnyr69r9IPFOWV8huvAjU9tEDmPxvyLDcy3xuoFjNUDWASmw7SrYs12wkoz4/YVg1jePyzCEuW2GKdXZkuVm6TccculJkRv52Hh6pEMGYybaNx/076uL101Eu1rXz3tT39kAdQgrmOsNexz1nc507muLYwSqNlLus7qvoTCMbPOBci4WimcCg2MorFWSGbGixsixV7RX2vIv2f7a/jkL8t4cUPd1A+VwjdvX4Ymdl4j5f7k/av+ax4rhXfqwxkfxR82/GUhAwEwHLJ6b6HzJ6+jeEa648a6KCFx5Nd4G8apZ062r3RCtaHKWPKbIj/WalN8/MzaYdyxYrCp/gm5PgzAmHIBYzUAl0TXiyyYtp9Kp+LjSo1xa2kj6nIgVT/tL0IpZVPS8sWGwXWhEwMH7ZGRNTPbjHTWGqL6JAc6orNDZwZaAjymrLjVvvymXVfjAdjGRLm1MqGlBEPNjHJ2FIrPQAhhTCxPQJZXyqjCABOvMxNe3BDiEzeX0VuuJ/i3olzDJ25Wyi8MizY6ZIyB074pL2d/qfimf1Z/tfLY/YceS7bHS7rKclVF3YuQy5aAHtFL1cJ7AGz5kHru8l9l6l35VXM1k+0XwpVfK/6z25fyz7rbMulo168z4w89G1GphQ31z9HPSzAGjGoASuVKEcAxtqcstCo+ZgC3PDOAciW0XCLz9BvZgyx2ShkXyXHJU9x2EvRoCUcts9juV7RdNMVtS91pCB2vSTdRLdEM17HCakffj9gF6Lh3Lt3YA5WXAEysK8MAGTfLsMKmR+6/vQNPKaZx/0knCNW5FzeEOOcXZfSVzU6zvnU1nP3zMl7cEOr6WunV9USb7LQfhsn+2bmMdLo7Po3oUo84ofgyb2DolTqvknznFP6kh4Vqs45y2ZN0WZ/RgK5jfLGz1JFfs1vUlqs0/QEI5aEQv3x6IFX/UvTzmFK5WhxNv8fiAZzLQNbam86wmAoQ1lfruPe5IeNeWW4TjKumLbzt7kgX29Qy6RB9rN0fx10S4YU+lu64CAPI+GeJ/kG2H117ljpmp7/GbZOuoGhCCi2b+cwWeHu2hxhnhlR04yarmDxRX7jJ1lKdduOjcy9uCPHRG8voLdfQ21/DR5eti5Q/hEjyydhfHdvtm342cPPZjfvlCof0rgnSfXdnduv+Nb8Ae2efdKWjDyLqgJAQV36UvJA8VqrKDr+FPNnenV2fnetZ7VvuvS1v8tj2YI0+MTPueW4IG6phQv9S9DML8LmjKTc1I5bKlSyA5wCaowbS7HUQb9hj4PonNuD2FRv1ZhG1acN9zbOiqx0XBJiy2uUifQWjjPIBDpmpNfQolpN9U1ZVlVX9ja/PNl3+gIf4SfB1YYidAfxLxu2RgIjlNzHTJZNdlCL4xh0OncRYMtmWUh9RfcT1wYxQyo0SCj0GQqGEzjSTDCvVZRLiMR/lu/zFwztxuYDkOUIg6SToTtlAl5F1InpARjyI7AeGonpRf4JIvrYNiP4OYJb9lmGIh9HMD41Y/icJ+SEYWZWxNznyp2QKRj5IeyuxfEn50zKnjINNt98DwYafDBxZnIaT95whAgpCA/1cDWDHYiGv1oETGMUDoBMZNEddRLlExpGJXJT11RD3rhyCzKRbm0OdTL3tMplus3LZtVWTym/qS1cusrCkGQcWZdkMRcTn2KUkU5/j/im3z83kMnNrNkAIQsXNNGvlh1F+a3lJuvs6yyvdfhFzpj4HkOJOO/TQoYdMCEEiDhd1Q0q0Ezb444bfzXX1sdt/5/rN+m/Po2rpT42bqW89IyDDSDPhQz1LQISBXEA1Bue1oqnyUv7IVRtnpUnnoiTPnZUgduhyaTKtfUt3lASK8NQJZRWdxfXv7hvC+kpdj1cT/ZwD0InNNLzpUgEzziVi2844MwMY+MPyjRgcCa1nZaSB1K/mUpO0+NR0kd/RBhZqUpfpQlhlSTHBdAfKkVD1E1OdngUJIFpJwCoG7gIQRqktChAZxyUAzZmZywz2V+orQ+ZFSGkOYmYwHgGEsEprDu3mmycB2Yl9UxJ71tKi9Azs2UKGD8ZbSc7+wsNpwHv7xZRm6Mgy48azshO8ZjzEbCfoZhIgsEsnm05CSXQaj82Eoc2I7gat3LY9M/j8QK1EAa1m8GMBKAwINdZvOMZBDMwDqBvgwMiSzqUZGSQnGZ2QARGWpH3qsCFRLa5nyzen1JcFBkeA3y8fxMl7dAi/Nl0/melcAD9rxOeGBqDUXy0yeIkVz8rXFcWoM/C3F6pw5YGNAbPepdZI5AzvGpfVRkQeu2XIKICai9lpg0EriXA1MX4+M5d55AfHzWv6U1pn/3YV1g7VLieic0PmolEuwSdnWzJgFFmVkrO+UmQTtVoRaIIus+GJLbZxGGPCCRkLCuFTnpWwCMkoQL483X7wxwRi9oOsKowjjt1vzZwoLFGp+Oi7MEjO/xwzmARdBG7SSRcbYMx9xa8hK9VDvmLbadnh771j3t7N+PrhX61qXT04shczvYOA0xm8QDebIlzSZ7X4LGWLzNgTkhXU/bA8cInitKV/wmv626oq3rlbB6xfHEvRT4CXlPqrxWJXrpQ2Bg2ngFK5+gkwLmXAmtn1yl7c2VueGcDNfx9wXvxg3vMmX9tsnhCLZxcyAmTJjf7JKNFBMhZa5g9c6LmExIxrGnomAC4JCMuuO3H+uN+ldvw1vfnhEG8IGe9ixjuZ0WpcfxGrQ8RxVkwPK64PHbr9eK27oSdZ3943IAyDuL5OEDmKJ+PQ9BmcnNyMfOWXfJ8fnNifEzF6oI8NPZBxvT6GOEeibLK+vH5AGCbCLzKEH7W30O2/eFf3uH9L79RlfR0jIR8fMj4N5j1sd1aknWL5Mz/dZSuTjPmtGYIgvADhEcZ0bbQhwso0j04fE45/zTS8bXFHU/2M9fe8YiH3tbT7bmgAesrVXgK63R9/0E/vxY1f8Me1eGmwlvoGGFhGIXlOdSARdsnvjIShYNEVZrsc3MFggIgqzPh8NkPfvO6E7oHxCkca3vLj3iUhcHbI/F5mBEYBzU4+N9udrviCFqYpPpyyYi0d8pwRDBMyyA0rjgcgJTIhEqwlSLNG80+8yDPtrT4EBI5hCKzvruI7n4FMDoq6QfwdlmEJA8KPA8Llt35g/iObg6+nLuvrqNbDDxPoIkb03EvauwLlUFnnleK5M7copj/ZvA06aQTSlN7m9bbTsvjyG7dx2Gf0M2IxA0R9Cwu5+Wn3m2oAesrVRQR+HEx5hsypq/8jBtUZOOvmF1Nf5OjODImXRSJpFFLuQ99IoqNueWl0BWMC0DMMHLfspPmpr8LeVLzxRyv2CkO6IAROTV3+Yk6ZvV1jYGb/pvTQNSyyfZmQkzmDOF7WiTAxQ0G6i2ZASSRwZKbf8Ey85FO+tVcrpn0ucGfvQCm3TU8aBuUFkM7yC2NxTTbAJX8+c/5jk8HXE67v3QXADSHzXlIeU+NP55w0uiSOtZIjWS5N8cHuU5Nk0UMm/NeRXVjQ2ZKqn9rYE1UA7LmwkFvu3mfqKgABb2NQXsVker8CkdlxR4Tbnx3SySwzGCIyZILJvBqzyVrjzV/iVV8cZzX1Zh/Hsoi6qj8c1yfT4V9mAuw5WcoPAH9434LHmOm0DNFRAJ6QDJYxNgu2sEO13HI2zE9srXXdQsu4yPJG+ZlJCJFNDxNtOvVdOkRyU5d3+ySEOJHDcDcF2fcn8yicMn6xhj2RDehoMN41WcoPADeePP+ZlgwtBdFN1oYyIX/6vHkqR8uj/pT6IOUbUi+i+uzQOaW+Hr/46IHnKw31U+kvgDwBb0u7z/RlQObXmeSO22XoYPz+lRUou6PjTqeTWiGU++n4QrYTasddyTJJh4UcuvAofhYEOOFnJ8xvmuDbHLj1A9344/u7b5veSvsT6AKABux3vpm+m6f8IubKJbHoXsn+U9uKraVBdzlNjbOrrK5yusYgSVfeh+2ZODMQq0d/xdN8kPVN/+x+w5zTRt8IfiQn9tio+gAGCHxhZx773/7B7j/95az5Y2XPhPGzE7pruQxOyRB+0Ej+bIi8QFqY0OB9d5Z+AK5SWN6DO7n+c+2IPGvkH7b+gvl1DXpso1SuZpn5WRDN0/231kaic2sH6/jM79fqH360Nn5AJAKFy2h3jHViCQ4dis5kvoukIIs60bEsC4DwswzhfddtAeVPw2Hf69s1DPF9Zhws974bxXJ316ndejbdDguSx24ewZ65HXcSxkC7y05G0EziJZGL0fG34qfik715R7vyihZI+QAokEk+OykYpNDjsODeDOGMez86eZ5cM7zr589lq7XwyjDE+80wxe42AzppLWL96DkSFRMYB92EAcbjYUG3vD9ImVBG05afDAFffcssdLVnLP2UUUkc5q0kop2KhZy1KSjNA9iLKPp5ZWkdzC6+6C6e7R9BrQ6YTRDOWqic7fUNy2PX9rA9gFKh45ExHg1S1qhZ3flNCHHGVCk/ANz5we6n7zqr+3VE/GWAKvr+9UjqHosZjq2ZUAuLDgvYOZbegOt6i00zaS46kl6E+1x+6NBhtWHaR1r70pUXu+Gs+xV9lfLDNr0SAF/unpk5fKqUHwB++o4dawx8BMD1RruS8mnORt+sNEEi4WrLr9QPzUNYKmN7CTFGQuDZ/pGEfib0lzAPKb/3mGYAjrBffgYT6yhWMuH+lRXRQeOWWG4/jMDJWzNKLgYjlnhyB4qj3ut1X06aDuEdLG/N4MxlJ8+vTJDXmxV3nTX/AgLeDtAKZRDluEi3zlr/txTEsNMYDls4rA1HrgcgFb4RXbvaDh0N6gtjbxkc4XKk7eKTBl5PFlZYIFnKK4n57Q98bP4FN7573pQZc4UbT5pfybfQhwA8lUxYG89JqmwiNLWZboe2nKxvDpOyIcfwvpVVSP1srL84wr2vhAFgYCf54EbaQyoA48k1w7qGLi/Zy0Z8rZu2bpTtO4Lqu3wwRFxb1zL19HeiYQDvuuaE+eu2lFCMBXd/uPtPzPxaAt8GcS9SFcz4modV5ENHnPgzQ5d4gEgrrFDWREhA4pzzAA/GWV/QDWcJRhrY+qfvX9S3+MiMgHAnh7z/w/8+/09TzT+Ja97ZvT4gvA/AoHy2P/GeAsVTW2L1+MCVX1fpwSl/sL6bl8owHn2hikrN3RSWor/ATu49JQwAAW8QOcz4U32L/h8cYdRCCGGUmUt1HLemBEZn/8V5mQBKeXTX2pefyMQKeuSHfW3ZSfPvn2ohScN9H52/OpeltwD4tnTMjNtnJwyN+y/DApMZtgVNCBUk80X71qxvP5EmRVQaBNMW9Pm4ku1JCLo5x1rG7WSoG/6o61gO67c7WoM3PXrOgtVTzbc0LDtp/oMAvqZ8TvNwm9ER+Qn16awU6E/lIac8h2Lrjzi2JQgbhxlPrK4iqbcJ/X2Dez+WASiVK4uYeVFi945+/jiy7E+8OIzBYRZMtf0SO4YRron0AYXyyhlduj1qEOXsYGAe8AFQymeDS6daOJrhzrO6h7MBnQ3gFIAqOn6WoRWEyyyVXszyUAZXPzjixOoyHywfnhF0lnWd+m6b+rsOYdylKXMsw0ErbHG9DOfa8clKhnBmlvjsuz6y41YRwjXC9NbgUhAt1+NpzegKzjKAlF87mWXoKfXNg0Lyw12XY/x9zYjRpUb6y1hUct4abHsATFmAoucDhGseyRzrjj2zdgTGtTMdkzGuuWmrffOVk3QrurdCCjVWdn01KxFwyU/f0b3Jv5U+2bj3o921hz/efT2BTyFgrb0PAA6TlYtpkRynku2yrusO4QkgMth6dhczNQRdexUsr6/c/Aahg3bhzfUhpMN2fw3/tDgT1hPhlMc/Mf8Hj5y7oOGjq1sLfnT8juuQ+sYdx7uTE570fFPifWuGt3gmx8w6SuiH1Yc0/SVkIx03sAwAEx+gO6YNs3HQFNPWbqwLSRQzk2S4fBpIzxJSIGTiRCYZBT1un+RMqG6T9Pag/umtwdWTx+7Nj7/9+/xftmbwOgAlJSSG6dEIyDFNRIBaic34J1RNGw42jpVQfpgrGeMtQwdAKL8qLMMI55oN+m9mSYgaVp1SLksH/v2T83851XwZD7bJZ64mwmqwkF/HQzX8E/LtesAp8h+dJoenEPVlIj0a65cG63beoYH+RjpuYBkAAs3T/ZaL9oqBBGwYZvx9zbDlosL5bv3Apqhrv+IIEBfQRiPxRl9yjq31VgID/33VcTuO++GPqcYDH+t+BkyHMqOEBuOYeOZO5FukG63H3HpeXmykge3OA3aIodsUu9zY6YNc9oN7TbbLJ+vChC12PqAEpkMfO7d7ypb4Joorj51XAfBdlQeIYOc57Lg+kesA3GNuTLfGzQ3BQHhyzTAGhtnYnQb6SyDxe4mpSUC1hVFd0qQziAlrN9axYTjpnkSd5BQ3Jf7Gbp2UY/GTz5KunV1K1g8I104inycVT3yiexURHR4QHjb3JF1E41jZeyoajB/kqSTdDieMi6rHl2U1hvQeEu5qCj855fqJEvGJDPFjAeHwns90r5pqPkwULQFdC1LP8xj5FIt21t2r5yr0+Fgh8Gj6AfuYJW+ADVXGvzbWR9VfF44B4Gk6stAvMzSZaP0IoBPn2fFOyo2w03HXbeQGxynlrWOi0g0nzX9iSzB7svDkJ7pXduRwKBGWJe5Xj0Uy3lffdIJNupTWspTKldhr1dqwaEGMPSuR5bf7IB4ughsCqDDPvr5hmv1JwE2Fdjqq5zPzV071+G8Krjux+2kAy+1Zz43NjaJLw8kuXR5bip4S3iW+S26Mor/gafIeHANAb46LImKU+qcumFyeMO80dt0VVc79i867IYRL1396eUUtpRg6AXduQX5PGu77WPdgyHgXg6424yPHQYx5WnhgParWZFxFvEqJNgDzGifxAJbVB060yw7dDQVTXNir6yFOe/DsrT9pOxYEhNvth9OQGDuSD7AJ+TXnGsi/NWO7Ky1uSEFWycb6G+m47r97Q5TSoPy+Pn4jqRu7GBskY/q0ISM0BI1Cd+ozcMfE2Lb14Znzu4cBnCmNQNo9j3VsGtETE7NVjYytSCmWILplaNR+Xs3AmSs/1z3lO/s2F0LGX+wzyTHgUeh2uTR6miy4uQVg43A4qv66cEMA423LLK7IEN+/sgrpdthuoDiWEUGKmyJ8UEMz6WZZUrTNVj8zhNTXHL1SsfxTkREA+Jp0V68ZmtPZTgDY31VoJY6pUX2ggTxxwy7EPLwGwJnPv4qUHwBaAlpuZNOW2vRQTpxnR9kseQfS9AtNju/tq9pNp+ivyyR7GRBmHVhd3HgpEe3v8RbgpFWTMag7TG72XrRA0q2V1aU9tLOjil5nPDj5LN6yKH2me5iZzgBIvMjRdcPRYIwbGwrFPyIxupbHqZapbBEkp34af6np9RkAfgbQGav+89Wl/AAwEvJjOmSybl/mQUSYJumaLMKHhi6aGuU0/kb0p9YMo5n+qicYJbQB6ClX2wk8Qz14o9bZrYlZbmUUrzBmpyP2tlYxc1OaeyJHjdRSRSpdbrQkouGx/7TxKwsrPts9DOA9AC1zafLNPGrIJNUdPbe2rpDqaco8SwM6bDo59JSrLyPgPasvevUpPwBkCCEBA3p8pPw6q1l2DkDQWci3Ewbbo9koZyaLjKa/PKOnXG1XxQPR9CxmLLIeIhCujdq5919v6Nob4LcT4Rcg1BKZSOshCAOTjXaznqpAMqMJMX5xT0JEib/3EbBNNqBX3Pr/WNH72e7adtPxIYBXqUGwl5fMH6WdI/fXB2weETvnOaXNlHNp10r8UXT9IOBKdxed8eJ/dW/1u/smivZsUMkG2I4I7yHgNgD6Xu1XibtjCvsX7ZEu/8kQO1FuOEO4KSC89b/e0LV3M/2Nw4BFpH/tShiAYiHXR4SHo5c6pP8BhPWV8DoCHZjN4IJ8BjsERP9GoNsZVEnPaFp3AncGScIhEg2D6JGA6PyWgHbOBnQagC4Gfj8ScjtepXjN/+3L/msAPyWiucZFl2NkZ+qtzDM5551XWGl+xn/UgEZOPdkmUXKlgJxrh0z558u4dp/LnuuY6vGcLGwcCdtrIX4LoLM1Q6flMrQTEc4l0IPxE6o21Es79X+S5pwk6JDNmfkrRHRbhujMjlbs0JrFBQFhvw3V8LrR9JcIDxcLuT51iZQcgAvh4BOwcSTcNWT8x0gNf6/UcR2APAOnEHhxQPg0AU8QMJzIESSe9nOOLfeRQgKVCPR/ACwF8HpmrKqF/K1ayM8CuIwZB4dTzf1JQvHLfa1Dw/gJM45R45PwHJHy3fXgpcfvfFr1ndVEizNuvaQdSph7WTRkftuql/nK7f93X+tUj+tkIH7F2mHMuKJa596ROv8/MFYBfDSAfQKiiwj0DEC1pvJvLftRyjkME+GRTIDziHgxgFNAaN84jOsqI/hHLcTnKzXeNdlDW39dHU++D0BvBJHPgTvPohu38YiQ+XKAnwPoOwBWZgIcFQRYSsT/B1BZesedtL6b9hi8EsB/B4TDswHtD+ABABcCeJbBP2XmNzNzq3JrAuDgqRaAzY1Fl/S1EvATEJ/quvj6VVyxix1v7LC+uyEAIRkKWO2l/Mk2Usu7bYtrJ8KOaBY7lYAfLf5K36vOY8sE2E+48PkQ/DYGrgPQQ8AFAeHBfJYOzBAOJcI3AcSzr73qle7eM0BYHgD/O5vBPlnC0QBWEuhbDH4+DPkKBh9pxnt0/XVhPwvA0NlM8xvk4ie4Qci4C4dROrmVwW8OmX9aD/GPeojzmemeXIb2zwR0OIG+SUTpWz6J+gn0QwK9NSDsCeAnIeOkGvPjIfhmMJ8K5k5dXF4b6J5qAdic2PfyvhkAfx/gk9XMbEZeDJk4Z8/a0lMwdPlOf1U47We/rOSTclXlLG/9WIZxNcx1SDh7JLwDAsCnVkZw7R6X9r2qwoEwxIJkTosBoIuZ310L+deVGj8eMk4B8NOWgPYMCG8C0Q9AZG2GEinulQHRN7IBvW5aa7AUwH31Os6vMf4RhriOwW8D0CrlQ/NhFP11f+LMVmfhOzKEQIlzGScWtX/vHGDmToDfS+BfV+v8eBjiPUT4eUuG9iSi4wi4GoTlINxCwHsyhN0DwuUAXs9MDwD4K4B/Z+a5WppIXkl+w1FTLQCbC/t9o3fu0AiuI8K7jWKpWBxmHKwwQMTkQGzB5bGIzylen9HxIJwYEeJFroZu8gIARH19ZetFF+bJTdcgEQj1kI8dHMZv976sb85Uj/dmxOFSCZNxF4GZ5zFwDjP+Wgv5AQCHZwiXtQb0moDoNAL9gkDLieiHAeGtbS20Z0C4MWS8a+Nw+CQDv2bg/czcZWuwHHv7oaRG+utG+W4I8DvW7l90QmYSiVIsnXQ95fP60cdcBn8wZPxxuM73gLEUoEsJtHcAOheg2XXGzSHjPmb+JIMXyfcA6KypWQWA/S35hpNXInb/Wl/34Aj+GDL0Vmzt6lvut/k5LBUGaPdfz7bmvHTZARgjIMq4WWe7jlxNSK9vjiGMiOoTm3uIjUst5EM2VPmPO1/S92rx3t7obt7Ra/wswrZIrgMG7xIyf7Ye4qGRkH8FYHZAOC8IsCcRLmXGvkM1vqfO+HPI+CjA8wxfSG6fgRWqkdGOUfT3d7LzrgHYqK26vpDI+DKhuzMbvYLYsngu3AQHBwB2YfB/MvgBAM+GwOMMvhSMAxjcKv3J5NqnIAg6M88+8YYVS6ZaAjYFe1zWNw/ArQzsZrxqM4uaF6KahF0y968y89C80nwjyUNAZvitOsLTMDThdZFd1mT9xfVVWXGceDkWAcy0R8h866JLeueNNj5bM068vnePEJhnxWKCR4JrkDN0rLytDD4oZFweMh4PGT0h4yEGf4GZdwU4SNu4Y2I8e2S3acuguzOL0fQXjI2yOXsVIL6e/oQ6ZjBFliQbEPaZ2yp7A0vhyWa4aF2VyzJ4Nhh5e7AYScMhG2LYz0vrzzO3MN83G/a8vG8uRc8zLCIxfubHWGwF1MqmZ1tRXoZJIu4nSbfaTjlHdtvqXCDbJ1jyro2AaAvaE0DCwIiQcRFAd+zylb65U82HCYNwhsn/Cadb+top8iv3uEbFuR3McwG0kqPYJL9Z46dHHwBh6bxc9EvBo+iv+0SwnQQk3C+3EQJR5chsm5qtGdIuaNpmFPel1aa74jxJa6Puz82MxnQS9QU93tz4gdNv6uuaalkYLw74Zu+RAXAPiIsy206OW0eUdLfNexPYUjQTCrBRSuWewyhlIOqY3/ETZa3f4BPhhXVdWGXVdXUYoj+dlQGy7q1IhHv2vqzvjVPNj/Hifb94rjNkfJBZjIUr92Tk23bZYcm/8ezMyomZEFX4laJfQm4yQXyFUfSXAOvFuc47AbFSW2wWs4xmOsWCkeb2Q9xo8pxtz1SHnB1/Oqmh7CALGuS0h2i4GMzcPlznj06VIEwE+36z7/iREL8FuFu6xmYmtcdSliFHGS1Fs7wBaRzUd7kywLqNgDj+I/2LPlpJoQyG+PUmt32t3GQZI/eeLO9D3xd3D9f5V7tf2nf8VPNlPBgcCc8CeAYgN/fZHJGr7hwz0N68xQ6vbflWBj2RuofUSwgDLcK0BvoLhvUOBncVYB0z+kWPRNeMDWvJwLkRu6zc9EN2+46VE8GSHinpJbhulKDreBcAcPbJN/Ru9ZnlA77dmz3w273/ScC1IGq1Ym8Ys2fid0KqC59yHiQ44sb4SGsnPQcgywfu9SB/otvOK9grCfY1NAvdPIOp1wria5dc3vufe1/em53A0G5RnLKsd3YInJuY7shOwpF292PEyWzj9aZNl9KLIKd5W79k5mXxrBZd265q9JeBfhDWyTYtA1As5FYDvAaOwSHn+3475BosR8mCaVsYk4sTCbpceGb7ZtUylNsjZsxi4KLNx+LNj0O+0zcDwOUh0+cR/VqrsH0yCefMmOSy2o3h5Qxvvqf9Xp8JA1jM9K7isigLoeRmttchBNz6Ka8icQyIPfsL8STK1xmfB3DFQd/qnTHV/GqGWogLmTHHSoqSkE+h2NZ2avUbguTIv2a8yYPZeSClbGLcRQu5DGFBocWMZwP9JWBNpOMGyReCEP0p7ZdFzMMFwKJtWtDRqhRWxiUKRoDsnU2ERBzTgB7FLg5dvUNeW1HzFzJ/4ORlvVtlLHnYlX0L6ow7iOijMqa3lsis1JCzO8+J9dOW4AIds5Ol6Kq+/rFOl55oW/xop1b2RgbDrh+kttuk/3Is9DInPlyt446Dvt23YKr5loaTl/UeycBZtlwqeSQkZNN66IocfYm/s/okK2eS3NmpYOeJclnCttMCseCXrr8AEr+0lHyilvlZ5V6b2CKe35UCErDnnFZYG0ZcX1911Dovj133Rt0YTJt2TYBEFlO6INFfa53xnVNu7F0wZdKRgkOv7D22HvLfAF4iZ3zt1WiXGpYSmuU6WLG17bLbWXnSsbxdJkgorlJ0182XCUI3BLHrm7oklB9W29aGIaT0H27bipe0pBby3w78du/xU80/iXfd1DevFuJKgPOufLrya8JhccZ6CSgliiY2+TT8agaLAOw5J5fQz3T95Wfde0o+C0C4hUAVvZ1QuOTa5QPhgB3VKp505rQVF+csztq3oWJEQdc36CRVKM5k2pmFhFO5oBbiWyfe0JufXFEYHUf9oLfz0Ct7L2PQjQB16hdyQMzAMMIfKbmgQ9ChlIiF0nA8U7tGwFYoqfxBnAgKyDYo6qe5A7nTj8zPfgdOfbt9thKHpr/2/akXUlj3R0aCrPuLhrCTGTcc+O3eyw79bm/nVPPzhBtW5Cs1/hbAxTjshCXfMu9FZIWv6pOFwY/gyLcV4ysldgJAHRay1oUD5uUS+pmivxUm3OLeV8IALCzknwHzGu2NSwhLtLCrBVn3laJucKLdWMBeIoloydckyW1O9i41ExKYAdAJF6s+H8PAT09c1jtlT58d+YO+g2qMO4hwDgFZyVeZ4kBKzGznAFQWHpbCmonSdf8b5QGkMsOpI/6CFBrgGAt5nu36bhlrOdH+g6BbcmqXyYJwTi3Enw/9bu9BU8XPE5f1toLxEwDH6pPxurrJ98vkdnRvrnzrnbRCvvU5mdyG0Rdy6rt+cUsG2CmO/53UmKNuvGZhIf+Me2+pL9Vh0P2yQfdZB2agqy2DpTvkrOuZu7ffV2puTJ1V8RDsC5Cgy0SKmC0i70AlE1XrLK5PIPA7mfm6E5dt2Yzy0T/snXHUVb1fZeAOgPaC1SvLv0F64i8lU++4/kETegDSyqsNQiDj72TCLxBhQ6DbN/sFgkAaE0qpI40GObmCtNBFzFQpdCMW1n7CJSHjjkOv7L3k9d/r3aIPE73z+t5syPxTJjpRSaPl6cbKrO7JlW81OVnyq5ZMoVo0q2KUIv/Wqhns8Vu6Qw6FtozVZ/MGIHOsddpBg7dq8V/dBEQiIUGMxbNatSWXULNb0u0369Vy558eHJUMUWVjyWBB1z9+yOntm/M4HsDN77pp8h88Ofbq3uzRP+o9noGHGPgkgFZ3f7zrLSbX8d2Axq6fnEVlpj5tJo4VFLGSBiKh19CQmPX+QHsEKmSQ+QX7mkGD67vfA+lRoMn9izEz36mVQZ8KgceP+H7v8W/+Ud+kG/f33fzcLAA3AnSimuWV/OrfWhDP8LOTDNQTng4XxH4JueIV1zdL5NLIiKVcNdGR8Sx23qY1VT9Tjv+ado/pBoDoFqg3/DT6Y2D/eTno/cpimci0o+5P+MDpF4yZreylAEP/ool8z5ndXTNnOORjKnW+76RlvYdMlpC86ce9+w6HuBXAzwEskgKtb0AxTyiZcXtVXO1u2pHKYdPt2deur2dnOIZAKmFgGwIZ67vhhDYagTlvXR9N+k8ib6BnybQVgZT6WmrYEn4GFjDw85E633rUVb37TRZfT76h96CBangfhNuv5+xELtvIZyqIZGGbJOlajkWzrv7IiYOA/XfIoZF+iuNKpNNIv34aevor94DoIGP51DeY70z44h39WP7ScCJGdWcFNdNbzLVmBHXA1uCSti/KpWq0SUEZBzb3r8AYDoi+CeALN5w0f92mCseJP+vNbqxhCRjnhsynR7svSa8GxW+JgfopbP0rvQyE4hd0rWMAoSof093jqIxd322fIX+h19DV0ACkuehutLSFMqIYb0yMsrNPADCeAUAO743xk2FE4hjmOFHfWmaUxgJhAFwfBLh0eis9cuNpm/7uwRNv6J0B4MIw5HNAEHkkpeRsjZsZK5UYtEdTvhk45gJUMf3Jgq5f4gHzqfkc05kQAti5qxWfPqyrsX6agOLehYXca9Put4kBqH6CCJeONmB3PjuEq/62XguEvUnENgp6OylglYH+ZMuKSroeIrI2CRs6G4HVxg/aHiisYsZl2QA/vu7E+WvGKxzHX7uicySkIwCcz4yDmBHYTFI/oW0YZhQ5jak2LXToVj1RP0w5536HOCeGx8kLNblZMuNG7jGJcy6vU/ielgTUCh1AyI6g0VjaFIaAcG9AuCJL+N2v3j1+I3/KDX2zhkN+LwHngjBP3rcYMRj1soZKK7dRZHGeIZSf9JYWJPgj5Efxx+KvlC/gffvMxCHz20a9N2act7Ar97UGbE5HqVwtAvg7gKbZ9JE64z/+9BLWbqwnYz+kGQFbiBzvx1Z4VwgdQWSnfNoyrHs+Zkg/mH9DAV0bEB6+/sT51u4oiRNv6Ju1bXu2f9X6kY+GjAtDxhwgXZkhjiMvgBoqftJTSDcUjYyARUsTFth9sj4t6WguEVLp3c8EP1OMQSPlT6MFTv2gQT3pSQZkZCIusypD+NLibXLf7F0/3HXjKd39jXh7yrK+2bWQ9w0Zp4BwDBizXWPXaDzSDYAY1lQD4Hym8IcbHLvft52WweePnIVs0FCFFYYBvKZYyKX+iE7T2qX+6n0AHyATm2bqNTd23RMD+OPyjcJNMy5jECQFxriTSYFSBPe77KjFnLEagAbuLoPWAVhLwMMhsBKx+0xEs0LGwYjWoy8PCH+oh3wrAx0JhU9lkrLktgtv3H7Xc5DK7oYT7JQn55qcuLbsm3IrjbDZbJfvijPZajGUavlV84McvrlGP7lByaXbys2JjUS20jtJUJ0T4bRJZqAlQ4fWoxeqnk2E/oBwNwP9ygnPBDSHGfuBMBvgLnlvauZODefl5MNyvIRcOQLmGt00D8yVJVeuwEk5O3rRNJyw23Sr32n6CdD9xa7cgWiAUTKpfBkTrpUywUJ51bmD5uXx194hVGoh5G4mS9GtZpMzPUR7KTJoMWFCSOYF1JdOBjoZWCQHj5nFeNJFzHiQiM5kxrUAB3ohwrmGeQRCxdnq11rV4KlMsDvU0TJeKDK8QGRQGZEhMBLKCUFTHVD7I6Q8sO4XgeP1actWWhbVXN+d/XX2GnaYB6HY9lOCrnKa1QTLIOhyQrEdmq2hyevHHQyDAGcw0AXgIoBbAcxmxq7yhkK270/ywmJLiqypsbQMhOWS2jwlso2D5S2QKMPiFNtNs/xCQHtLgAN2aNNtN9VP5svQBM1/XIdoGTGtNi/iMLuMOJYsYsL8zix2m92q0iTJKTrmkvsgj3zfvP2oiLlrkm3E5Zmd9kUZvS2ZDV2+wUb1X0onuf20RpAAIMvga7MBniDg6+b2TH3rPfkOE1K3vUJ9d7f1OnsBoLbzkrXWbtbt5V9cR2XsA1NXPsqt6Gn1rZWAgBAEyS3F1nMHzeoTOWXEzkVqcv9wxgdi/BR/xDKaGX98PSDcHzKuA7jVki9LBm3+2luzyYhfQi7VekRS/qxy2oY6dC0v0K1bZYQ1JUl3ZGy3bXPYcWZW618T/VwNSv661JgNQLGQq4GwTG0xNg8VRJ2Sc80Ju3fEHWfR2ZSHhMgwDi5dPzhh6kMuqVnrrDFd+0aAeZ+gYoSgx9fXL0jQMYyZDayHNvS0qTcZddZCfL8lwCVEdK9ZmjKzuXlltjJEZhekdpX1shmJY+EKi/pJN9es07uzpVrqU8/1q2y6XrILxJIeETIB4YMHdeBDB3UgCOz2jUKL9gPTP2UUgiBtbwALpW9CV+NneQMp94c0Oqz6Mf/ubcvSV+shfgpgVpp8GXmKFUd5U0I+AdM/JF6lLeQ/bl+uwEDKj/CmyGmfkZR/ktfXhohhrYrFY/GO3aZb+tdIP0FYVizkmq6MjGUzxWUE/jAIWR1Hq04ZzcS27RkcvlMb7lwxZGqSsGaqgtQ/6S2Qnnsdl1RcJ/Z5rBlYQD6FEF2KZBd1Q8K1h33CeA9EgnWmwkF1xiUA3g7CA2BaILvHwicj2R6Q4uNJWixc8akA8VKPdXvSL2So5yK07XME3d0gTap9jozFJw6bgTcujh6Z2KY9wKV3rkcYivbt0YS9/qyMtLkl6bbrvQ1KBLTyCkNgeTqGHlUy1yfBwERYEPcwIKxpCXBCNeTzQTgEDj1Nnkgew6azqsPmHiN7INrjuIfCYSX5vi1R3m1f5w3U0jYbebTCgVieZH8OW9CObdoC2GGkHVvE+lkDqKn7D4wWAgAoFnIlMP1GejRSbrUiEXDY/HbMzAXGcqsSpBioLK72UTRjpShbNJE+IbcNh+7+s7J/ajYnm2YssDyWfbPpIfP7A8J7AZxBxANmf7fpX/KVTdLoSSWApQR2IsxJjMEu5+6zsLcAi40/gU1ryRDOjZVf3eUbF7fh3MNmoCVLorzwLEQb5nkBk4U3HoTsS/pzAmYFgE3WX8qWvld2xguGj4KXRKgwcEoIHMGMTzR9NR05/JX8EXWSv4sIcT2XJuSDlCkWv4Mp5V/KNyfls+Er9uL6M/IBDulusxKPUjot/WT6TaPM/7gMQNz+eRQ/IQiYvitjzcwgBubNyOK413SoOvpD7xYURsuevM1cbXsWcnZLeZxIjyPb1lfIinKNkEKPxgnx89hk9dn+NFkfIiBkXETEIYE+B5gZDUKgyRJuThFkdUmzsQUpymJc8UYP8NgbZ9z9+XJjTWuG8PFDZuCNu+QT/HvzLnn8+yEz0JJxnicICHLnn9V+vFU4fauyyTPI2V/Wh3N/lqHT42g2Clnbp7W3hM9nAwyGzN+yVissORP7SyRRy6PI3pFTRtGZbHtAMG+1Y0F3ZZuU0y/kQ95fLB/S37IS5LqjhGMXd2CHGdmG+qf1E1QB4TyMAWPaT10s5JaXytXbQHSM6qDMPqpxIAD7zc3jvpVDWN4/bN2J9cCDYIrxJlRYYc7YWytNWiZBZzWIpr6K9bXHLThH6nryRtg8UMS6khAKvSpAIMIMgG4AYfcAtGfI+ICaSdj4d4n+aR8f5rqKBIpWAeRlpWwGMC6jFA527kx/j11JVSYbED7y2ul48+I22azFv4jGuO6RjXhxILSMsRobrUdSX/Q5k0BNKDMZujSEluFTYYEoY20hjq9hPEpaBsJ3Q8atADpVH4y8iUnF5HLMsStf1uyTLn9apoRSS/mKnhOADpO0eEnrIJnOdvtWfSZtZHbuasXSuW2aB430D1HTtxW7cssxBtBYCgFAqVzdBcDfAIz6+24PPD+EHz/6cizMbDEWiqkOo+TNSOZB0sVgkaQ7U7dmDjt0VcOa8dmO1dj2ONTuLBWLyfoM3B8Ab4l/HfYAe92djPehvkPmJZPnYNHTv+syzqc8D+dz7+1bcMyu7Xjt/LG9JqFSY1zy53V4cKX947ZuAt3imXTXxScSCp0MaZqXcZb89Dl6DMDrM4RvMXCqfX0jMyTyCUZMbPlJ7uGXM3L88E8anQyvLVNhWXGTj9EizLZ8me+O/MTfiQjv2WtmbABGxSCAfYqF3DNjKTxmAwAApf7qVQC/X2Yq7Fs11ugPPRvxq39ssK29ZiKZ2FpMamb2ENOXoJkJ0FyfZAHVB5lJkR9WYbZ3a1n8NfvrRRP2vm69356+kglwVa3O93C0aQhq84+q4yqm2SSURjeGQyq5Dh1T6EawDF3d37475PDpIzqRy8hZozn/QIRqjfHlP6/DQ89XnbAt5oDgn81HMjO3UGij5Em6rm95AeLhIKs+QKD1AeFoCnAEMy5JylLsq8lrS1kiAnFE14s9lqylSoUxeoifp4iLqcnJrMEL/qdqki0fNv+S9Lcvno6jdpomdKQZ/+iHxa7cGRgjxpYDMP2+mIEBHfJYARkJS0nYf4e2+DlliofEcEENmDki00Zi1NSSmlkBNo0YumrfuPya27pvTl47Ud+lG5eRTD/c/hE+GYbYDUQnEaiWmK1S+pdM7Mm1cPdpOSBw6IF4Os/E+TadKFL+C17fiVzW5s9o/GMGWrPAZ4/sxL475Jz9AOodAc5ThGi09JfsX/LxZcEDufSntU6sgxMhIPwvENqZ1Ytg0/aYmC9ynZ9gK7yRSyOfMqEGcd2E/DB02/o67MifkF85S5lJz9YPazIE0NmWwdLt23QfRuHfAAgXj0elx2UAioXcciK6UFvqNKWJLXxXWwb/fmAXZuTMJQxDYQ+I+015ASLmtNoXipXQ6fj6Rukdsu5xsr52FskIhps7kvTYIAQM/CgbYD0IXzQzoGnfdoldI+CGR7bABW55S1nkBiDbWOwzN4fPvL4TLZl0/ozGPwKhJUOREZjbmmjf/lQ025gFup8O3blH2+035fW8oMQlEthvEOF3RPgJwO1JD1LxTPBfliGHv44AkqyfJn9CPt0H16zxI6d9R761wRBqIOUDRJiRy+DjB3RZL/wYhX8XFgtji/0VxucBRPgxgEes3x4HO5/R+VntWRy7uAPCrkI4OdanMZvC502pp9t360NlQp0AWUdgymUSPy0qP0kl+Zzrs11f/iqPuH5HPcSVBFxBhN/o/ih67NaY+NR1cdn5hJgl7efkdcY8ULOs8x4AYuwztxWfPiJS/mb8GY1/DKAlAD7z+k7su0NrdG1xXflp3hyU7Fdq/8U46vuF8Q7keInju1uzdDEDNzNjnt4sRkl5Mi+pcT4dOWPBJ81/LSn2MYl60CEgJ+TbqiflhOx+KDmkBvJ+7OLp2KYtMyb+AXgk1s1xgcZbAQB6+iuHgej3BOisEnNaMgWoM+Mnj67DI6srkDN60jLLxAoScZtM1sj0AAm6rpASeOkdgiZ8smInmZZnpw31wA0Eq5NP2DEIdEvIeB+AvzBjNzt2N8nGZE7A5AbUWOprWDkFMn1RdQCds5jeGuCQBW04Za+OyO2X99+AP2OlV2uMnz06gDtXDGFDNZQecsxXsZTrxuSklgLJKL2c/FRoYNVxQinC2myApSHjbACfSOQe5PWlbJHhmkk8G/6zlrNkshiiHKXIj6Sr+ponKfKn1x9cmxSflKZkyXZ5vHuvmfpXuJrxh4EKmN+0sCt/J8aJCRkAACiVq19l8CfFUCYiaGXj6iFw9WMv49HVQ4Ixpk7SGKgT9lCq5Q8AeiunEcK0W0tPBJq8sFEkd0RZcNpO0NiJGsdZAIheQ4yLQuBU+8UcjuGI25fKn0gUSkVPZPpt+vRcgE8dVsBOXVmtBmb2as6f8dBL/TV8+fYy1lfNNug0/lHMP0eJnVDHNhR2ws+mZ4h+QIRLQsaTRJw1RkfKTPL6qvdSTqRRgjgvRUcl8hITjZ5j5KJrQtSi8aPESVHeSRSKokvmtOH0PWbqJ2lH4w+B/m+xkDsfE8BEQoC4p3wxMa2Vw2HuwygXAGQC4PQ9Z2LbaVmLW7byy5yAmMk1jwjRww+AjHuMchDUZgyZjNF7gFTMJuiSMfr6LK5vjbeVPdCJHNNrK+bcVfdbxpaQ8ZuhKyUJkFQGO/aW300ibUY+Uv5iV1bfjW3ZGvAHGCBgYDT+SfpOXVl85ogCZubJPHQk+me/PNTJXcAop/UWIHHeKL89PgGhyECgld9mDeyYPRmbq6SCmXykLBtpVP87jwBoupE1IV9s2ldX1UrNsidGvlwxUzmv2dOyOHX3mcgEGJ1/DBDTWjCPK/EnMWEDUOzKrwPh7WCsJ+Xi6kFis2mFI0PcEgBvWtiBlkDNrNL6qmUVGScZulmWkVMtizDBbpPFd2NqTB04dNLW1Lm+ZfYlN9nxTuzZgMGdsGan2IJbcS/bxiHe4pr6gk/hYruv1JpfaMGnDo1m/mbj7/IHTAMEejtAbwdjYDT+SfpOhSw+fXgBCwotQrnth5Dc/tu/KeA8F0Aq1nfzAWa2DoG51lhb3oU5Z9RLzMXUmP/GNRDbymO6bTzEOVZbhoV8WXXch5DI9IlMfVt6GNkMcHSxA9kAo/IvDhfXg/D2Yld+3UT1eOIeAIBiIXcvgb4BovixRMTrq7El1wuj0RDsu30ep+w+E9lM0oJbc39KdtWCqMB28VgokrGgbYzN9aWTqwtR2gxj2jKZWjN7xcZosCXAIKLJLyWscWY6EnXFbYlZz/ICzNOBUeb/nbt34Atv6MJOXS2jj79NHwDhuGIhd3uxkLudiI4j0MA46mOnrhZcfPQ2OHGPjuTTftrTkUbAKHZgHTvGLjYoydCC87kMDQaEwVT+WLwQ13fLsfFGlAAkFpMcgSLjXMYzt+OMCxqr/kNcn3RT+vpSPkHRTs2Td5uJfebkxzT+ceVvFAu5e0fT02bYJAMQ38WXGLzM+MPq5tQMLe6ejBHIBGLtVj+ia4+WeY5f0OXg6qWYJB0w9aULZbvfym2PswLCVTWuaNQ/Eu2bnkbSIRKEfdNzmZXJpSbTvhZONXM5CTLzmf70XADC7I4AJ+4xHcfuOs0Z39HGHwDRw2AcXSzkblPjVCzkbgPjaAIeHkN9TScCjnvNNJy8Zwe2m5414ycUOZDjaim58Ghkgs7lL1QugLBNe3YVgJW2Z6VmX4srhq69L7t9kCM/sOXHlhaxl9/pH6R8EIScwdwsp8inkgUQMgScsvtM7BOv949l/AFeRoQvbar6brIBKBZyg2CcCeZnyA6K7MwXc2S9AOw7J49Td58J63VmzvKMcftNllSV00MkkmjS/efYysoki1l0McF5Wn1A7RA01zduoymnnvc3vIm+//D4eaEMW4wxke4ptGAbnjrLX1ox7Nes7dSVxX8csQ2O2WWa8FrM+DYbfzAeAfCWYldy1ih25e4F4S3MeKQZ/9z2CYS3Lm7HRa/vQrGrxbxzQN2f+NP3AaV8Joyz3pmgBZ8tvbny2Lk1ADW4dDG+Fn9kGMgqYWrGPyXQN/cc19czewqdxbsmpHwpL8H6LUA2/FfypXYjnrL7TCzZLj8q/wT9GTDOLBZyg5uqv7SpDSiUytX9AP4jgE5tUIV/bU3y8X098mIF1zzxsmCUZRGMq8OSqYYuTIF9OyoDIy7oZgSk1TcvfTDty/3c7LSvH/5Q7+aDFoqn8xk6aqjGTzJzp+6ZXi0wV2ZR36wJk7BzDFm/JUNYOjePk/eYgWktNOr4SnrsfzzGhKMWFnJrm/Gxp1ydRYxbGbyXHo1R2lf0jSOM6x7fgAefr2CkzsYtB2At02lDp44F/8kur0aMiNZ25jOLX67W/gLQbtasrFcjpPcnvC7RUcHhJF31R8iPPTmQMbpwB8TN08tlP9G+4C8R4fQ9ZmKv7fLJ5hrzdx2Djl5YyD2IzYDNZgAAoFSuHsGMW0ENPIuknqFv3TD+vGIjnlpbMZ3SwRFb36Wnpl0rzRh2+CKWsUjU1805Iwy2JwR1TnBAZ3bj+trasypLTwF4DxgP6flAZX3l3m+KkzySDtZd1JlmRMmethbCv+3XicWzcs25ljK+8eE3i4Xcx8fJyysY+NhY2nfpT68dxn/fX8ZQTSXGCEgs2ZGj+DLpZjwkQ0ctQ1gaMl9LhN1c+bCSamntp9BT5UvfX1I+pGRI+VLSx7L9UeRr923zOGL+NOw4U7x0e/TxDYlwVLGQu308vGyGzWoAAKDUX/kUiL6EcYQXtZBxzRPr8OS/qnbnkoIMrRvujTAaIrUOu2x1yOzUF1/kse144jFmnAHgIYvGzidSjtn5jOmHLWjDKXvM0BtCxolhABcVC7kvT6RyqVz9DIDPY5RXw6ePH+PaxzfgjhWRl2pCoQhpIXEqXRwTsJQI32FgP9tYJL9TCk22B+c61jmkyAw3URY3DSFJnJSx3bfN4bTdO8fySm+JkJkvWNiV/8p4edEMm54EdFDsyn8F4AuhXmQ7BmQDwmm7d2Kv2XnkMoZTVuYe+nQ6qPH5RJYXSQEDRCYX9klK60jKNQPCKhLbDFOF3TnvZv7VuTkdGfz7QQWcusfMiSp/PwPvmKjyA0CxkPsyA+8A0D/eukSE0/aagXNeW8D20zMNVgXs3Jak6+HVx5EGBoTVmkgJA2HVs5DGR0ry3DUYsmwzz6eRIZGfuQxhr9l5nDoB5Qf4ws2t/Gm3udnQU65+hsAXQxsZ22VKU21mxgsDNVz1aBkbhkOHCsvFShhcHp2Jbqgvwz8GEg24Wz7ZLZ88/r/MuBZQIQCQ6gmktKNo2QA4eMd2vKE4DYU2aZ/HMH6KznQ/iE8oFvIrNwMrUSpX5oHpRiY+YEzXd+jloRB/7NmIv/YNohY6409JRUlZ0FHflxLhFACfSqsvz8n2VBlOuUYaRKhutetuIXcL6MfLU+RrRmuAM5YUsF1HdrzjFwJ04aYY8maYNAMAxC4k85f0qLqQGibo66t1PPjCEP5QGtDa4r7SiQHzKi9lgiWHdcaX7PqGLPy2xMbOuHsqEZeyjzuFzsAXAfycgQf09U1+IFlfJwKjdnbfNodjdu7AvBlZvfyYNj7Nxo+ZfwCijyws5IaxGdFTrraC+f8R0QdG418anQGsXF/Dr58ZwBNrqnGVOBEnplBbQW06AUtBfAKBPqtaNVt+KcWri/nb4JVbzKyVzZKPFLqp5PAvpb4x/tH5NxenY585eczI2T/jPabxI7pgspTfHqtJQqlc/SyAi5lTbWp874QkHXhsTQV3PzeIvvUjIsWS0nFZ3/Xp4/bd6dz2BE0SzumaWD1weiDjetL7xr+YIXq2FvKV1sxOIokIbdP0985cBkcVp+G189qRdfZ/Nx6fBH0YhDMJdH1xMyu/4GUrg08G4/sAtY6zfwCAWgjcs3IQf+rZiHKlHs/YaUk8iNk9aiuXCd41Eoa7A/isLEvaCJtzLNqRM2oiv6cv2Fy+JP+sApwuXwAwv7MVB89rx56z21Loo/OXCBcWC7kvTgYvFSb9N9aZ8cU4PrtYcVQvabD6pRrBaEHfe3YbFm+Tw8+fXo9/9FdRqYVmsOSgM+vhJDkjqwwMS+EivQRj9glI42EsvrX2C2hmW9cnc30QwjpjvsVU4QdavgYRtpuWwSHd07B0+zzasoTxjo+iM6ME4O0LC/mnJpOXsWG5uqe/8jCIf0VMxbH0T9JbMsCh3dOw/9w2PPRCBXf2bsSLA7WYN2KUxPgq41ALeRER1fSTcYJ/RvmFxybpwjro90G6KVygoXxp8YjlSk8apDwF035blrBLVw7vWDwDrVkSCepx8fdCZkyq8pt7mmT0lKsBGAcT4VeIX96YujFAukGCzsxYNVDD/asGcf+qIV3HrBKn1E/GA9pN4xS62fwDfU15/cRwMevfAVDXzwZ09kjI2xHos8n3Cpr6bVnCWxZNxwE7tKEliJermtx/s/Fh8DfB+PTCrvwmbwoZF0/7K+0gXEKgj43Gv0Z0JsJInXH/80P4zT83YHBEKCrMOj9Yn/9ia4Z6R0J8R/JfzqR6mK3HZx266J+QoMQ+k/HKF4hw0Nx27D+3Ddt3ZO3rj3181jHj7SDcvbCQG3MifaLYIgZAoae/ehARvs/g3SbUAAMbhkP8rmcDHl9TQS2UMZRVzD7FozY7ppPciKz4BzqQmY8D4bPOxkYQEWa3Z3DgvHa8bsd2ZJpllcc2FqsJOK/Ylb9mE1rZZJT6q6cz+FJQ9KvJE7wXhAzc9dwg7n1uCC9urEGuu4nZ/YsE/JzBD0THpr4OF5wxbTrMNKZTqUQpY9kgyu6/eeF0dLQEE+YrgZ5ixpkLuzZtf//4rrmFUSpXOwH8GuCDAIojXpHMg8PVFDozsGpgBHev3IjH11QwUldF5ayt3CwVGMB6qYL28lSijgSd5bquocuXNhiYtwYDWArgJAY+o7rcGhD23i6PQ7rbk7NCg/sbhR4CuAXA2cVCbsWW5l8Dni4AcDmAt0Gv+kzs/hiE1RtGcNdzg3hw1VBk5M3zF18kwo2I91mo8EDP1U6yT7UtPQmZzIuWZaPNVkS2fBhREk9GOvLVkonC1IPntWNuR8tY+ZdGDwG6F8Bbi4Xcui3Juy1uABRK5cqXADoHQN5e/ogGh8VxIzqYsGG4jpXrR3DP84NYNTCCwZrSXkSCw8n6yqXXLzFl2wXUdOHCq/YkHbK9iL9LA6KL6szHLirksGROHrvNyqEjfi/ieO8vSUcfQGcWC7k/TRXfmvO0+gaAvw+ge2L3Z9MHqiGeWlvFo6sr6H15BHXm6+OfZnuomYvPLJ8nsPltlYcw/IK/7tZzk8shtLcQ5k5vwcE7tGOH6S2YnsvY7Y2fvxWAv14s5C+YCp5NmQEAgJ5y5QgC3cDgWY2iq/EcV2uMR9ZU8Oy6YSwvV7FxJDQFmsFtUJ4XiwONmmEGpucyYUtA+y/ZLv+dnQqt+y0stOqM/kTvRxwPEOhqBs5fWMgNTDJbNgk95WoHAV9l8LsJ6NhM94/1lRDPb6jd/at/rv9f1Ro/tGG4nrqVptH6PslPck424n+MjpYMdu5qxYLOVizZrg0tmU2/nzjpt5bBJy0s5G+fTJ40w5QaAAAolauzAb4CoJPl4Ii19dTBa0YHA5VaiEfXVPDEvyp4uVrH2sGaaEBk8CG+i3hdzSLy1VvmGgQQY9u2LDrzGew5O4+9t8sjnw2eZmABxV7NRPvv0P9AjAuLXZvn4Y8txtf+6n4cvaL6jZt4/5JeAbCiUgt3ffTFCh5fU8G6Sh1rNspVhJineg+uTLIqqloJiMsK/quGZrVl0JnPYI9t89gr4q3lxG8qfwG+HqCPFwu5NVPJpyk3AADQU65mwXgzES4B4CQIRzHPo9CZGSEDLwzU8M9yVTP5+Q0jeHbdcPzAimkprfn2FkKxM4ftp5tV08Xb5LB9R9a8+WOC/WtC7wPwhWIh973JGfUtg1J/5YMg+hyA7s08PgCAkBmrB2p4em1VF3thoIaechWDI2J5L/ElQluWsLDQGsfwEXbRvKVRrz8B+lPM+DQIv1s4yk93bwlsFQZAoVSuzADoLDB/gYG8PVGbmVi+Y2FT6IMjjOGQR+1Xa4bQng30rLK5rt+AvoKAL4HomuJW7u6Pna/VDgCng/kCBhZM8vgBFPNWGPdGkt4aRHE9TYJ8OfQKgM8B/N1iIb9+qnkyyrBMLUr9lV1AdCmAYwAEaq098Vpkk8p/5dMJfQRcDeDizfGih60RpXK1HcCFDLybgO6tavwnjx4C+A2Yzyt25cf0e31bElulAVAolSu7AHQtgH0tgozf0/DKoq8E8FWA/7tYyE/KFt6tDaVypRWgDwM4H8C8UcYHr2D6wwCfVixsfYqvsFUbAADo6a8GRHwIM70PwHuJkJWrqmo5qNGq61ZJZ4Qgvp9AN4Dx9WLX5O/42hpR6q8GIJzD4JPAdADFL5KZcv5sGr3GjB8T8Y+Y6a6FWzlvt3oDIFEqVxaB8TkG3kkULTEpNNpisZXRBxj4GYGuKhZyd0/1eG5NKJWrBzPzGUQ4lYGOrZR/jemMAQJuAuELxUJ+XL/PN5V4RRkAhXg34ZsBnAvwXgzKT0oefvPQBxH9btvlAH5XLOS2mgTQ1ohSuToDEW/PBrAEQPsU868JnSsAPcbAZRTxdt1Uj9948Yo0ABKl/souDBwL4CQiWgSgy+z8isqYjXzuzrDJomMtAc8w+AYiumW8v9jqEaFUri5i5rcR6CQQdgEwC9gS/GtK72fm5QBuIOCXW2Nibzx4xRsAiZ5ydTYBbwCwGMDbmHkJgMA8Dy5f3mF/biK9BsLTYL4NRH8FcFtxlLfveowPpXJ1FoAjwfw6EB0J8K5gym4m/jWjh0T0CKLnL/7BwJ8WTvHmnc2JV5UBcFEqVxYh2oByAICFAO3FjHkEnuveutgEhrQ3PAr6SgCrmPkRIjwL4F5m9C3sypem+n7/J6Gnv1IkQjeAg5ixExEtYea5RDRvFP414++qiL/8GIAeAPcD6HslxfTjxavaAKShp1yZAaYZIqPzztHqEOEuBiKrz7x+YdfWs5HDw6CnvzIDRDPizTizmXHIqJUIN5kgn9cv3Io26Xh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4vKLx/wH7i7/383nWsQAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAyMC0wMS0xOVQxNTozMDozMi0wNzowMMr/2j0AAAAldEVYdGRhdGU6bW9kaWZ5ADIwMjAtMDEtMTlUMTU6MzA6MzMtMDc6MDAd1Wk1AAAAAElFTkSuQmCC',	'1.75',	'1.1',	'1.5',	'1.5',	'1.4',	'1.3',	'1.4',	'1',	'0',	'2020-05-15 01:10:13',	'2020-05-15 01:10:13');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `bills`;

CREATE TABLE `bills` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `device_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned DEFAULT NULL,
  `stoke_id` bigint(20) unsigned NOT NULL,
  `discount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `total_price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'total price after discount',
  `total_paid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ' ',
  `type` int(11) NOT NULL COMMENT '0=>for bill buy,1=>for bill sale',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bills_user_id_foreign` (`user_id`),
  KEY `bills_device_id_foreign` (`device_id`),
  KEY `bills_account_id_foreign` (`account_id`),
  KEY `bills_stoke_id_foreign` (`stoke_id`),
  CONSTRAINT `bills_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `bills_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `bills_stoke_id_foreign` FOREIGN KEY (`stoke_id`) REFERENCES `stokes` (`id`),
  CONSTRAINT `bills_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `device_stokes`;

CREATE TABLE `device_stokes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` bigint(20) unsigned NOT NULL,
  `stoke_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `device_stokes_device_id_foreign` (`device_id`),
  KEY `device_stokes_stoke_id_foreign` (`stoke_id`),
  CONSTRAINT `device_stokes_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `device_stokes_stoke_id_foreign` FOREIGN KEY (`stoke_id`) REFERENCES `stokes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `device_stokes` (`id`, `device_id`, `stoke_id`, `created_at`, `updated_at`) VALUES
(1,	1,	1,	'2020-05-15 01:10:12',	'2020-05-15 01:10:12');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `devices`;

CREATE TABLE `devices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mac` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'if device is localHost store mac ,else store ip',
  `hash_check` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'store name for device and treasury',
  `treasury_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `default_stoke` bigint(20) unsigned DEFAULT NULL,
  `design_bill_print` bigint(20) unsigned DEFAULT NULL,
  `state_download_backup` tinyint(1) NOT NULL DEFAULT 0,
  `download_backup_every` int(11) DEFAULT NULL,
  `day_download` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `devices_mac_unique` (`mac`),
  UNIQUE KEY `devices_name_unique` (`name`),
  UNIQUE KEY `devices_hash_check_unique` (`hash_check`),
  KEY `devices_default_stoke_foreign` (`default_stoke`),
  KEY `devices_design_bill_print_foreign` (`design_bill_print`),
  CONSTRAINT `devices_default_stoke_foreign` FOREIGN KEY (`default_stoke`) REFERENCES `stokes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `devices_design_bill_print_foreign` FOREIGN KEY (`design_bill_print`) REFERENCES `bill_prints` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `devices` (`id`, `mac`, `hash_check`, `name`, `treasury_value`, `default_stoke`, `design_bill_print`, `state_download_backup`, `download_backup_every`, `day_download`, `created_at`, `updated_at`) VALUES
(1,	'80-C1-6E-EB-44-E8',	'$2y$10$AilmeXTNto8zrjLc5XpKwOkRJaAL/7XMW5VEecSaR6AlvEo0N6xmO',	'الجهاز الرئيسى',	'0',	1,	NULL,	0,	NULL,	NULL,	'2020-05-15 01:10:11',	'2020-05-15 01:10:11'),
(2,	'DC-4A-3E-8C-27-14',	'$2y$10$SgK1Oi.LuYzoE8NHiQwH.es6GqX0AkrMdHzPf81nI7cMru.4Vla.C',	'جهاز 2',	'0',	NULL,	NULL,	0,	NULL,	NULL,	'2020-05-15 01:10:12',	'2020-05-15 01:10:12');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `emp_jops`;

CREATE TABLE `emp_jops` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0 =>not active,1 =>active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `emp_jops_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `emp_jops` (`id`, `name`, `state`, `created_at`, `updated_at`) VALUES
(1,	'بدون',	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `emp_moves`;

CREATE TABLE `emp_moves` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `device_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `emp_id` bigint(20) unsigned NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL COMMENT '0 =>for account when add this person,1 => for add addition, 2 => for discount ,\n            3 => for borrow ,4 => for puy money,5 =>for attend,6 =>for not attend(this row add when change to not attend),7 =>not attend but was attend',
  `account_after_this_action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `emp_moves_device_id_foreign` (`device_id`),
  KEY `emp_moves_user_id_foreign` (`user_id`),
  KEY `emp_moves_emp_id_foreign` (`emp_id`),
  CONSTRAINT `emp_moves_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `emp_moves_emp_id_foreign` FOREIGN KEY (`emp_id`) REFERENCES `emps` (`id`),
  CONSTRAINT `emp_moves_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `emps`;

CREATE TABLE `emps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `emp_jop_id` bigint(20) unsigned NOT NULL,
  `device_id` bigint(20) unsigned NOT NULL COMMENT 'for device can allow use this emp',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tel` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `account` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `day_salary` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `note` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `state` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0 =>not active,1 =>active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `emps_user_id_foreign` (`user_id`),
  KEY `emps_emp_jop_id_foreign` (`emp_jop_id`),
  KEY `emps_device_id_foreign` (`device_id`),
  CONSTRAINT `emps_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `emps_emp_jop_id_foreign` FOREIGN KEY (`emp_jop_id`) REFERENCES `emp_jops` (`id`),
  CONSTRAINT `emps_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `exist_deals`;

CREATE TABLE `exist_deals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned DEFAULT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT 'store value for operation',
  `value_add_to_treasury` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT 'store value added to treasury by + number',
  `type` int(11) NOT NULL COMMENT '0=>for profit,1 =>for loses',
  `note` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exist_deals_device_id_foreign` (`device_id`),
  KEY `exist_deals_user_id_foreign` (`user_id`),
  KEY `exist_deals_account_id_foreign` (`account_id`),
  CONSTRAINT `exist_deals_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `exist_deals_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `exist_deals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `device_id` bigint(20) unsigned NOT NULL,
  `expense_type_id` bigint(20) unsigned NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0=>for dont take money from treasury,1=>for take money from treasury',
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_user_id_foreign` (`user_id`),
  KEY `expenses_device_id_foreign` (`device_id`),
  KEY `expenses_expense_type_id_foreign` (`expense_type_id`),
  CONSTRAINT `expenses_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `expenses_expense_type_id_foreign` FOREIGN KEY (`expense_type_id`) REFERENCES `expenses_types` (`id`),
  CONSTRAINT `expenses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `expenses_types`;

CREATE TABLE `expenses_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0 =>not active,1 =>active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `expenses_types_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `makes`;

CREATE TABLE `makes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `stoke_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `store_id` bigint(20) unsigned DEFAULT NULL COMMENT 'use nullable because in add save it without store_id',
  `product_unit_id` bigint(20) unsigned NOT NULL,
  `relation_qte` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'store value relation product_unit_id and main unit',
  `qte` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'qte by main unit',
  `price_make` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'price for 1 main unit',
  `note` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `makes_device_id_foreign` (`device_id`),
  KEY `makes_user_id_foreign` (`user_id`),
  KEY `makes_stoke_id_foreign` (`stoke_id`),
  KEY `makes_product_id_foreign` (`product_id`),
  KEY `makes_store_id_foreign` (`store_id`),
  KEY `makes_product_unit_id_foreign` (`product_unit_id`),
  CONSTRAINT `makes_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `makes_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `makes_product_unit_id_foreign` FOREIGN KEY (`product_unit_id`) REFERENCES `product_units` (`id`),
  CONSTRAINT `makes_stoke_id_foreign` FOREIGN KEY (`stoke_id`) REFERENCES `stokes` (`id`),
  CONSTRAINT `makes_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`),
  CONSTRAINT `makes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=630 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(593,	'2018_01_25_102316_create_stokes_table',	1),
(594,	'2018_01_26_230111_create_bill_prints_table',	1),
(595,	'2018_01_27_015030_create_devices_table',	1),
(596,	'2018_10_12_000000_create_users_table',	1),
(597,	'2018_10_12_100000_create_password_resets_table',	1),
(598,	'2019_08_08_224950_create_bill_messages_table',	1),
(599,	'2019_09_01_112156_create_activities_table',	1),
(600,	'2019_09_09_192417_create_backups_table',	1),
(601,	'2019_09_09_200619_create_settings_table',	1),
(602,	'2019_10_04_144759_create_accounts_table',	1),
(603,	'2019_10_04_160435_create_exist_deals_table',	1),
(604,	'2019_11_04_003136_create_bills_table',	1),
(605,	'2019_11_18_194822_create_product_categories_table',	1),
(606,	'2019_11_18_235632_create_stoke_place_names_table',	1),
(607,	'2019_11_27_142737_create_treasuries_table',	1),
(608,	'2019_12_02_220046_create_expenses_types_table',	1),
(609,	'2019_12_02_224038_create_expenses_table',	1),
(610,	'2019_12_09_213030_create_product_units_table',	1),
(611,	'2019_12_11_170830_create_barcodes_table',	1),
(612,	'2019_12_13_144211_create_products_table',	1),
(613,	'2019_12_15_005321_create_relation_product_units_table',	1),
(614,	'2019_12_15_005729_create_relation_product_makes_table',	1),
(615,	'2019_12_23_004252_create_device_stokes_table',	1),
(616,	'2019_12_26_005536_create_stoke_product_places_table',	1),
(617,	'2019_12_27_135931_create_stores_table',	1),
(618,	'2019_12_27_220501_create_bill_details_table',	1),
(619,	'2020_01_05_212433_create_makes_table',	1),
(620,	'2020_01_26_204554_create_bill_backs_table',	1),
(621,	'2020_01_26_205016_create_bill_back_details_table',	1),
(622,	'2020_01_26_213107_create_sale_make_qte_details_table',	1),
(623,	'2020_01_27_002922_create_product_moves_table',	1),
(624,	'2020_01_28_151025_create_emp_jops_table',	1),
(625,	'2020_01_28_152556_create_emps_table',	1),
(626,	'2020_01_28_155507_create_emp_moves_table',	1),
(627,	'2020_02_03_001815_create_account_calculations_table',	1),
(628,	'2020_02_07_235944_create_permits_table',	1),
(629,	'2020_02_19_112921_create_visits_table',	1);


-- --------------------------------------------------------

DROP TABLE IF EXISTS `permits`;

CREATE TABLE `permits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mange_stoke` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `place_product` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'for product place in stoke',
  `sup_cust` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'for allow use supplier customer',
  `product_make` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'for allow use product make',
  `product_no_qte` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'for allow use product no qte',
  `use_barcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'null or error value for not use barcode',
  `use_barcode2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'null or error value for not use barcode 2',
  `use_barcode3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'null or error value for not use barcode3',
  `bill_design` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'for allow change bill_design',
  `use_expenses` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'for allow use_expenses',
  `use_exit_deal` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'for allow use_exit_deal',
  `use_emp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'for allow use_emp',
  `account_product_move` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'for allow show report account_product_move for supplier or customer',
  `use_visit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'for allow use_visit',
  `only_product_no_qte` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'null or error value for only use product_no_qte only in project,dependent permit product_no_qte',
  `login_counter` int(11) DEFAULT NULL COMMENT 'store number of login',
  `expire_date` date DEFAULT NULL COMMENT 'null for don''t have expire date',
  `use_price2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'null or wrong value for not use price2 for sale',
  `use_price3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'null or wrong value for not use price3 for sale',
  `use_price4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'null or wrong value for not use price4 for sale',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permits` (`id`, `mange_stoke`, `place_product`, `sup_cust`, `product_make`, `product_no_qte`, `use_barcode`, `use_barcode2`, `use_barcode3`, `bill_design`, `use_expenses`, `use_exit_deal`, `use_emp`, `account_product_move`, `use_visit`, `only_product_no_qte`, `login_counter`, `expire_date`, `use_price2`, `use_price3`, `use_price4`, `created_at`, `updated_at`) VALUES
(1,	'$2y$10$jTx8pZ9hVwOk3y8ZCT34QOlwzCgbRO8S9F9Jp/KuidIBDzbosvcCe',	'$2y$10$H2oQnIE3N3zZNFfV7ERWTOq0PdDRXu54yoWKmUpgpKBfxxRlUmTpC',	'$2y$10$mowCMxrkFMJn5WwPO1c27u08KAhYjj4nUpasMjjIrxT8WCNtyLh..',	'$2y$10$I1djvOR.cMSaiv2X.hM7MuaRJ5L/l9vFzRptFTZjxiK1E3xk6l5NG',	'$2y$10$cY5ob8g969B/AFQq5kFsq.GxytN2c4.ozVPuwno1z..277p.Rfu5C',	'$2y$10$KOd7pFJz5N/O9Sef8ErVnuFsEGRnpP7xzS8AAkWzM3PwhEvgFGsyS',	'$2y$10$1m.jhvieEQFDg.H2/vkxvuRnl3Q55lW8SNzfHbYCY8klBcZNZ3syq',	'$2y$10$JDJcgobZLCjNid3UQWblSOZHWMQhuOg9UjG1K9nGzxULX5WxXxQgi',	'$2y$10$QiRRwrZO2aHpJo874kDG4u9iGAxJWaZF4Q5k7T6QMsFByvpsTi6Ri',	'$2y$10$NSyOR6rFE3PUq0oq5yY.eu8LIASfZr9hO8Ckolq.sqjHBc.oMjQHm',	'$2y$10$s.7jrUAvJKZouK/V2QfMzeFPq4ONM/2yY2diKv31B0ECoM0wli8ne',	'$2y$10$/bB94IlG07kEuc13b6tQTOhJbGzRBwDPVFUBhfBSOQplrObBonIhO',	'$2y$10$Ozh4YYbZs4fXE36ygHrSMuQ4ScL3j8W/CP/cQ8M7MMj/fZjrX3dmC',	'$2y$10$0s51SiKqhaUU3k.lhUZB4.xE701wJXwGOyaZVqNjktJFltSRJyWj6',	'$2y$10$NcMZaBh7hHpe/voZ1y2/BuMJI7q6oqSaKq8y7HBQZp47FK5G8pErS',	NULL,	NULL,	'$2y$10$ABcEFV5ZPnSlBXlV9kKhpOWoVxTOsMmVFiimFTYxUXiMv3jwDjnu.',	'$2y$10$IX07bV3s39N9.sxaTIX8.OSLDnwhGpJFJIj2IduAGUJ/F5CUoVjyK',	'$2y$10$n7KSnm6vMMyhRaXu7CtJ5.KnIHyXGHJMCQAUpcJfBkGfT35DlTR8e',	'2020-05-15 01:10:15',	'2020-05-15 01:10:15');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `product_categories`;

CREATE TABLE `product_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0 =>not active,1 =>active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product_categories` (`id`, `name`, `state`, `created_at`, `updated_at`) VALUES
(1,	'بدون',	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `product_moves`;

CREATE TABLE `product_moves` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `store_id` bigint(20) unsigned DEFAULT NULL COMMENT 'used if delete Damaged qte , or delete making, nullable Because type product no qte',
  `stoke_id` bigint(20) unsigned DEFAULT NULL COMMENT 'nullable Because type product no qte',
  `product_id` bigint(20) unsigned NOT NULL,
  `product_unit_id` bigint(20) unsigned NOT NULL,
  `relation_qte` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'store value relation product_unit_id and main unit',
  `qte` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'qte by main unit',
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'price for 1 main unit',
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '0 => bill buy,1 => bill sale, 2 => Damaged Qte buy,3 => Damaged Qte Make, 4 => making,5=>use to make,\n            6 =>bill buy back,7 => bill sale back,8 =>bill buy back replace,9 => bill back sale replace,\n            10=>for move To other stoke (-),11 => for move to this stoke (+),\n            12 => for old qte before edit bill buy,13 => old qte before eqit bill sale,\n            14 => new qte after edit bill buy,15 =>new qte after edit bill sale,16 => when create product',
  `bill_id` bigint(20) unsigned DEFAULT NULL COMMENT 'used if type is 1 or 2',
  `bill_back_id` bigint(20) unsigned DEFAULT NULL COMMENT 'used if type is 6 or 7 if delete it',
  `make_id` bigint(20) unsigned DEFAULT NULL COMMENT 'used if type is 4',
  `note` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_moves_device_id_foreign` (`device_id`),
  KEY `product_moves_user_id_foreign` (`user_id`),
  KEY `product_moves_store_id_foreign` (`store_id`),
  KEY `product_moves_stoke_id_foreign` (`stoke_id`),
  KEY `product_moves_product_id_foreign` (`product_id`),
  KEY `product_moves_product_unit_id_foreign` (`product_unit_id`),
  KEY `product_moves_bill_id_foreign` (`bill_id`),
  KEY `product_moves_bill_back_id_foreign` (`bill_back_id`),
  KEY `product_moves_make_id_foreign` (`make_id`),
  CONSTRAINT `product_moves_bill_back_id_foreign` FOREIGN KEY (`bill_back_id`) REFERENCES `bill_backs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_moves_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_moves_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `product_moves_make_id_foreign` FOREIGN KEY (`make_id`) REFERENCES `makes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_moves_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_moves_product_unit_id_foreign` FOREIGN KEY (`product_unit_id`) REFERENCES `product_units` (`id`),
  CONSTRAINT `product_moves_stoke_id_foreign` FOREIGN KEY (`stoke_id`) REFERENCES `stokes` (`id`),
  CONSTRAINT `product_moves_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`),
  CONSTRAINT `product_moves_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `product_units`;

CREATE TABLE `product_units` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_value_for_min_qte` int(11) NOT NULL DEFAULT 0 COMMENT 'default value for min qte when add new product',
  `state` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0 =>not active,1 =>active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_units_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product_units` (`id`, `name`, `default_value_for_min_qte`, `state`, `created_at`, `updated_at`) VALUES
(1,	'قطعة',	5,	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13'),
(2,	'شنطة',	5,	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13'),
(3,	'علبة',	5,	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13'),
(4,	'كيلو',	5,	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13'),
(5,	'كرتونة',	5,	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13'),
(6,	'بالة',	5,	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13'),
(7,	'طن',	5,	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13'),
(8,	'زجاجة',	5,	1,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_category_id` bigint(20) unsigned NOT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'true => this product show in bill,false =>this product can''t show in bill',
  `special` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true => this product show in special product in bill',
  `allow_buy` tinyint(1) NOT NULL COMMENT 'true => this product can buy',
  `allow_sale` tinyint(1) NOT NULL COMMENT 'true => this product can sale',
  `allow_make` tinyint(1) NOT NULL COMMENT 'true => this product can make',
  `allow_no_qte` tinyint(1) NOT NULL COMMENT 'true => this product has no qte in stoke',
  `product_unit_id` bigint(20) unsigned NOT NULL,
  `min_qte` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'store min qte for product in stoke',
  `barcode1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barcode2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barcode3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_buy` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_sale1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `price_sale2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `price_sale3` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `price_sale4` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_name_unique` (`name`),
  KEY `products_product_category_id_foreign` (`product_category_id`),
  KEY `products_product_unit_id_foreign` (`product_unit_id`),
  CONSTRAINT `products_product_category_id_foreign` FOREIGN KEY (`product_category_id`) REFERENCES `product_categories` (`id`),
  CONSTRAINT `products_product_unit_id_foreign` FOREIGN KEY (`product_unit_id`) REFERENCES `product_units` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `relation_product_makes`;

CREATE TABLE `relation_product_makes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `creator_id` bigint(20) unsigned NOT NULL COMMENT 'store product_id that use to create main product',
  `qte_creator` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `relation_product_makes_product_id_foreign` (`product_id`),
  KEY `relation_product_makes_creator_id_foreign` (`creator_id`),
  CONSTRAINT `relation_product_makes_creator_id_foreign` FOREIGN KEY (`creator_id`) REFERENCES `products` (`id`),
  CONSTRAINT `relation_product_makes_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `relation_product_units`;

CREATE TABLE `relation_product_units` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `product_unit_id` bigint(20) unsigned NOT NULL,
  `relation_qte` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'store vale greater than main unit',
  `barcode1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barcode2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barcode3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_buy` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_sale1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `price_sale2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `price_sale3` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `price_sale4` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `relation_product_units_product_id_foreign` (`product_id`),
  KEY `relation_product_units_product_unit_id_foreign` (`product_unit_id`),
  CONSTRAINT `relation_product_units_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relation_product_units_product_unit_id_foreign` FOREIGN KEY (`product_unit_id`) REFERENCES `product_units` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `sale_make_qte_details`;

CREATE TABLE `sale_make_qte_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `make_id` bigint(20) unsigned DEFAULT NULL,
  `bill_detail_id` bigint(20) unsigned DEFAULT NULL,
  `bill_back_detail_id` bigint(20) unsigned DEFAULT NULL,
  `store_id` bigint(20) unsigned NOT NULL,
  `qte` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'qte by main unit',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_make_qte_details_make_id_foreign` (`make_id`),
  KEY `sale_make_qte_details_bill_detail_id_foreign` (`bill_detail_id`),
  KEY `sale_make_qte_details_bill_back_detail_id_foreign` (`bill_back_detail_id`),
  KEY `sale_make_qte_details_store_id_foreign` (`store_id`),
  CONSTRAINT `sale_make_qte_details_bill_back_detail_id_foreign` FOREIGN KEY (`bill_back_detail_id`) REFERENCES `bill_back_details` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_make_qte_details_bill_detail_id_foreign` FOREIGN KEY (`bill_detail_id`) REFERENCES `bill_details` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_make_qte_details_make_id_foreign` FOREIGN KEY (`make_id`) REFERENCES `makes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_make_qte_details_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `show_treasury_value_in_header` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'true=>show_treasury_value_in_header',
  `allow_sound` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'true=>for_allow_sound',
  `allow_account_without_tel` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'true=>allow_account_without_tel',
  `allow_repeat_tell_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_repeat_tell_account',
  `allow_repeat_supplier_name` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_repeat_supplier_name',
  `allow_repeat_customer_name` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_repeat_customer_name',
  `allow_account_with_negative_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_account_with_negative_account',
  `allow_pay_money_to_account_with_negative_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_pay_money_to_account_with_negative_account',
  `allow_take_money_from_account_with_negative_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_take_money_from_account_with_negative_account',
  `edit_auto_for_default_min_qte_unit` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'true=>for allow_edit automatic for min qte when add product',
  `price1_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'قطاعى' COMMENT 'sore price one name',
  `price2_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'نص جملة' COMMENT 'sore price two name',
  `price3_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'جملة' COMMENT 'sore price three name',
  `price4_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'مندوب' COMMENT 'sore price four name',
  `allow_add_expenses_without_subtract_from_treasury` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_add_expenses_without_subtract_from_treasury',
  `auto_update_price_product_bill_buy` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'true=>for allow_auto_update_price_product when change in_bill_buy',
  `auto_update_price_product_bill_sale` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'true=>for allow_auto_update_price_product when change in _bill_sale',
  `show_unit_when_print_bill` tinyint(1) NOT NULL DEFAULT 1,
  `bill_message_buy_id` bigint(20) unsigned DEFAULT NULL,
  `bill_message_sale_id` bigint(20) unsigned DEFAULT NULL,
  `use_small_price` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `settings_bill_message_buy_id_foreign` (`bill_message_buy_id`),
  KEY `settings_bill_message_sale_id_foreign` (`bill_message_sale_id`),
  CONSTRAINT `settings_bill_message_buy_id_foreign` FOREIGN KEY (`bill_message_buy_id`) REFERENCES `bill_messages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `settings_bill_message_sale_id_foreign` FOREIGN KEY (`bill_message_sale_id`) REFERENCES `bill_messages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`id`, `show_treasury_value_in_header`, `allow_sound`, `allow_account_without_tel`, `allow_repeat_tell_account`, `allow_repeat_supplier_name`, `allow_repeat_customer_name`, `allow_account_with_negative_account`, `allow_pay_money_to_account_with_negative_account`, `allow_take_money_from_account_with_negative_account`, `edit_auto_for_default_min_qte_unit`, `price1_name`, `price2_name`, `price3_name`, `price4_name`, `allow_add_expenses_without_subtract_from_treasury`, `auto_update_price_product_bill_buy`, `auto_update_price_product_bill_sale`, `show_unit_when_print_bill`, `bill_message_buy_id`, `bill_message_sale_id`, `use_small_price`, `created_at`, `updated_at`) VALUES
(1,	1,	1,	1,	0,	0,	0,	0,	0,	0,	1,	'قطاعى',	'نص جملة',	'جملة',	'مندوب',	0,	1,	1,	1,	NULL,	NULL,	0,	'2020-05-15 01:10:13',	'2020-05-15 01:10:13');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `stoke_place_names`;

CREATE TABLE `stoke_place_names` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stoke_place_names_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `stoke_product_places`;

CREATE TABLE `stoke_product_places` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stoke_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `stoke_place_name_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stoke_product_places_stoke_id_foreign` (`stoke_id`),
  KEY `stoke_product_places_product_id_foreign` (`product_id`),
  KEY `stoke_product_places_stoke_place_name_id_foreign` (`stoke_place_name_id`),
  CONSTRAINT `stoke_product_places_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stoke_product_places_stoke_id_foreign` FOREIGN KEY (`stoke_id`) REFERENCES `stokes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stoke_product_places_stoke_place_name_id_foreign` FOREIGN KEY (`stoke_place_name_id`) REFERENCES `stoke_place_names` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `stokes`;

CREATE TABLE `stokes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stokes_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stokes` (`id`, `name`, `state`, `created_at`, `updated_at`) VALUES
(1,	'المخزن الرئيسى',	1,	'2020-05-15 01:10:11',	'2020-05-15 01:10:11');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `stores`;

CREATE TABLE `stores` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stoke_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qte` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'qte by main unit',
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'price for 1 main unit',
  `type` int(11) NOT NULL COMMENT '0 =>if qte not make,1=>if qte is make',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stores_stoke_id_foreign` (`stoke_id`),
  KEY `stores_product_id_foreign` (`product_id`),
  CONSTRAINT `stores_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `stores_stoke_id_foreign` FOREIGN KEY (`stoke_id`) REFERENCES `stokes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `treasuries`;

CREATE TABLE `treasuries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `device_id` bigint(20) unsigned DEFAULT NULL COMMENT 'store device id and treasury id',
  `val` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `note` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '0 for add money,1  for take money ',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `treasuries_user_id_foreign` (`user_id`),
  KEY `treasuries_device_id_foreign` (`device_id`),
  CONSTRAINT `treasuries_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `treasuries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_id` bigint(20) unsigned DEFAULT NULL COMMENT 'to store temp treasury id',
  `state` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0 not active , 1 is active',
  `bg` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'bg2',
  `bg_img` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL COMMENT '1=>admin,2=>normalUser',
  `log_out_security` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_log_out_security_when try to open window you can''t have permetion to open it',
  `allow_edit_my_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_edit_account_my_account',
  `allow_edit_my_account_name` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_edit_my_account_name',
  `allow_edit_account_email` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_edit_account_my_account',
  `allow_change_background` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_edit_account_my_account',
  `allow_manage_activities` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_manage_activities',
  `allow_add_account` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'true=>for allow_add_account',
  `create_notification_when_add_account_with_old_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for create_notification_when_add_account_with_old_account',
  `allow_access_index_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_access_index_account',
  `allow_edit_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_access_index_account',
  `allow_edit_account_type` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_edit_account_type',
  `allow_edit_account_name` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_edit_account_name',
  `allow_edit_account_tel` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_edit_account_tel',
  `allow_delete_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_delete_account',
  `allow_adjust_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_adjust_account',
  `create_notification_when_adjust_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for create_notification_when_adjust_account',
  `allow_access_report_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_access_report_account',
  `allow_delete_account_buy_take_money` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_delete_account_buy_take_money',
  `notification_when_delete_account_buy_take_money` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for create_notification_when_delete_buy_or_take',
  `allow_mange_stoke` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_stoke',
  `allow_mange_place_in_stoke` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_place_in_stoke',
  `allow_mange_product_place_in_stoke` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_product_place_in_stoke',
  `allow_mange_backup` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_backup',
  `allow_download_backup` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_download_backup',
  `allow_mange_treasury` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_treasury',
  `allow_delete_treasury` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_delete_treasury',
  `create_notification_when_delete_treasury` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for create_notification_when_delete_treasury',
  `allow_mange_setting` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_setting',
  `allow_mange_device` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_device',
  `allow_access_total_report` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_access_total_report',
  `allow_add_expenses_and_expenses_type` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_add_expenses_and_expenses_type',
  `allow_mange_expenses_type` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_expenses_type',
  `allow_mange_expenses` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_expenses',
  `allow_delete_expenses` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_delete_expenses',
  `allow_add_expenses_with_out_subtract_form_treasury` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_add_expenses_with_out_subtract_form_treasury',
  `notification_when_add_expenses_with_out_subtract_form_treasury` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for create_notification_when_add_expenses_with_out_subtract_form_treasury',
  `notification_when_delete_expenses` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for notification_when_delete_expenses',
  `allow_add_product` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_product_unit',
  `allow_manage_product` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_product_unit',
  `allow_mange_barcode` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_barcode',
  `allow_mange_product_category` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_product_category',
  `allow_mange_product_unit` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_product_unit',
  `allow_mange_print_setting` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_bill_message',
  `allow_mange_bill_message` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_mange_bill_message',
  `allow_create_bill_buy` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_create_bill_buy',
  `allow_create_bill_sale_show` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_create_bill_buy',
  `allow_manage_bill_buy` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_manage_bill_buy',
  `allow_edit_bill_buy` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_edit_bill_buy',
  `allow_delete_bill_buy` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_delete_bill_buy',
  `notification_delete_bill_buy` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for notification_delete_bill_buy',
  `allow_create_bill_sale` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_create_bill_sale',
  `allow_manage_bill_sale` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_manage_bill_sale',
  `allow_manage_bill_sale_with_profit` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_manage_bill_sale_with_profit',
  `allow_edit_bill_sale` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_edit_bill_sale',
  `allow_delete_bill_sale` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_delete_bill_sale',
  `notification_delete_bill_sale` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for notification_delete_bill_sale',
  `allow_add_make` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_add_make',
  `allow_manage_make` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_manage_make',
  `allow_delete_make` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_delete_make',
  `notification_delete_make` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for notification_delete_make',
  `allow_access_product_in_stoke` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_access_product_in_store',
  `allow_access_product_in_all_stoke` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_access_product_in_all_stoke',
  `allow_move_product_in_stoke` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_move_product_in_stoke',
  `notification_when_move_product` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for notification_when_move_product',
  `allow_add_damage` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_add_damage',
  `notification_when_add_damage` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for notification_when_add_damage',
  `allow_access_product_move` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_access_product_move',
  `allow_delete_damage` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_access_product_move',
  `notification_when_delete_damage` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for notification_when_delete_damage',
  `allow_access_product_profit` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_access_product_profit',
  `allow_add_emp` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_add_emp',
  `allow_manage_emp_jops` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_add_emp',
  `allow_manage_emp` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_add_emp',
  `allow_manage_emp_operation` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_add_emp',
  `allow_manage_emp_move` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_add_emp',
  `allow_manage_emp_attend` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_add_emp',
  `allow_create_exit_deal` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_create_exit_deal',
  `allow_manage_exit_deal` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_manage_exit_deal',
  `allow_delete_exit_deal` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_delete_exit_deal',
  `notification_when_delete_exit_deal` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for notification_when_delete_exit_deal',
  `allow_add_visit` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow_create_exit_deal',
  `allow_manage_visit` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow manage and edit',
  `allow_delete_visit` tinyint(1) NOT NULL DEFAULT 0,
  `notification_when_delete_visit` tinyint(1) NOT NULL DEFAULT 0,
  `show_notification_visit` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true=>for allow manage and edit',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_device_id_foreign` (`device_id`),
  CONSTRAINT `users_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `device_id`, `state`, `bg`, `bg_img`, `type`, `log_out_security`, `allow_edit_my_account`, `allow_edit_my_account_name`, `allow_edit_account_email`, `allow_change_background`, `allow_manage_activities`, `allow_add_account`, `create_notification_when_add_account_with_old_account`, `allow_access_index_account`, `allow_edit_account`, `allow_edit_account_type`, `allow_edit_account_name`, `allow_edit_account_tel`, `allow_delete_account`, `allow_adjust_account`, `create_notification_when_adjust_account`, `allow_access_report_account`, `allow_delete_account_buy_take_money`, `notification_when_delete_account_buy_take_money`, `allow_mange_stoke`, `allow_mange_place_in_stoke`, `allow_mange_product_place_in_stoke`, `allow_mange_backup`, `allow_download_backup`, `allow_mange_treasury`, `allow_delete_treasury`, `create_notification_when_delete_treasury`, `allow_mange_setting`, `allow_mange_device`, `allow_access_total_report`, `allow_add_expenses_and_expenses_type`, `allow_mange_expenses_type`, `allow_mange_expenses`, `allow_delete_expenses`, `allow_add_expenses_with_out_subtract_form_treasury`, `notification_when_add_expenses_with_out_subtract_form_treasury`, `notification_when_delete_expenses`, `allow_add_product`, `allow_manage_product`, `allow_mange_barcode`, `allow_mange_product_category`, `allow_mange_product_unit`, `allow_mange_print_setting`, `allow_mange_bill_message`, `allow_create_bill_buy`, `allow_create_bill_sale_show`, `allow_manage_bill_buy`, `allow_edit_bill_buy`, `allow_delete_bill_buy`, `notification_delete_bill_buy`, `allow_create_bill_sale`, `allow_manage_bill_sale`, `allow_manage_bill_sale_with_profit`, `allow_edit_bill_sale`, `allow_delete_bill_sale`, `notification_delete_bill_sale`, `allow_add_make`, `allow_manage_make`, `allow_delete_make`, `notification_delete_make`, `allow_access_product_in_stoke`, `allow_access_product_in_all_stoke`, `allow_move_product_in_stoke`, `notification_when_move_product`, `allow_add_damage`, `notification_when_add_damage`, `allow_access_product_move`, `allow_delete_damage`, `notification_when_delete_damage`, `allow_access_product_profit`, `allow_add_emp`, `allow_manage_emp_jops`, `allow_manage_emp`, `allow_manage_emp_operation`, `allow_manage_emp_move`, `allow_manage_emp_attend`, `allow_create_exit_deal`, `allow_manage_exit_deal`, `allow_delete_exit_deal`, `notification_when_delete_exit_deal`, `allow_add_visit`, `allow_manage_visit`, `allow_delete_visit`, `notification_when_delete_visit`, `show_notification_visit`, `remember_token`, `created_at`, `updated_at`) VALUES
(1,	'VIP Account Ease',	'123',	NULL,	'$2y$10$zOf9EFn9Zi82xp3gMjkQFOHEHrPRgXGDP0.FvHaz/FVR5QPbu4oYS',	1,	1,	'bg2',	NULL,	1,	0,	0,	0,	0,	0,	0,	1,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	NULL,	'2020-05-15 01:10:12',	'2020-05-15 01:10:12');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `visits`;

CREATE TABLE `visits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `device_id` bigint(20) unsigned DEFAULT NULL,
  `bill_id` bigint(20) unsigned DEFAULT NULL,
  `account_id` bigint(20) unsigned DEFAULT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'this price add to treasury when finish',
  `type` int(11) NOT NULL COMMENT '0=>for free vist,1=>for online visit,2 =>for in place visit,3 => for plan',
  `state_visit` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0=>not finish,1=>finish',
  `alarm_before` int(11) DEFAULT 0 COMMENT 'store day alarm before date alarm',
  `date_alarm` date DEFAULT NULL,
  `date_finish` date DEFAULT NULL,
  `note` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visits_user_id_foreign` (`user_id`),
  KEY `visits_device_id_foreign` (`device_id`),
  KEY `visits_bill_id_foreign` (`bill_id`),
  KEY `visits_account_id_foreign` (`account_id`),
  CONSTRAINT `visits_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `visits_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON DELETE CASCADE,
  CONSTRAINT `visits_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`),
  CONSTRAINT `visits_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- THE END
